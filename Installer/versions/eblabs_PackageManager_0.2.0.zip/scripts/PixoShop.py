import Qt

from functools import partial
import os
#import scandir
import json
import re
import math

class Actions(object):
    pixmapImageFileCache = {} # for caching loading image files into pixmaps
    textAspectQPainter = False

    @classmethod
    def loadPixmapFromPathSimple(cls, filepath):
        imagePixmap = Qt.QtGui.QPixmap(filepath)
        return imagePixmap

    @classmethod
    def loadPixmapFromPath(cls, filepath, width, height):
        try:
            cls.pixmapImageFileCache
        except:
            cls.pixmapImageFileCache = {}

        if filepath not in cls.pixmapImageFileCache.keys():
            #http://doc.qt.io/qt-5/qpainter.html#drawImage
            
            # add checkered background
            width, height = 250,250
            color= [0.5]*3
            pixmap = cls.newQImage(250, 250, color)
            pixmap = cls.addCheckers(pixmap)
            
            # add image
            imagePixmap = Qt.QtGui.QPixmap(filepath)

            # scale down
            topAreaRect = Qt.QtCore.QRect(0, 0, pixmap.width(), pixmap.height()*.75)
            fitRect, resizeFactor = cls.fitRectWithin(imagePixmap.rect(), pixmap.rect())
            imagePixmap = imagePixmap.scaled(fitRect.width(), fitRect.height(), Qt.QtCore.Qt.KeepAspectRatio, Qt.QtCore.Qt.SmoothTransformation)


            # positioning
            sourceRect = Qt.QtCore.QRect(0,0, imagePixmap.width(), imagePixmap.height())
            x = (pixmap.width() - imagePixmap.width()) / 2
            y = ((pixmap.height()*0.75) - imagePixmap.height()) / 2
            targetRect = Qt.QtCore.QRect(x,y, imagePixmap.width(), imagePixmap.height())
            
            # fit
            p = Qt.QtGui.QPainter(pixmap)
            p.drawPixmap(targetRect, imagePixmap, sourceRect)
            p.end()
            
            #
            cls.pixmapImageFileCache[filepath] = pixmap
            

        return cls.pixmapImageFileCache[filepath]

    @classmethod
    def fitRectWithin(cls, inner, outer):
        '''
        resize factor
        '''
        resizeFactor = min(float(outer.width()) / float(inner.width()), float(outer.height()) / float(inner.height()))

        '''
        center
        '''
        fitRect = Qt.QtCore.QRect(0,0,inner.width() * resizeFactor, inner.height() * resizeFactor)
        fitRect.moveCenter(outer.center())

        return [fitRect, resizeFactor]



    
    @classmethod
    def truncateString(cls, textString, maxWidth, padString = False, *args, **kwargs):
        textString = str(textString)
        if len(textString) > maxWidth:
            # middle
            textString = textString[:int(maxWidth / 2)] + '...' + textString[int(maxWidth / -2):]
            
            # end
            #textString = textString[:int(maxWidth-3)] + '...'
        
        if padString:
            textString = textString.ljust(maxWidth)
            
            
            
        return textString
    
    @classmethod
    def addRectangle(cls, pixmap, color, x, y, width, height, opacity = 1 ):
        # pen
        qcolor = Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255), int(opacity * 255))
        
        # set rect
        rect = Qt.QtCore.QRect(int(x*pixmap.width()), int(y*pixmap.height()), int(width*pixmap.width()), int(height*pixmap.height()))

        # painter
        painter = Qt.QtGui.QPainter(pixmap)
        #painter.setPen(pen)
        painter.fillRect(rect, qcolor)
        
        # end
        painter.end() 
        return pixmap

    @classmethod
    def addIcon(cls, pixmap, x, y, width, height, iconType = 'dir' ):
        if iconType in ['dir']:
            return cls.addIconFolder( pixmap, x, y, width, height )
        elif iconType in ['doc', 'image']:
            return cls.addIconDocument( pixmap, x, y, width, height )
        elif iconType in ['selection', 'pose', 'animation']:
            
            #
            colorLookup = {}
            colorLookup['selection'] = [0.639, .824, .455] # green
            colorLookup['pose'] = [0.275, .753, .804]  # blue
            colorLookup['animation'] = [0.847, .263, .145]  # red
            
            color = colorLookup[iconType]
            
            return cls.addIconLargeSquare( pixmap, x, y, width, height, color=color )
        # fallback
        return cls.addIconFolder( pixmap, x, y, width, height )


    @classmethod
    def addHoverShading(cls, qimage, color = [0,0,0, 0.2]):
        #
        qcolor = Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255), int(color[3] * 255))
        
        # 
        width = qimage.width()
        height = qimage.height()
        
        # painter
        p = Qt.QtGui.QPainter(qimage)
        p.setRenderHint(Qt.QtGui.QPainter.Antialiasing)
        p.setPen(Qt.QtCore.Qt.PenStyle.NoPen)
        
        # draw white test circle
        p.setBrush(qcolor)
        x, y = 0,0
        rect = Qt.QtCore.QRect(0, 0, int(width), int(height))
        p.drawEllipse(rect)
        
        # end
        p.end() 
        
        returnMap = qimage
        if type(qimage) == Qt.QtGui.QImage:
            newQImage = Qt.QtGui.QPixmap(width, height)
            newQImage.convertFromImage(qimage)
            returnMap = newQImage
        
        return returnMap 



    @classmethod
    def drawPolygon(cls, pixmap, x, y, width, height, points, color ):    
        
        # build polygon
        polygon = Qt.QtGui.QPolygonF()
        
        for p in  points:
            # offset to x,y, width, height
            px = (x*pixmap.width()) + (p[0]*width*pixmap.width())
            py = (y*pixmap.height())  + (p[1]*height*pixmap.height())
            qpoint = Qt.QtCore.QPointF(px, py)
            polygon.append(qpoint)
        
        # path
        painterPath = Qt.QtGui.QPainterPath()
        painterPath.addPolygon(polygon)
        
        # pen
        #pen = Qt.QtGui.QPen(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)));
        #pen.setWidth(1)
        
        if len(color)==3:
            color = color + [1]
        
        # brush
        brush = Qt.QtGui.QBrush(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255), int(color[3] * 255)))
        
        # painter
        painter = Qt.QtGui.QPainter(pixmap)
        #painter.setPen(pen)
        painter.fillPath(painterPath, brush)

        # end
        painter.end() 
        return pixmap 

    @classmethod
    def drawPolygonOutline(cls, pixmap, x, y, width, height, points, color, lineWidth = 0.05, absoluteLineWidth = False ):
        
        # build polygon
        polygon = Qt.QtGui.QPolygonF()
        
        for p in  points:
            # offset to x,y, width, height
            px = (x*pixmap.width()) + (p[0]*width*pixmap.width())
            py = (y*pixmap.height())  + (p[1]*height*pixmap.height())
            qpoint = Qt.QtCore.QPointF(px, py)
            polygon.append(qpoint)
        
        # path
        painterPath = Qt.QtGui.QPainterPath()
        painterPath.addPolygon(polygon)
        
        # pen
        pen = Qt.QtGui.QPen(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)));
        penWidth = pixmap.width() * lineWidth
        if absoluteLineWidth:
            penWidth = lineWidth
        pen.setWidth(penWidth)
        
        # brush
        #brush = Qt.QtGui.QBrush(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)))
        
        # painter
        painter = Qt.QtGui.QPainter(pixmap)
        #painter.setRenderHint(Qt.QtGui.QPainter.Antialiasing, True)
        painter.setRenderHint(Qt.QtGui.QPainter.SmoothPixmapTransform, True)

        painter.setPen(pen)
        
        # draw polygon
        painter.drawPolygon(polygon)
        #painter.fillPath(painterPath, brush)

        # end
        painter.end() 
        return pixmap            
    
    @classmethod
    def newQImage(cls, width, height, color):
        # add in transparency if not in color
        if len(color) == 3:
            color.append(1)
        # 
        qimage = Qt.QtGui.QImage(Qt.QtCore.QSize(width, height), Qt.QtGui.QImage.Format_ARGB32)
        qimage.fill(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255), int(color[3] * 255)))
        #pixmap = Qt.QtGui.QPixmap(width, height)
        #pixmap.fill(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)))
        return qimage
    
    @classmethod
    def addBorder(cls, pixmap, borderWidth, color):
        # pen
        pen = Qt.QtGui.QPen(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)));
        pen.setWidth(borderWidth)
        
        #
        width = pixmap.width()
        height = pixmap.height()
        offset = 1
        
        # painter
        painter = Qt.QtGui.QPainter(pixmap)
        painter.setPen(pen)
        painter.drawLine(0, 0, 0, width)
        painter.drawLine(0, height-offset, width, height-offset)
        painter.drawLine(width-offset, height, width-offset, 0)
        painter.drawLine(width, 0, 0, 0)
        
        # end
        painter.end() 
        return pixmap

    @classmethod
    def addText(cls, pixmap, textString, color, scaleMultiplier = 0.95, alignMode = Qt.QtCore.Qt.AlignCenter, backgroundColor = False):   
        bgPixmap = False
        if backgroundColor:
            bgPixmap = cls.qImageCanvas(pixmap.width(), pixmap.height())
        
        # set rect
        rect = Qt.QtCore.QRect(0, 0, pixmap.width(), pixmap.height())
        
        # pen
        pen = Qt.QtGui.QPen(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)));
        
        # painter
        painter = Qt.QtGui.QPainter(pixmap)
        painter.setPen(pen)

        # painter font, fit text to width
        factor = float(pixmap.rect().width()) / float(painter.fontMetrics().boundingRect(textString).width())
        factorV = float(pixmap.rect().height()) / float(painter.fontMetrics().boundingRect(textString).height())
        factor = min(factor, factorV)
        factor = factor * scaleMultiplier
        
        # set font scaling
        font = painter.font()
        font.setPixelSize(font.pixelSize() * factor)
        painter.setFont(font)

        # draw text
        painter.drawText(rect, alignMode, textString)
           
        # end
        painter.end()
        
        #bgImageVar = PS.overlayImage(bgImageVar, imageVar )
        
        return  pixmap 

    @classmethod
    def getTextAspect(cls, text=False, widget=False):
        aspectRatio = 1
        if text and widget:
            textRect = widget.fontMetrics().boundingRect(text)
            aspectRatio = float(textRect.width())/float(textRect.height())
        
        '''
        else:
            if not cls.textAspectQPainter:
                cls.textAspectQPainter = Qt.QtGui.QPainter()
            textRect = cls.textAspectQPainter.fontMetrics().boundingRect(stringVar)
            aspectRatio = float(textRect.width())/float(textRect.height())
        '''
        return aspectRatio

    @classmethod
    def addTextInsideRect(cls, pixmap, text ='myString', color = [1, 1, 1, 1], x=0, y=0, w=1, h=1, scaleMultiplier = 0.95, alignMode = Qt.QtCore.Qt.AlignCenter, fitHeight=True):
        '''
        prep string
        '''
        #text = cls.truncateString(text, 30)
        
        '''
        imageRect
        '''
        outer = Qt.QtCore.QRect(int(x * pixmap.width()),int(y * pixmap.height()) , int(w * pixmap.width()), int(h * pixmap.height()))

        '''
        painter
        '''
        pen = Qt.QtGui.QPen(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)))
        painter = Qt.QtGui.QPainter(pixmap)
        painter.setPen(pen)

        '''
        text rect
        '''
        inner = painter.fontMetrics().boundingRect(text)

        '''
        fit Rect, scale factor
        '''
        fitRect, scaleFactor = cls.fitRectWithin(inner, outer)
        fitRect.moveCenter(outer.center())

        font = painter.font()
        font.setPixelSize(float(font.pixelSize()) * float(scaleFactor))
        painter.setFont(font)

        '''
        draw text
        '''
        painter.drawText(fitRect, alignMode, text)
           
        # end
        painter.end()


        return pixmap

    @classmethod
    def createBreadcrumbTextPixmap(cls, textString, width, height, textColor = [1,1,1,1], fitHeight = True):   
        # 
        pixmap = cls.newQImage(width, height, [0,0,0,0])

        # set rect
        padding = 0.2
        '''
        x = int(pixmap.width()*(padding))
        y = int(pixmap.height()*(padding))
        w = int(pixmap.width()-(x*2))
        h = int(pixmap.height()-(y*2))
        '''
        x = 0
        y = 0
        w = pixmap.width()
        h = pixmap.height() * 0.96
        
        rect = Qt.QtCore.QRect(x, y, w, h)

        # pen
        color = textColor
        pen = Qt.QtGui.QPen(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)));
        
        # painter
        painter = Qt.QtGui.QPainter(pixmap)
        painter.setPen(pen)
        
        # painter font, fit text to width
        sizeCheckString = textString#'ABC'
        factorHeight = float(rect.height()) / float(painter.fontMetrics().boundingRect(sizeCheckString).height())
        factorWidth = float(rect.width()) / float(painter.fontMetrics().boundingRect(sizeCheckString).width())
        factor = factorHeight  * 0.9
        if not fitHeight:
            factor = min(factorWidth  * 0.9, factor)
        
        # set font scaling
        font = painter.font()
        font.setPixelSize(font.pixelSize() * factor)
        painter.setFont(font)
        
        # draw text
        painter.drawText(rect, Qt.QtCore.Qt.AlignCenter, textString) #Qt.QtCore.Qt.AlignTop|Qt.QtCore.Qt.AlignHCenter

        # end
        painter.end()
        
        
        return pixmap

    @classmethod
    def transparentPixelsBoundingBox(cls, pixmapVar):
        '''
        bounding - box - of - an - image
        '''
        l = pixmapVar.width()
        t = pixmapVar.height()
        r = 0
        b = 0
        paddingWidth = pixmapVar.width()
        paddingHeight = pixmapVar.height()


        for y in range(pixmapVar.height()):
            rowFilled = False
            for x in range(pixmapVar.width()):
                if Qt.QtGui.qAlpha(pixmapVar.pixel(x, y)):
                    rowFilled = True
                    r = max(r, x)
                    if l > x:
                        l = x
            if rowFilled:
                t = min(t, y)
                b = y
        return Qt.QtCore.QRect(Qt.QtCore.QPoint(l , t ), Qt.QtCore.QPoint(r , b ))

    @classmethod
    def addCheckers(cls, pixmap):
        # checker pattern image
        size = pixmap.width()/10
        checkerPixmap = Qt.QtGui.QPixmap(size*2, size*2)
        p = Qt.QtGui.QPainter(checkerPixmap)
        
        color = [.1,.1,.1]
        colorA = Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255))
        color = [.0,.0,.0]
        colorB = Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255))

        p.fillRect(0, 0, size, size, colorA)
        p.fillRect(size, size, size, 2*size, colorA)
        p.fillRect(size, 0, size, size, colorB)
        p.fillRect(0, size, size, size, colorB)
        p.end()
        
        # fill in bg
        p = Qt.QtGui.QPainter(pixmap)
        p.fillRect(pixmap.rect(), checkerPixmap)
        p.end()

        #
        return pixmap

    @classmethod
    def testTransparentIcon(cls, width, height):
        #https://stackoverflow.com/questions/24943711/qt-drawing-icons-using-color-and-alpha-map
        
        ## generate alpha ###################################################
        # setup image
        qimage = Qt.QtGui.QImage(Qt.QtCore.QSize(width, height), Qt.QtGui.QImage.Format_ARGB32)
        qimage.fill(Qt.QtCore.Qt.GlobalColor.transparent)
        
        # painter
        p = Qt.QtGui.QPainter(qimage)
        p.setRenderHint(Qt.QtGui.QPainter.Antialiasing)
        p.setPen(Qt.QtCore.Qt.PenStyle.NoPen)
        
        # draw white test circle
        p.setBrush(Qt.QtCore.Qt.GlobalColor.white)
        x, y = 0,0
        rect = Qt.QtCore.QRect(int(x*width), int(y*height), int(width), int(height))
        p.drawEllipse(rect)
        
        # end
        p.end()

        qpixmap = Qt.QtGui.QPixmap(width, height)
        qpixmap.convertFromImage(qimage)
        #icon = Qt.QtGui.QIcon(qpixmap)
        
        return qpixmap

    @classmethod
    def convertToIcon(cls, imageVar):

        # qimage format
        if type(imageVar) == Qt.QtGui.QImage:
            newPixmap = Qt.QtGui.QPixmap(imageVar.width(), imageVar.height())
            newPixmap.convertFromImage(imageVar)
            imageVar = newPixmap
        
        #
        icon = Qt.QtGui.QIcon(imageVar)
        
        #
        return icon  
    
    @classmethod
    def convertToPixmap(cls, imageVar):

        # qimage format
        if type(imageVar) == Qt.QtGui.QImage:
            newPixmap = Qt.QtGui.QPixmap(imageVar.width(), imageVar.height())
            newPixmap.convertFromImage(imageVar)
            imageVar = newPixmap
        
        #
        return imageVar  



        
    @classmethod 
    def pixmapCanvas(cls, width = 100, height = 100, fillColor = Qt.QtCore.Qt.GlobalColor.transparent):
        '''
        create transparent qimage
        '''
        qimage = Qt.QtGui.QImage(Qt.QtCore.QSize(width, height), Qt.QtGui.QImage.Format_ARGB32)
        qimage.fill(fillColor)

        qpixmap = Qt.QtGui.QPixmap(width, height)
        qpixmap.convertFromImage(qimage)

        return qpixmap

    @classmethod 
    def qImageCanvas(cls, width = 100, height = 100, fillColor = Qt.QtCore.Qt.GlobalColor.transparent):
        '''
        create transparent qimage
        '''
        qimage = Qt.QtGui.QImage(Qt.QtCore.QSize(width, height), Qt.QtGui.QImage.Format_ARGB32)
        qimage.fill(fillColor)

        return qimage



    @classmethod
    def tintRGB(cls, colorVar, tintVar):
        resultColor = []
        for i, c in enumerate(colorVar):
            resultColor.append(colorVar[i]*tintVar[i])
        return resultColor
      
        
    @classmethod
    def drawQimagePolygon(cls, qImage, x, y, width, height, points, color ):    
        
        '''
        set color
        '''
        if len(color) == 3:
            color.append(1)
        
        qcolor = Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255), int(color[3] * 255))
        
        '''
        build polygon
        '''
        polygon = Qt.QtGui.QPolygonF()
        for p in  points:
            # offset to x,y, width, height
            px = (x*qImage.width()) + (p[0]*width*qImage.width())
            py = (y*qImage.height())  + (p[1]*height*qImage.height())
            qpoint = Qt.QtCore.QPointF(px, py)
            polygon.append(qpoint)
        
        '''
        '''
        #painterPath = Qt.QtGui.QPainterPath()
        #painterPath.addPolygon(polygon)
        
        '''
        setup painter
        '''
        p = Qt.QtGui.QPainter(qImage)
        p.setRenderHint(Qt.QtGui.QPainter.Antialiasing)
        p.setPen(Qt.QtCore.Qt.PenStyle.NoPen)
        p.setBrush(qcolor)
        
        '''
        draw polygon
        '''
        
        p.drawPolygon(polygon)

        '''
        close drawing
        '''
        p.end()

        return qImage         

    @classmethod
    def drawQimagePolygon_roundedSquare(cls, qImage, radius=5, color=[0.255, 0.518, 0.953, 1], x=0, y=0, w=1, h=1):
        '''
        square points
        '''
        points = []
        points.append([0,0])
        points.append([0,1])
        points.append([1,1])
        points.append([1,0])
        points.append([0,0])

        '''
        color
        '''
        if len(color) == 3:
            color.append(1)
        qcolor = Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255), int(color[3] * 255))

        '''
        create rect
        '''
        width = qImage.width()
        height = qImage.height()
        rect = Qt.QtCore.QRect(int(x * width), int(y * height), int(w*width), int(h*height))
        '''
        polygon = Qt.QtGui.QPolygonF()
        for p in points:
            # offset to x,y, width, height
            px = (x * qImage.width()) + (p[0] * width * qImage.width())
            py = (y * qImage.height()) + (p[1] * height * qImage.height())
            qpoint = Qt.QtCore.QPointF(px, py)
            polygon.append(qpoint)
        '''

        '''
        setup painter
        '''
        p = Qt.QtGui.QPainter(qImage)
        p.setRenderHint(Qt.QtGui.QPainter.Antialiasing)
        p.setPen(Qt.QtCore.Qt.PenStyle.NoPen)
        p.setBrush(qcolor)


        '''
        draw rounded rect
        '''
        p.drawRoundedRect(rect, radius, radius)

        '''
        close drawing
        '''
        p.end()


        return qImage

    @classmethod
    def qImageToQPixmap(cls, qImage):    
        qpixmap = Qt.QtGui.QPixmap(qImage.width(), qImage.height())
        qpixmap.convertFromImage(qImage)
        return qpixmap
    
    @classmethod
    def blendColors(cls, rgba1, rgba2, blendValue): 
        resultColor = []
        for i  in range(len(rgba1)):
            c = (rgba2[i] * blendValue) + (rgba1[i] * (1-blendValue))
            resultColor.append(c)
        return resultColor
        
    @classmethod
    def lightenImage(cls, qImage):
        qImage = Qt.QtGui.QPixmap(qImage)
        color = Qt.QtGui.QColor(0,1,1,1)
        painter = Qt.QtGui.QPainter(qImage)
        painter.setCompositionMode(painter.CompositionMode_ColorBurn)
        painter.fillRect(qImage.rect(), color)
        painter.end()
        return qImage
        
    @classmethod
    def overlayImage(cls, baseImage, overlayImage, doScale = True):
        '''
        scale overlay to fit
        '''
        aspectRatioMode =  Qt.QtCore.Qt.KeepAspectRatio # IgnoreAspectRatio
        if doScale:
            overlayImage = overlayImage.scaled(baseImage.width(), baseImage.height(), aspectRatioMode, transformMode=Qt.QtCore.Qt.SmoothTransformation)

        '''
        adjust qrect center
        '''
        rect = overlayImage.rect()
        rect.moveCenter(Qt.QtCore.QPoint(baseImage.rect().center()))

        '''
        composit
        '''
        painter = Qt.QtGui.QPainter(baseImage)
        overlayImage = Qt.QtGui.QPixmap(overlayImage)
        painter.drawPixmap(rect, overlayImage)

        return baseImage

    @classmethod
    def rotatePoint(cls, origin_point, point, angle):
        """
        Rotate a point counterclockwise by a given angle around a given origin.

        The angle should be given in radians.
        ie rotate(origin, point, math.radians(10))
        https://stackoverflow.com/questions/34372480/rotate-point-about-another-point-in-degrees-python
        """
        ox, oy = origin_point
        px, py = point

        qx = ox + math.cos(angle) * (px - ox) - math.sin(angle) * (py - oy)
        qy = oy + math.sin(angle) * (px - ox) + math.cos(angle) * (py - oy)
        return [qx, qy]


class Templates(object):
    
        
    @classmethod
    def genericPixmap(cls, labelText, width, height, backgroundImage = False, iconType = 'dir' ):
        # fill
        color = [0.8,0.8,0.8]
        pixmap = cls.newQImage(width, height, color)
        
        # contents placeholder rect
        color = [1,1,1]
        x = .05
        y = .05
        width = .9
        height = .9
        pixmap = Actions.addRectangle(pixmap, color, x, y, width, height )
        if backgroundImage:
            pixmap = Actions.loadPixmapFromPath(backgroundImage, width, height)

        # placeholder icon
        if not backgroundImage:
            x = .2
            y = .1
            width = .6
            height = .6
            pixmap = Actions.addIcon(pixmap, x, y, width, height, iconType=iconType )
                      
        # text backdrop rect
        color = [1,1,1]
        x = 0
        y = 0.75
        width = 1
        height = 1
        pixmap = Actions.addRectangle(pixmap, color, x, y, width, height )
        
        # text icon
        padding = .05
        x = 0
        y = 0.75
        width = 0.25
        height = 0.25
        x = x + padding
        y = y + padding
        width = width- (padding * 2)
        height = height- (padding * 2)
        pixmap = Actions.addIcon(pixmap, x, y, width, height, iconType = iconType )

        # boder
        borderWidth = 1
        color = [.9,.9,.9]
        pixmap = Actions.addBorder(pixmap, borderWidth, color)
        
        # text
        color = [0,0,0]
        x = .25
        y = 0.75
        width = .75
        height = 0.25
        #pixmap = Actions.addText(pixmap, textString, color)
        pixmap = Actions.addTextInsideRect(pixmap, labelText, color, x, y, width, height)
        
        return pixmap

    @classmethod
    def drawQImageShape_checkMark(cls, qImage, x, y, width, height, color=[0.255, 0.518, 0.953]):
        # check mark
        points = []
        points.append([0.0823024094309, 0.505687340944])
        points.append([0.399430238991, 0.81936831392])
        points.append([0.896140980809, 0.325282183766])
        points.append([0.768753164485, 0.198359220403])
        points.append([0.400311911721, 0.563164177983])
        points.append([0.205590356873, 0.386658203617])
        points.append([0.205590356873, 0.386658203617])

        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)

        return qImage



    @classmethod
    def drawQImageShape_x(cls, qImage, x, y, width, height, color = [0.255, 0.518, 0.953] ):    
        points = []
        points.append([0.5,0.358578610045])
        points.append([0.782842695616,0.0757359144293])
        points.append([0.924264064497,0.217157283311])
        points.append([0.641421368881,0.499999978927])
        points.append([0.924264085571,0.782842695616])
        points.append([0.782842716689,0.924264064497])
        points.append([0.5,0.641421347808])
        points.append([0.217157283311,0.924264064497])
        points.append([0.0757359144293,0.782842695616])
        points.append([0.358578631119,0.499999978927])
        points.append([0.0757359355028,0.217157283311])
        points.append([0.217157304384,0.0757359144293])
        points.append([0.5,0.358578610045])
        
        
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)
        return qImage




    @classmethod
    def drawQImageShape_search(cls, qImage, x, y, width, height, color = [0.255, 0.518, 0.953] ):    
        '''
        circle part
        '''
        points = []
        points.append([0.4,0.0602632365107])
        points.append([0.504984436885,0.0768911212721])
        points.append([0.599692282698,0.125147150996])
        points.append([0.674852869254,0.200307717302])
        points.append([0.723108919228,0.29501555299])
        points.append([0.73973660149,0.4])
        points.append([0.723108716729,0.50498438626])
        points.append([0.674852687005,0.599692181449])
        points.append([0.599692161199,0.674852707255])
        points.append([0.504984376135,0.723108736979])
        points.append([0.399999989875,0.73973664199])
        points.append([0.29501559349,0.723108757229])
        points.append([0.200307798302,0.674852727505])
        points.append([0.125147252245,0.599692201698])
        points.append([0.0768912022716,0.50498440651])
        points.append([0.0602633175102,0.4])
        points.append([0.0768912022716,0.29501559349])
        points.append([0.125147231995,0.200307778052])
        points.append([0.200307757802,0.125147211745])
        points.append([0.295015563115,0.0768911415219])
        points.append([0.4,0.0602632365107])
        
        
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)
        
        '''
        handle part
        '''
        
        points = []
        points.append([0.630663888166,0.728699525255])
        points.append([0.871300474745,0.969336111834])
        points.append([0.969336111834,0.871300474745])
        points.append([0.728699525255,0.630663888166])
        points.append([0.630663888166,0.728699525255])
        
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)
        

        return qImage  

    @classmethod
    def drawQImageShape_star(cls, qImage, x, y, width, height, color = [0.255, 0.518, 0.953] ):    
        points = []
        points.append([0.5,0.0454196589561])
        points.append([0.642467796803,0.373929988083])
        points.append([0.975528270006,0.390911142764])
        points.append([0.730517819524,0.644919897851])
        points.append([0.793892681599,0.94992819005])
        points.append([0.500000014447,0.812400843439])
        points.append([0.206107378006,0.949928249654])
        points.append([0.269482180476,0.644919935104])
        points.append([0.0244716405869,0.390911187467])
        points.append([0.357532203197,0.373930017886])
        points.append([0.5,0.0454196589561])
        
        
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)
        #qImage = cls.drawPolygon(qImage, x, y, width, height, points, color)

        return qImage      

    @classmethod
    def drawQImageShape_square(cls, qImage, x, y, width, height, color = [0.255, 0.518, 0.953] ):    
        points = []
        points.append([0,0])
        points.append([0,1])
        points.append([1,1])
        points.append([1,0])
        points.append([0,0])

        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)
        #qImage = cls.drawPolygon(qImage, x, y, width, height, points, color)

        return qImage  



    @classmethod
    def drawQImageShape_plus(cls, qImage, x, y, width, height, color = [0.255, 0.518, 0.953] ):    
        points = []
        points.append([0.405000005662,0.40499997735])
        points.append([0.405000005662,0.025])
        points.append([0.59500002265,0.025])
        points.append([0.59500002265,0.40499997735])
        points.append([0.975,0.40499997735])
        points.append([0.975,0.594999994338])
        points.append([0.59500002265,0.594999994338])
        points.append([0.59500002265,0.975])
        points.append([0.405000005662,0.975])
        points.append([0.405000005662,0.594999994338])
        points.append([0.025,0.594999994338])
        points.append([0.025,0.40499997735])
        points.append([0.405000005662,0.40499997735])
        
        
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)
        #qImage = cls.drawPolygon(qImage, x, y, width, height, points, color)

        return qImage  



    @classmethod
    def drawQImageShape_tearOff(cls, qImage, x, y, width, height, color = [0.255, 0.518, 0.953] ):   
        points = []
        points.append([0.035,0.592999994457])
        points.append([0.035,0.965])
        points.append([0.406999977827,0.965])
        points.append([0.286760929502,0.844760923959])
        points.append([0.844760923959,0.286760929502])
        points.append([0.965,0.406999977827])
        points.append([0.965,0.035])
        points.append([0.592999994457,0.035])
        points.append([0.713239064757,0.155239042585])
        points.append([0.155239042585,0.713239064757])
        points.append([0.035,0.592999994457])

        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)

        return qImage

    @classmethod
    def drawQImageShape_options(cls, qImage, x, y, width, height, color = [0.255, 0.518, 0.953] )  :      
        points = []
        points.append([0.0, 0.0])
        points.append([1.0, 0.0])
        points.append([1.0, 0.272727251053])
        points.append([0.0, 0.272727251053])
        points.append([0.0, 0.0])
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)

        points = []
        points.append([0.0, 0.363636374474])
        points.append([1.0, 0.363636374474])
        points.append([1.0, 0.636363625526])
        points.append([0.0, 0.636363625526])
        points.append([0.0, 0.363636374474])
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)

        points = []
        points.append([0.0, 0.727272748947])
        points.append([1.0, 0.727272748947])
        points.append([1.0, 1.0])
        points.append([0.0, 1.0])
        points.append([0.0, 0.727272748947])
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)

        return qImage    

    @classmethod
    def drawQImageShape_squareOutline(cls, qImage, x, y, width, height, color = [0.255, 0.518, 0.953] ) :
        '''
        top
        '''

        points = []
        points.append([0.1,0.1])
        points.append([0.9,0.1])
        points.append([0.9,0.9])
        points.append([0.1,0.9])
        points.append([0.1,0.1])
        qImage = Actions.drawPolygonOutline(qImage, x, y, width, height, points, color, lineWidth = 0.05)
        '''
        points = []
        points.append([0.95,0.95])
        points.append([0.95,0.05])
        points.append([0.05,0.05])
        points.append([0.05,0.95])
        points.append([0.95,0.95])
        points.append([0.95,0.91])
        points.append([0.09,0.91])
        points.append([0.09,0.09])
        points.append([0.91,0.09])
        points.append([0.91,0.95])
        points.append([0.95,0.95])
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)
        '''
        return qImage
    
    @classmethod
    def drawQImageShape_shareIcon(cls, qImage, x, y, width, height, color = [0.255, 0.518, 0.953] )  :      
        '''
        arrow
        '''
        points = []
        points.append([0.48,0.504599276085])
        points.append([0.52,0.504599276085])
        points.append([0.52,0.2])
        points.append([0.6,0.2])
        points.append([0.5,0.1])
        points.append([0.4,0.2])
        points.append([0.48,0.2])
        points.append([0.48,0.504599276085])
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)
        
        
        '''
        box
        '''
        points.append([0.42,0.34])
        points.append([0.42,0.3])
        points.append([0.2,0.3])
        points.append([0.2,0.8])
        points.append([0.8,0.8])
        points.append([0.8,0.3])
        points.append([0.58,0.3])
        points.append([0.58,0.34])
        points.append([0.76,0.34])
        points.append([0.76,0.76])
        points.append([0.24,0.76])
        points.append([0.24,0.34])
        points.append([0.42,0.34])
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)


        return qImage
    
    @classmethod
    def drawQImageShape_circle(cls, qImage, x, y, width, height, color=[0.255, 0.518, 0.953]):
        points = []
        points.append([0.500000109747, 0.00499970406294])
        points.append([0.577435219809, 0.011093994081])
        points.append([0.652963621914, 0.0292267757654])
        points.append([0.724725556821, 0.0589515605569])
        points.append([0.790953989923, 0.0995364058018])
        points.append([0.85001817435, 0.149982000887])
        points.append([0.900463739932, 0.209046214819])
        points.append([0.941048555672, 0.275274662673])
        points.append([0.970773310959, 0.34703659758])
        points.append([0.988906063139, 0.422565007061])
        points.append([0.994999999106, 0.499999999106])
        points.append([0.988905738592, 0.577435064912])
        points.append([0.970772986412, 0.652963430136])
        points.append([0.941048260629, 0.724725335538])
        points.append([0.900463444889, 0.790953753889])
        points.append([0.850017879307, 0.850017938316])
        points.append([0.790953724384, 0.900463533401])
        points.append([0.724725306034, 0.941048349142])
        points.append([0.652963400632, 0.970773104429])
        points.append([0.577435028031, 0.988905856609])
        points.append([0.499999947473, 0.995000117123])
        points.append([0.422564859539, 0.988905856609])
        points.append([0.347036479563, 0.970773104429])
        points.append([0.275274574161, 0.941048319638])
        points.append([0.20904615581, 0.900463474393])
        points.append([0.149981971383, 0.850017879307])
        points.append([0.0995364058018, 0.790953724384])
        points.append([0.0589515900612, 0.724725291282])
        points.append([0.029226834774, 0.65296338588])
        points.append([0.0110940825939, 0.577435005903])
        points.append([0.00499982208014, 0.499999917969])
        points.append([0.0110940825939, 0.422564822659])
        points.append([0.029226834774, 0.347036435306])
        points.append([0.0589516195655, 0.275274515152])
        points.append([0.0995364648104, 0.209046067297])
        points.append([0.149982059896, 0.14998188287])
        points.append([0.209046244323, 0.0995363172889])
        points.append([0.275274692178, 0.0589515015483])
        points.append([0.347036612332, 0.0292267462611])
        points.append([0.422565007061, 0.011093994081])
        points.append([0.500000109747, 0.00499970406294])

        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, color)

        return qImage

    @classmethod 
    def pixmapShape_star(cls):
        # fill
        color = [0.9,0.9,0.9]
        width = 50
        height = 50
        '''

        pixmap = cls.newQImage(width, height, color)
        '''
        qimage = Qt.QtGui.QImage(Qt.QtCore.QSize(width, height), Qt.QtGui.QImage.Format_ARGB32)
        qimage.fill(Qt.QtCore.Qt.GlobalColor.transparent)
        
        # painter
        p = Qt.QtGui.QPainter(qimage)
        p.setRenderHint(Qt.QtGui.QPainter.Antialiasing)
        p.setPen(Qt.QtCore.Qt.PenStyle.NoPen)
        
        # draw white test circle
        p.setBrush(Qt.QtCore.Qt.GlobalColor.white)
        x, y = 0,0
        rect = Qt.QtCore.QRect(int(x*width), int(y*height), int(width), int(height))
        p.drawEllipse(rect)
        
        # end
        p.end()

        qpixmap = Qt.QtGui.QPixmap(width, height)
        qpixmap.convertFromImage(qimage)
        #icon = Qt.QtGui.QIcon(qpixmap)
        
        return qpixmap




    @classmethod
    def addIconFolder(cls, pixmap, x, y, width, height ):    
        #
        color = [0.2,0.2,0.2]         
        # shape points
        points = []
        points.append([0.0444666300034,0.120350069215])
        points.append([0.0444666300034,0.879649930785])
        points.append([0.955533369997,0.879649930785])
        points.append([0.955533369997,0.257747201318])
        points.append([0.478308106293,0.257747201318])
        points.append([0.379488645575,0.120350069215])
        points.append([0.0444666300034,0.120350069215])
        
        # build polygon
        polygon = Qt.QtGui.QPolygonF()
        
        for p in  points:
            # offset to x,y, width, height
            px = (x*pixmap.width()) + (p[0]*width*pixmap.width())
            py = (y*pixmap.height())  + (p[1]*height*pixmap.height())
            qpoint = Qt.QtCore.QPointF(px, py)
            polygon.append(qpoint)
        
        # path
        painterPath = Qt.QtGui.QPainterPath()
        painterPath.addPolygon(polygon)
        
        # pen
        pen = Qt.QtGui.QPen(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)));
        pen.setWidth(1)
        
        # brush
        brush = Qt.QtGui.QBrush(Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)))
        
        # painter
        painter = Qt.QtGui.QPainter(pixmap)
        painter.setPen(pen)
        #painter.drawPolygon(polygonPoints)
        painter.fillPath(painterPath, brush)

        # end
        painter.end() 
        return pixmap

    @classmethod
    def addIconTreeview(cls, pixmap, x, y, width, height ):    
        # smallSquareA
        points = []
        points.append([0.1,0.1])
        points.append([0.3,0.1])
        points.append([0.3,0.3])
        points.append([0.1,0.3])
        points.append([0.1,0.1])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # smallSquareB
        points = []
        points.append([0.1,0.4])
        points.append([0.1,0.6])
        points.append([0.3,0.6])
        points.append([0.3,0.4])
        points.append([0.1,0.4])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # smallSquareC
        points = []
        points.append([0.1,0.7])
        points.append([0.1,0.9])
        points.append([0.3,0.9])
        points.append([0.3,0.7])
        points.append([0.1,0.7])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # bigSquareA
        points = []
        points.append([0.4,0.1])
        points.append([0.4,0.3])
        points.append([0.9,0.3])
        points.append([0.9,0.1])
        points.append([0.4,0.1])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # bigSquareB
        points = []
        points.append([0.4,0.4])
        points.append([0.4,0.6])
        points.append([0.9,0.6])
        points.append([0.9,0.4])
        points.append([0.4,0.4])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # bigSquareC
        points = []
        points.append([0.4,0.7])
        points.append([0.4,0.9])
        points.append([0.9,0.9])
        points.append([0.9,0.7])
        points.append([0.4,0.7])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)

        return pixmap    

    @classmethod
    def addIconLargeSquare(cls, pixmap, x, y, width, height, color = [0.255, 0.518, 0.953] ):    
        # |bigIcon|bigIcon
        points = []
        points.append([0.1,0.1])
        points.append([0.1,0.9])
        points.append([0.9,0.9])
        points.append([0.9,0.1])
        points.append([0.1,0.1])
        #color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)

        return pixmap 

    @classmethod
    def addIconLargeIcons(cls, pixmap, x, y, width, height ):    
        # |bigIcon|bigIcon
        points = []
        points.append([0.1,0.1])
        points.append([0.1,0.9])
        points.append([0.9,0.9])
        points.append([0.9,0.1])
        points.append([0.1,0.1])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)

        return pixmap  
    
    @classmethod
    def addIconMediumIcons(cls, pixmap, x, y, width, height ):    
        # mediumBox1
        points = []
        points.append([0.1,0.1])
        points.append([0.45,0.1])
        points.append([0.45,0.451441007183])
        points.append([0.1,0.451441007183])
        points.append([0.1,0.1])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # mediumBox2
        points = []
        points.append([0.55,0.1])
        points.append([0.55,0.451441007183])
        points.append([0.9,0.451441007183])
        points.append([0.9,0.1])
        points.append([0.55,0.1])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # mediumBox3
        points = []
        points.append([0.1,0.551441007183])
        points.append([0.1,0.9])
        points.append([0.45,0.9])
        points.append([0.45,0.551441007183])
        points.append([0.1,0.551441007183])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # mediumBox4
        points = []
        points.append([0.55,0.551441007183])
        points.append([0.55,0.9])
        points.append([0.9,0.9])
        points.append([0.9,0.551441007183])
        points.append([0.55,0.551441007183])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)

        return pixmap  
    
    @classmethod
    def addIconSmallIcons(cls, pixmap, x, y, width, height ):    
        # smallBox1
        points = []
        points.append([0.1,0.1])
        points.append([0.1,0.3])
        points.append([0.3,0.3])
        points.append([0.3,0.1])
        points.append([0.1,0.1])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # smallBox2
        points = []
        points.append([0.4,0.1])
        points.append([0.4,0.3])
        points.append([0.6,0.3])
        points.append([0.6,0.1])
        points.append([0.4,0.1])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # smallBox3
        points = []
        points.append([0.7,0.1])
        points.append([0.7,0.3])
        points.append([0.9,0.3])
        points.append([0.9,0.1])
        points.append([0.7,0.1])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # smallBox4
        points = []
        points.append([0.1,0.4])
        points.append([0.1,0.6])
        points.append([0.3,0.6])
        points.append([0.3,0.4])
        points.append([0.1,0.4])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # smallBox5
        points = []
        points.append([0.1,0.7])
        points.append([0.1,0.9])
        points.append([0.3,0.9])
        points.append([0.3,0.7])
        points.append([0.1,0.7])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # smallBox6
        points = []
        points.append([0.4,0.4])
        points.append([0.4,0.6])
        points.append([0.6,0.6])
        points.append([0.6,0.4])
        points.append([0.4,0.4])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # smallBox7
        points = []
        points.append([0.4,0.7])
        points.append([0.4,0.9])
        points.append([0.6,0.9])
        points.append([0.6,0.7])
        points.append([0.4,0.7])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # smallBox8
        points = []
        points.append([0.7,0.4])
        points.append([0.7,0.6])
        points.append([0.9,0.6])
        points.append([0.9,0.4])
        points.append([0.7,0.4])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # smallBox9
        points = []
        points.append([0.7,0.7])
        points.append([0.7,0.9])
        points.append([0.9,0.9])
        points.append([0.9,0.7])
        points.append([0.7,0.7])
        color = [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)

        return pixmap  


    @classmethod
    def addIconDocument(cls, pixmap, x, y, width, height, backgroundColor =  [0.255, 0.518, 0.953]):    

        # background square
        points = []
        points.append([0.0420387455357,0.0420387455357])
        points.append([0.957961254464,0.0420387455357])
        points.append([0.957961254464,0.957961254464])
        points.append([0.0420387455357,0.957961254464])
        points.append([0.0420387455357,0.0420387455357])
        color = backgroundColor# [0.255, 0.518, 0.953] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # text block 1
        points = []
        points.append([0.194834031727,0.237431669519])
        points.append([0.194834031727,0.304607076017])
        points.append([0.805165968273,0.304607076017])
        points.append([0.805165968273,0.237431669519])
        points.append([0.194834031727,0.237431669519])
        color = [1,1,1] # white
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)        

        # text block 1
        points = []
        points.append([0.194834031727,0.351921983135])
        points.append([0.194834031727,0.419097389633])
        points.append([0.805165968273,0.419097389633])
        points.append([0.805165968273,0.351921983135])
        points.append([0.194834031727,0.351921983135])
        color = [1,1,1] # white
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color) 

        # text block 1
        points = []
        points.append([0.194834031727,0.466412296751])
        points.append([0.194834031727,0.533587703249])
        points.append([0.805165968273,0.533587703249])
        points.append([0.805165968273,0.466412296751])
        points.append([0.194834031727,0.466412296751])
        color = [1,1,1] # white
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color) 

        # text block 1
        points = []
        points.append([0.194834031727,0.580902610367])
        points.append([0.194834031727,0.648078016865])
        points.append([0.805165968273,0.648078016865])
        points.append([0.805165968273,0.580902610367])
        points.append([0.194834031727,0.580902610367])
        color = [1,1,1] # white
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)

        # text block 1
        points = []
        points.append([0.194834031727,0.695392923983])
        points.append([0.194834031727,0.762568330481])
        points.append([0.614490313616,0.762568330481])
        points.append([0.614490313616,0.695392923983])
        points.append([0.194834031727,0.695392923983])
        color = [1,1,1] # white
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)

        return pixmap   

    @classmethod
    def addIconInfo(cls, pixmap, x, y, width, height ):    
        
        colors = {}
        colors['white'] = [1,1,1,1]
        colors['blue'] = [0.255, 0.518, 0.953]
        
        # |bigIcon|bigIcon
        points = []
        points.append([0.1,0.1])
        points.append([0.1,0.9])
        points.append([0.9,0.9])
        points.append([0.9,0.1])
        points.append([0.1,0.1])
        color = colors['blue'] # blue
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # infoBoxA
        points = []
        points.append([0.45,0.2])
        points.append([0.45,0.3])
        points.append([0.55,0.3])
        points.append([0.55,0.2])
        points.append([0.45,0.2])
        color = colors['white']
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        # infoBoxB
        points = []
        points.append([0.45,0.4])
        points.append([0.45,0.8])
        points.append([0.55,0.8])
        points.append([0.55,0.4])
        points.append([0.45,0.4])
        color = colors['white']
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, points, color)
        
        return pixmap



    @classmethod
    def drawQImageShape_edit(cls, qImage, x, y, width, height, color = [0.255, 0.518, 0.953] )  :      
        
        
        colorPaper = cls.tintRGB([1]*3, color)
        colorFlap = cls.tintRGB([0.6]*3, color)
        colorLines = cls.tintRGB([0.4]*3 , color)
        colorPencil = cls.tintRGB([0.1]*3, color)    

        
        '''
        paper
        '''
        points = []
        points.append([0.16214755573,0.26579116937])
        points.append([0.331073777865,0.0968649472353])
        points.append([0.83785244427,0.0968649472353])
        points.append([0.83785244427,0.911481086479])
        points.append([0.16214755573,0.911481086479])
        points.append([0.16214755573,0.26579116937])
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, colorPaper)


        '''
        corner flap
        '''
        points = []
        points.append([0.331073777865,0.0968649472353])
        points.append([0.331073777865,0.26579116937])
        points.append([0.16214755573,0.26579116937])
        points.append([0.331073777865,0.0968649472353])
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, colorFlap)
        
        '''
        top line
        '''        
        points = []
        points.append([0.299658253878,0.387240619465])
        points.append([0.299658253878,0.44573198004])
        points.append([0.700341746122,0.44573198004])
        points.append([0.700341746122,0.387240619465])
        points.append([0.299658253878,0.387240619465])      
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, colorLines)

        '''
        mid line
        '''        
        points = []
        points.append([0.299658253878,0.556166841601])
        points.append([0.299658253878,0.614658202175])
        points.append([0.700341746122,0.614658202175])
        points.append([0.700341746122,0.556166841601])
        points.append([0.299658253878,0.556166841601])    
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, colorLines)

        '''
        bot line
        '''        
        points.append([0.299658253878,0.725093063736])
        points.append([0.299658253878,0.783584424311])
        points.append([0.518404980594,0.783584424311])
        points.append([0.530142836434,0.725093063736])
        points.append([0.299658253878,0.725093063736]) 
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, colorLines)    

        '''
        pencil
        '''        
        points = []
        points.append([0.478592350614,0.814176855547])
        points.append([0.585392402982,0.801726456604])
        points.append([0.968744672255,0.418374187331])
        points.append([0.87439501883,0.324024533907])
        points.append([0.491042749557,0.70737680318])
        points.append([0.478592350614,0.814176855547])
        qImage = Actions.drawQimagePolygon(qImage, x, y, width, height, points, colorPencil)               

        return qImage  

    @classmethod
    def drawQImageShape_Grabby(cls, pixmap, x, y, width, height, color = [0.255, 0.518, 0.953] , angle = 0) :
        # curve1
        points = []
        points.append([0.402352981233, 0.943224853832])
        points.append([0.416040286037, 0.962548107674])
        points.append([0.494138436981, 0.965768649981])
        points.append([0.615713909068, 0.952886480753])
        points.append([0.689786382128, 0.935978633642])
        points.append([0.705083958086, 0.91423997307])
        points.append([0.703473686932, 0.821649381745])
        points.append([0.706694229239, 0.751602586569])
        points.append([0.729238025388, 0.626806572175])
        points.append([0.743730465769, 0.535021116427])
        points.append([0.773520482109, 0.470610270288])
        points.append([0.797674549411, 0.405394288572])
        points.append([0.814582396522, 0.340178306856])
        points.append([0.825791135551, 0.277559243001])
        points.append([0.794264529968, 0.253342016653])
        points.append([0.755618022285, 0.24931633877])
        points.append([0.737289381155, 0.295895850136])
        points.append([0.7186449448, 0.348103344533])
        points.append([0.705889093663, 0.384460763577])
        points.append([0.708304500393, 0.337762900126])
        points.append([0.719576398467, 0.27254691841])
        points.append([0.735552791911, 0.21692940457])
        points.append([0.737723528466, 0.16100406151])
        points.append([0.699384850003, 0.137591970739])
        points.append([0.648606115629, 0.138831253627])
        points.append([0.628596078296, 0.197669309774])
        points.append([0.613298502338, 0.292675307829])
        points.append([0.606857417724, 0.367552916465])
        points.append([0.602026604264, 0.368358052042])
        points.append([0.603636875417, 0.296700985712])
        points.append([0.603636875417, 0.200084716504])
        points.append([0.613298502338, 0.125207107867])
        points.append([0.610014800986, 0.0675451755629])
        points.append([0.560096395228, 0.0490270572979])
        points.append([0.50534717601, 0.0619092265257])
        points.append([0.497666808508, 0.116350616523])
        points.append([0.502189792748, 0.190423089583])
        points.append([0.500579521595, 0.290259901099])
        points.append([0.497358979288, 0.352255340507])
        points.append([0.490302236233, 0.355649427939])
        points.append([0.486087081213, 0.303947205903])
        points.append([0.477112237784, 0.229503744578])
        points.append([0.478280395621, 0.167445146124])
        points.append([0.467632121994, 0.106002206111])
        points.append([0.416735035535, 0.0954722845677])
        points.append([0.364511609126, 0.113935209793])
        points.append([0.357265388935, 0.168684429011])
        points.append([0.369342422586, 0.27013151168])
        points.append([0.379004049507, 0.355475882814])
        points.append([0.385445134121, 0.414250779916])
        points.append([0.385445134121, 0.464974321251])
        points.append([0.369342422586, 0.522138947199])
        points.append([0.352434575475, 0.552734099115])
        points.append([0.334721592787, 0.554344370268])
        points.append([0.311372661061, 0.539851929887])
        points.append([0.29204940722, 0.50201055778])
        points.append([0.234884781271, 0.46014350779])
        points.append([0.197848544741, 0.447261338562])
        points.append([0.168058528402, 0.450481880869])
        points.append([0.139878783216, 0.512477320278])
        points.append([0.157591765905, 0.53904679431])
        points.append([0.193822866858, 0.568031675073])
        points.append([0.222002612044, 0.585744657761])
        points.append([0.246961814922, 0.625196301021])
        points.append([0.285608322606, 0.68236092697])
        points.append([0.33633186394, 0.735499875034])
        points.append([0.379809185084, 0.764484755797])
        points.append([0.395106761042, 0.795885043289])
        points.append([0.395106761042, 0.795885043289])

        '''
        apply rotation
        '''
        new_points = []
        for p in points:
            coord = Actions.rotatePoint([0.5,0.5], p, math.radians(angle))
            new_points.append(coord)

        '''
        '''
        pixmap = Actions.drawPolygon(pixmap, x, y, width, height, new_points, color)

        return pixmap