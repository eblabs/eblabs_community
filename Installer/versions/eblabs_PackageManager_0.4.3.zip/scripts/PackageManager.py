#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
eblabs Package Manager

@2019 Eric Bates, eric@eric-bates.com

This is a Package Manager for installing and updating all of your eblabs animation tools.

"""

import os
from functools import partial

from . import Qt
from . import Prefs
from . import DataWidgets
from . import Utils
from . import PixoShop

__author__ = "Eric Bates, eblabs.com"
__copyright__ = "Copyright (c)2019, Eric Bates"
__credits__ = ["Eric Bates"]
__maintainer__ = "Eric Bates"
__email__ = "info@eblabs.com"
__status__ = "Beta"
__version__ = '0.4.3'
__version_date__ = '2019-10-18'

'''
- reinstall shelf button
- update button
- import shelf button 2019->2017 setup
'''

class PrefsManager(Prefs.PrefsManager):
    instance = False

    @classmethod
    def getInstance(cls):
        '''
        override this method to set prefs group
        '''
        if not cls.instance:
            kwargs = {}
            kwargs['prefsGroup'] = 'PackageManager'
            cls.instance = Prefs.Prefs(**kwargs)
        return cls.instance

    @classmethod
    def print_basic_info(cls):
        print('##### Package Manager #####')
        print('version: {0}'.format(__version__))
        print('   date: {0}'.format(__version_date__))


class Window(Qt.QtWidgets.QDialog):

    def __init__(self, *args, **kwargs):
        parent = Utils.QTHelpers.get_main_window()

        '''
        set parent
        '''
        super(Window, self).__init__(parent)

        '''
        set title
        '''
        windowTitle = "eblabs Package Manager"

        '''
        '''
        self.setObjectName(windowTitle)
        self.setWindowTitle(windowTitle)

        '''
        set window flags
        '''
        self.setWindowFlags(
            Qt.QtCore.Qt.Window |
            Qt.QtCore.Qt.CustomizeWindowHint |
            Qt.QtCore.Qt.WindowTitleHint |
            Qt.QtCore.Qt.WindowCloseButtonHint
            )

        '''
        main layout for Document
        '''
        self.main_layout = Utils.VBoxLayout(self)
        self.main_layout.setObjectName('main_layout')
        self.main_layout.setAlignment(Qt.QtCore.Qt.AlignTop)
        self.setLayout(self.main_layout)

    def display(self):
        '''
        set mode
        '''
        windowTitle = "eblabs Package Manager"
        self.setObjectName(windowTitle)
        self.setWindowTitle(windowTitle)

        '''
        deffered add document
        '''
        self.main_document = Document(self)
        self.main_layout.addWidget(self.main_document)

        '''
        set to user path
        '''
        self.main_document.set_key(Utils.Core.get_user_path())
        self.main_document.update_to_widget()

        '''
        set size
        '''
        self.resize(900, 700)
        self.show()

        '''
        debugging
        '''
        PrefsManager.print_basic_info()

class Document(DataWidgets.DataWidget, Qt.QtWidgets.QWidget):
    def __init__(self, *args, **kwargs):
        '''
        attributes
        '''
        self.internal_data = {}
        self.pages = {}
        self.onChangeCallback = False

        '''
        inherit
        '''
        super(Document, self).__init__(*args, **kwargs)

    def do_layout(self):
        '''
        main layout
        '''
        self.main_layout = Utils.GridLayout(self)
        self.main_layout.setAlignment(Qt.QtCore.Qt.AlignTop | Qt.QtCore.Qt.AlignLeft)

        '''
        menu bar
        '''
        self.main_menu_bar = Qt.QtWidgets.QMenuBar(self)
        self.main_layout.addWidget(self.main_menu_bar, 0, 0, 1, 2)
        self.main_layout.setAlignment(self.main_menu_bar, Qt.QtCore.Qt.AlignLeft)

        '''
        build menus
        '''
        self.add_menu_items(self.main_menu_bar)

        '''
        right tabs
        '''
        self.right_tab_area = Qt.QtWidgets.QTabWidget(self)
        self.main_layout.addWidget(self.right_tab_area, 1, 2, 1, 1)

        '''
        User Tab
        '''
        self.main_tab = UserPage(self)
        self.right_tab_area.addTab(self.main_tab, 'Info')

        '''
        left options
        '''
        self.page_list = Qt.QtWidgets.QListWidget(self)
        self.page_list.setVerticalScrollMode(Qt.QtWidgets.QAbstractItemView.ScrollPerPixel)
        self.page_list.itemPressed.connect(self.on_selection_change)

        self.main_layout.addWidget(self.page_list, 1, 0, 1, 1)
        self.page_list.setFixedWidth(300)

        '''
        signals
        '''
        self.setup_signals_and_connections()

    def setup_signals_and_connections(self):
        self.main_tab.version_changed.connect(self.update_to_widget)

    def add_menu_items(self, parent_menu):
        '''
        main menu, User
        '''
        menu = parent_menu.addMenu("Main Menu")

        '''
        Packages
        '''
        sub_menu = menu.addMenu('Packages')
        sub_menu.addAction("Add Package", partial(Utils.Core.install_package, callback=self.update_to_widget))

        '''
        Help
        '''
        menu = parent_menu.addMenu("Help")

        '''
        Update
        '''
        sub_menu = menu.addMenu('Update')
        action = sub_menu.addAction("Update Package Manager", Utils.Core.update_package_manager)
        action.setEnabled(True)

    def update_to_widget(self):
        self.populate_package_list()
        self.package_list_set_initial_selection()
        self.on_selection_change()

    def populate_package_list(self):
        '''
        clear list
        '''
        self.page_list.clear()

        '''
        get packages
        '''
        self.internal_data = Utils.Core.get_packages_basic_info(root_path=self.get_key())
        if not self.internal_data:
            return False

        '''
        test
        '''
        for sub_folder, data_file_path in self.internal_data:
            '''
            create labels and info
            '''
            widget = PackageListItemWidget()
            item = Qt.QtWidgets.QListWidgetItem('', self.page_list)
            item.setSizeHint(Qt.QtCore.QSize(self.page_list.contentsSize().width(), 40))

            '''
            set list items/widgets
            '''
            self.page_list.addItem(item)
            self.page_list.setItemWidget(item, widget)

            '''
            set labels
            '''
            widget.set_key(data_file_path)
            widget.update_to_widget()

    def package_list_set_initial_selection(self):
        '''
        '''
        if self.page_list.count():
            self.page_list.setCurrentRow(0)

    def on_selection_change(self, *args, **kwargs):
        '''
        get active datafile
        '''
        data_file = self.get_current_data_filepath()
        self.set_value(data_file)

        '''
        update child widgets
        '''
        self.update_child_widgets()

    def update_child_widgets(self):
        '''
        override
        '''
        data_file = self.get_value()
        self.main_tab.set_key(data_file)
        self.main_tab.update_to_widget()

    def get_current_data(self):
        '''
        get active datafile
        '''
        data_file = self.get_current_data_filepath()
        if not data_file:
            return False
        '''
        load json data 
        '''
        data_value = {}
        try:
            data_value = Utils.FileUtils.read_json_file(data_file)
        except Exception as e:
            data_value = {}
        if not data_value:
            data_value = {}
        return data_value

    def get_current_data_filepath(self):
        '''
        get selected items
        '''
        current_item = self.page_list.currentItem()
        if not current_item:
            return False
        '''
        get widget from item
        '''
        widget = self.page_list.itemWidget(current_item)
        data_file = False
        try:
            data_file = widget.get_key()
        except Exception as e:
            #print(283, Exception, e)
            pass
        if not data_file:
            return False
        return data_file


class PackageListItemWidget(DataWidgets.DataWidget, Qt.QtWidgets.QWidget):
    def __init__(self, *args, **kwargs):
        super(PackageListItemWidget, self).__init__(*args, **kwargs)

    def do_layout(self):
        '''
        layout
        '''
        self.main_layout = Utils.GridLayout(self)
        self.setLayout(self.main_layout)

        '''
        Main Label
        '''
        self.main_label = Qt.QtWidgets.QLabel('Main')
        self.main_layout.addWidget(self.main_label, 0, 0, 1, 1)

        '''
        Sub Label
        '''
        self.sub_label = Qt.QtWidgets.QLabel('Sub')
        self.main_layout.addWidget(self.sub_label, 0, 1, 1, 1, Qt.QtCore.Qt.AlignRight)

    def set_key(self, key):
        '''
        store key
        '''
        self.data_key = key

        '''
        load json data internally
        '''
        data_value = {}
        try:
            data_value = Utils.FileUtils.read_json_file(self.data_key)
        except Exception as e:
            data_value = {}
        if not data_value:
            data_value = {}

        '''
        store
        '''
        self.set_value(data_value)

    def update_to_widget(self):
        '''
        set labels
        https://html-online.com/editor/
        '''
        data = self.get_value()
        text = data.get('package', 'NOT SET')
        text = '<h3><strong>{0}</strong></h3>'.format(text)
        self.main_label.setText(text)
        text = data.get('version', 'NOT SET')
        self.sub_label.setText(text)


class UserPage(DataWidgets.DataWidgetCollection, Qt.QtWidgets.QWidget):

    version_changed = Qt.QtCore.Signal()

    def __init__(self, *args, **kwargs):
        #
        self.version_widget = False
        super(UserPage, self).__init__(*args, **kwargs)

    def do_layout(self):
        '''
        update blocking
        '''
        self.set_block_updates(True)

        '''
        layout
        '''
        page_layout = Qt.QtWidgets.QGridLayout(self)
        page_layout.setColumnStretch(0,1)
        self.setLayout(page_layout)

        '''
        scroll area layout
        '''
        scroll_area_widget = Qt.QtWidgets.QScrollArea(self)
        scroll_area_widget.setWidgetResizable(True)
        scroll_area_widget.setVerticalScrollBarPolicy(Qt.QtCore.Qt.ScrollBarAsNeeded)
        page_layout.addWidget(scroll_area_widget, 0,0,1,1)

        '''
        layout + widget
        '''
        w = Qt.QtWidgets.QWidget(self)
        self.main_layout = Qt.QtWidgets.QVBoxLayout(w)
        w.setLayout(self.main_layout)
        scroll_area_widget.setWidget(w)

        self.main_layout.setAlignment(Qt.QtCore.Qt.AlignLeft | Qt.QtCore.Qt.AlignTop)
        self.main_layout.setSpacing(3)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        '''
        widget types
        '''
        widget_types = {}
        widget_types['singleLine'] = DataWidgets.TextLineDisplay
        widget_types['singleLineHeader'] = DataWidgets.TextLineDisplayHeader
        widget_types['multiLine'] = DataWidgets.TextMultiDisplay
        widget_types['url'] = DataWidgets.URLDisplay
        #widget_types['versionCombo'] = DataWidgets.ComboBoxEdit
        widget_types['versionCombo'] = DataWidgets.OptionsButtonEdit
        widget_types['shelfButtonGroup'] = ButtonListWidgetViewer



        #widget_types['shelfButtonGroup'] = EditorButtonWidget

        '''
        add widgets for keywords
        '''
        keywords_config = []
        keywords_config.append(['package', 'singleLineHeader'])
        #keywords_config.append(['package_id', 'singleLine'])
        keywords_config.append(['version', 'versionCombo'])
        keywords_config.append(['shelf_data', 'shelfButtonGroup'])
        keywords_config.append(['website', 'url'])
        keywords_config.append(['support', 'url'])
        keywords_config.append(['description', 'multiLine'])
        self.keyword_lookup = {}
        for k, t in keywords_config:
            '''
            create widget
            '''
            w = widget_types[t](self)
            self.add_widget(k, w)

            '''
            set data
            '''
            w.set_key(k)
            w.set_value('')
            w.set_parent_data(False)
            w.update_to_widget()

            '''
            widget callbacks
            '''
            #w.add_on_dirty_callback(partial(self.set_dirty, True))
            #w.add_on_dirty_callback(self.update_indicators)

            '''
            layout
            '''
            self.main_layout.addWidget(w, stretch=1)
            self.keyword_lookup[k] = w

        '''
        setup version box
        '''
        self.version_widget = self.get_matching_widget_for_key('version')
        if self.version_widget:
            self.version_widget.add_on_dirty_callback(self.on_version_combo_box_change)

        '''
        update blocking
        '''
        self.set_dirty(False)
        self.set_block_updates(False)


    def debugging(self, widget):
        '''
        indicator colors
        '''
        rgb = [1,1,1,0.5]  # white
        rgb = [int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255)]

        '''
        setup stylesheet
        '''
        styleSheet = ''

        '''
        background color
        '''
        styleElement = 'background-color: rgb({0},{1},{2},{3})'.format(*rgb)
        styleSheet += '{0};; '.format(styleElement)

        widget.setStyleSheet(styleSheet)

    def set_key(self, key):
        '''
        update blocking
        '''
        self.set_block_updates(True)

        '''
        store key
        '''
        self.data_key = key

        '''
        load json data internally
        '''
        data_value = {}
        try:
            data_value = Utils.FileUtils.read_json_file(self.data_key)
        except Exception as e:
            data_value = {}
        if not data_value:
            data_value = {}

        '''
        store
        '''
        self.set_value(data_value)

        '''
        update blocking
        '''
        self.set_dirty(False)
        self.set_block_updates(False)


    def update_to_widget(self):
        '''
        update blocking
        '''
        self.set_block_updates(True)

        '''
        data
        '''
        for (k, w) in self.keyword_lookup.items():
            value = self.get_value().get(k, 'NOT SET')
            w.set_block_updates(True)
            w.set_key(k)
            w.set_value(value)
            w.set_parent_data(self.get_value())
            w.update_to_widget()
            w.set_block_updates(False)


        '''
        setup version box
        '''
        #version_widget = self.get_matching_widget_for_key('version')
        if self.version_widget:
            '''
            block updates
            '''
            self.version_widget.set_block_updates(True)

            '''
            get potential version
            '''
            data_filepath = os.path.normpath(self.get_key())
            potential_versions = Utils.Core.get_potential_versions(data_filepath)
            #print(958, 'set_optional_value', potential_versions)
            self.set_optional_value(potential_versions)

            '''
            update combobox            
            '''
            versions = potential_versions.keys()
            self.version_widget.set_optional_value(versions)
            self.version_widget.update_to_widget()

            '''
            block updates
            '''
            self.version_widget.set_block_updates(False)

        '''
        update blocking
        '''
        self.set_dirty(False)
        self.set_all_dirty(False)
        self.set_block_updates(False)


    def on_version_combo_box_change(self, *args, **kwargs):
        if not self.get_block_updates():
            if self.version_widget:
                '''
                get data
                '''
                current_version = self.version_widget.get_value()
                version_data = self.get_optional_value()
                install_package = version_data.get(current_version, False)
                if not install_package:
                    return False

                '''
                install command
                '''
                #command = partial(Utils.install_package, filepaths = [install_package])
                command = partial(self.install_package, filepaths=[install_package])

                '''
                package file
                '''
                kwargs = {}
                kwargs['parentWidget'] = self
                kwargs['titleText'] = 'Install Package'
                kwargs['messageText'] = 'Install Version {0}'.format(current_version)
                kwargs['successCallback'] = command
                Utils.QTHelpers.getYesNoFromUser(**kwargs)

    def install_package(self, filepaths = []):
        '''
        install package
        '''
        Utils.Core.install_package(filepaths=filepaths)

        '''
        signal a change in version
        '''
        self.version_changed.emit()


class ButtonListWidgetViewer(DataWidgets.DataWidget, Qt.QtWidgets.QWidget):

    def __init__(self, *args, **kwargs):
        super(ButtonListWidgetViewer, self).__init__(*args, **kwargs)

    def do_layout(self):
        '''
        general sizing
        '''
        height = Utils.MayaUtils.get_dpi_scaled_value(60)

        '''
        layout
        '''
        page_layout = Qt.QtWidgets.QGridLayout(self)
        page_layout.setAlignment(Qt.QtCore.Qt.AlignLeading | Qt.QtCore.Qt.AlignTop)
        page_layout.setSpacing(10)
        page_layout.setContentsMargins(0,0,0,0)
        self.setFixedHeight(height)
        self.setLayout(page_layout)
        page_layout.setColumnStretch(2,1)

        '''
        button icon list
        '''
        self.button_list = Qt.QtWidgets.QToolBar(self)
        #self.button_list.setSizePolicy(Qt.QtWidgets.QSizePolicy.Maximum, Qt.QtWidgets.QSizePolicy.Expanding)
        size = Utils.MayaUtils.get_dpi_scaled_value(50)
        self.button_list.setIconSize(Qt.QtCore.QSize(size,size))
        page_layout.addWidget(self.button_list, 0, 2, 1, 1, Qt.QtCore.Qt.AlignLeft)

        '''
        callbacks
        '''
        self.add_on_dirty_callback(partial(self.update_indicators))

    def update_to_widget(self, dirty_state = False):
        '''
        clear list
        '''
        self.button_list.clear()

        '''
        get data
        '''
        value = self.get_value()

        '''
        set icons
        '''
        for i, d in enumerate(value):
            '''
            add image
            '''
            qpixmap = self.get_pixmap_for_data_icon(i)
            if not qpixmap:
                w = 32
                h = 32
                #rgb = [1, 1, .4, 1]  # yellow
                rgb = [0.847, .263, .145, 1]  # red
                qcolor = Qt.QtGui.QColor(int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255))
                qpixmap = PixoShop.Actions.qImageCanvas(width=w, height=h, fillColor=qcolor)
            qicon = PixoShop.Actions.convertToIcon(qpixmap)

            '''
            test toolbar
            '''
            w = Qt.QtWidgets.QToolButton()
            w.setToolTip('click to add to current shelf')
            w.clicked.connect(partial(self.on_click_button, i))
            w.setIcon(qicon)
            self.button_list.addWidget(w)

        '''
        dirty update
        '''
        self.set_dirty(dirty_state)

    def on_click_button(self, index):
        '''
        create button on active shelf
        '''
        active_shelf = Utils.MayaUtils.get_active_shelf()

        '''
        install command
        '''
        parent_data = self.get_parent_data()
        shelf_data = parent_data.get('shelf_data', [])
        if not shelf_data:
            return False
        button_data = shelf_data[index]
        button_description = button_data.get('short_name', 'Tool Name')
        command = partial(Utils.MayaUtils.create_shelf_button, target_shelf=active_shelf, button_data=button_data)

        '''
        ask to install button to active shelf
        '''
        titleText = 'Add Shelf Button?'
        messageText = 'Add "{0}" to {1}'.format(button_description, active_shelf)
        successCallback = command
        parentWidget = self
        Utils.QTHelpers.getYesNoFromUser(parentWidget=parentWidget, titleText=titleText, messageText=messageText,
                                           successCallback=successCallback)

    def get_pixmap_for_data_icon(self, shelf_button_index):
        data = self.get_parent_data()
        if not data:
            return False

        '''
        find icon in local folder
        '''
        root_path = Utils.Core.get_user_path()
        icon_filename = Utils.Core.get_icon_path_from_data(data, shelf_button_index = shelf_button_index, root_path=root_path)
        if not icon_filename:
            return False

        '''
        check if full path or shortpath
        '''
        if os.path.isfile(icon_filename):
            pixmap = PixoShop.Actions.loadPixmapFromPathSimple(icon_filename)
        else:
            pixmap = Utils.MayaUtils.getPixmapForPath(icon_filename)

        '''
        scale up to fit within 100x100
        '''
        target_dimension = 100
        longest_dimension = max(pixmap.width(), pixmap.height())
        scale_factor = target_dimension / float(longest_dimension)
        new_width = pixmap.width() * scale_factor
        new_height = pixmap.height() * scale_factor
        pixmap = pixmap.scaled(new_width, new_height, Qt.QtCore.Qt.KeepAspectRatio,
                                         Qt.QtCore.Qt.SmoothTransformation)

        return pixmap


