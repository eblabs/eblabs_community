import os
import re
import json
import string
import Scandir
import sys
import copy
import zipfile
from functools import partial
import shutil
from operator import itemgetter


from . import Prefs
from . import Qt
from . import DataTemplates
from . import eblabs_drag_drop_install

class PrefsManager(Prefs.PrefsManager):
    instance = False

    @classmethod
    def getInstance(cls):
        '''
        override this method to set prefs group
        '''
        if not cls.instance:
            kwargs = {}
            kwargs['prefsGroup'] = 'PackageManager'
            cls.instance = Prefs.Prefs(**kwargs)
        return cls.instance


class Misc(object):

    @classmethod
    def camel_case_to_label(cls, string_var):
        try:
            return_string = re.sub(r'((?<=[a-z])[A-Z]|(?<!\A)[A-Z](?=[a-z]))', r' \1', string_var)
            return_string = return_string.replace('_', ' ')
            return return_string
        except:
            return string_var


class FileUtils:

    @classmethod
    def touch(cls, path):
        '''
        create folder
        '''
        basedir = os.path.dirname(path)
        if not os.path.exists(basedir):
            os.makedirs(basedir)
        '''
        create empty file
        '''
        with open(path, 'a'):
            os.utime(path, None)

    @classmethod
    def validateText(cls, text, *args, **kwargs):
        if not text:
            return False
        validCharacters = "-_.(){0}{1}".format(string.ascii_letters, string.digits)
        validatedCharacters = []
        for c in text:
            # replace space with underscore
            if c == ' ':
                c = '_'
            # filter non valid characters
            if c in validCharacters:
                validatedCharacters.append(c)
        # return result
        validatedText = ''.join(validatedCharacters)
        return validatedText

    @classmethod
    def getFileNameParts(cls, filepath, *args, **kwargs):
        if not filepath:
            return False
        folderName, filename = os.path.split(filepath)
        baseFileName, fileExtension = os.path.splitext(filename)
        fileExtension = fileExtension[1:]  # remove period
        return folderName, baseFileName, fileExtension

    @classmethod
    def getFilesInFolder(cls, path, extensions, recursive = True):
        fileList = []
        #print(2869, path, extensions, recursive)
        if path:
            if os.path.exists(path):
                for entry in Scandir.scandir(path):
                    fileCheckList = []
                    if entry.is_dir(follow_symlinks=False):
                        if recursive:
                            fileCheckList += cls.getFilesInFolder(entry.path, extensions, recursive)
                    else:
                        fileCheckList += [entry.path]
                    matchFound = False
                    if fileCheckList:
                        for f in fileCheckList:
                            if extensions:
                                for extension in extensions:
                                    if f.endswith(extension):
                                        fileList.append(os.path.normpath(f))
                                        matchFound = True
                                        break
                            else:
                                fileList.append(os.path.normpath(f))
        return fileList

    @classmethod
    def get_sub_folders(cls, path, *args, **kwargs):
        folders = []
        if path and os.path.exists(path):
            for entry in Scandir.scandir(path):
                if not entry.name.startswith('.') and entry.is_dir():
                    folders.append(entry.name)
        return folders

    @classmethod
    def read_json_file(cls, filepath):
        try:
            with open(filepath, 'r') as f:
                data = json.loads(f.read())
                return data
        except:
            return False

    @classmethod
    def write_json_file(cls, filepath, data):
        try:
            '''
            write data
            '''
            data = json.dumps(data, sort_keys=True, indent=4)
            with open(filepath, 'w') as f:
                f.write(data)
        except:
            return False

    @classmethod
    def browseFolder(cls, path):
        if path:
            if sys.platform == "win32":
                    os.startfile(path)
            elif sys.platform == "Darwin":
                os.system(["open", path])
            else:
                os.system('xdg-open "{0}"'.format(path))

    @classmethod
    def split_path_all(cls, path):
        allparts = []
        while 1:
            parts = os.path.split(path)
            if parts[0] == path:  # sentinel for absolute paths
                allparts.insert(0, parts[0])
                break
            elif parts[1] == path: # sentinel for relative paths
                allparts.insert(0, parts[1])
                break
            else:
                path = parts[0]
                allparts.insert(0, parts[1])
        return allparts

    @classmethod
    def get_dev_path(cls):
        scripts_path = MayaUtils.get_scripts_path()
        default_value = os.path.normpath(os.path.join(scripts_path, 'scripts', 'eblabs_hub'))
        path = PrefsManager.getProperty('install_path', default_value)
        return path

    @classmethod
    def get_user_path(cls):
        return PrefsManager.getProperty('dev_folder', False)

class MayaUtils(object):

    resourceCache = False
    shelfIconLookup = {}
    shelfIconPaths = []

    try:
        from maya import cmds
        from maya import mel
        maya_loaded = True
    except:
        maya_loaded = False

    @classmethod
    def is_maya_loaded(cls):
        return cls.maya_loaded

    @classmethod
    def get_user_app_dir_path(cls):
        if not cls.is_maya_loaded():
            return False
        return cls.cmds.internalVar(userAppDir=True)

    @classmethod
    def remove_package_buttons_from_shelf(cls, shelf, package_id):
        if not cls.is_maya_loaded():
            return False
        '''
        look up buttons
        '''
        remove_shelf_buttons = cls.get_package_buttons_from_shelf(shelf, package_id)
        if not remove_shelf_buttons:
            return False
        '''
        delete
        '''
        cls.cmds.deleteUI(*remove_shelf_buttons, control=True)


    @classmethod
    def get_package_buttons_from_shelf(cls, shelf, package_id):
        if not cls.is_maya_loaded():
            return False
        '''
        set active shelf
        '''
        cls.set_active_shelf(shelf)

        '''
        check that shelf exists
        '''
        if not cls.cmds.shelfLayout(shelf, exists=True, query=True):
            return []

        '''
        iterate through child buttons of shelf
        '''
        matching_buttons = []
        child_array = cls.cmds.shelfLayout(shelf, query=True, childArray=True, fullPathName=True)
        if not child_array:
            return []
        for shelf_button in child_array:
            command_str = cls.cmds.shelfButton(shelf_button, query=True, command=True)
            '''
            check package_id
            '''
            split_lines = command_str.splitlines()
            for line in split_lines:
                '''
                isolate package_id line
                '''
                match = Core.are_all_strings_in_string(line, ['package_id', '='])
                if match:
                    '''
                    check package_id value
                    '''
                    component, component_value = line.split('=')
                    component_type, component_value = Core.inspect_component(component_value)
                    if component_value == package_id:
                        if shelf_button not in matching_buttons:
                            matching_buttons.append(shelf_button)
                            break
        '''
        results
        '''
        return matching_buttons

    @classmethod
    def get_active_shelf(cls):
        if not cls.is_maya_loaded():
            return False
        parent = cls.mel.eval("global string $gShelfTopLevel; $temp = $gShelfTopLevel;")
        active_tab = cls.cmds.tabLayout(parent, query=True, selectTab=True)
        return active_tab

    @classmethod
    def set_active_shelf(cls, shelf):
        if not cls.is_maya_loaded():
            return False
        '''
        create if it doesnt exist
        '''
        cls.create_shelf(shelf)

    @classmethod
    def create_shelf(cls, shelf):
        if not cls.is_maya_loaded():
            return False
        '''
        create shelf if it doesnt exist
        '''
        parent = cls.mel.eval("global string $gShelfTopLevel; $temp = $gShelfTopLevel;")
        if not cls.cmds.shelfLayout(shelf, exists=True, query=True):
            # trying mel to avoid odd race condition
            #mel.eval('if (!`shelfLayout -exists {0} `) deleteUI {0};'.format(shelf))
            #mel.eval('if (!`shelfLayout -exists {0} `) ${0} = `shelfLayout -cellHeight 32 -p $gShelfTopLevel {0}`;'.format(shelf))
            cls.mel.eval('${0} = `shelfLayout -cellHeight 32 -p $gShelfTopLevel {0}`;'.format(shelf))

        '''
        set active shelf
        '''
        cls.cmds.tabLayout(parent, edit=True, selectTab=shelf)

    @classmethod
    def get_dpi_scaling(cls):
        value = 1
        try:
            if cls.is_maya_loaded():
                value = cls.cmds.mayaDpiSetting( query=True, realScaleValue=True )
        except:
            pass
        return value

    @classmethod
    def get_dpi_scaled_value(cls, v):
        value = v
        if cls.is_maya_loaded():
            try:
                value = v * cls.get_dpi_scaling()
            except:
                pass
        return value


    @classmethod
    def create_shelf_button(cls, target_shelf = False, button_data = False):
        print(button_data)
        '''
        annotation
        '''
        button_annotation = button_data['annotation']

        '''
        children/popups 
        '''
        button_popups = button_data['children']

        '''
        icon
        '''
        icon_path = button_data['icon']['image']

        '''
        overlay label
        '''
        icon_label = button_data['icon']['label']

        '''
        list label
        '''
        list_label = button_data['shortName']

        '''
        command
        '''
        try:
            button_command_data = button_data['command_data']
        except:
            button_command_data = DataTemplates.Templates.getCommandTemplate()
        button_command = button_command_data['command']
        button_source_type = button_command_data['sourceType']

        '''
        get target shelf
        '''
        parent = cls.cmds.shelfLayout(target_shelf, query=True, fullPathName=True)
        # make button
        button_data = cls.cmds.shelfButton(parent =parent,  annotation=button_annotation, image=icon_path, image1=icon_path, c=button_command,
                                       sourceType=button_source_type)
        cls.cmds.shelfButton(button_data, edit=True, imageOverlayLabel=icon_label)
        cls.cmds.shelfButton(button_data, edit=True, label=list_label)

        # add popups
        if button_popups:
            popMenu = cls.cmds.popupMenu(button_data, button=3)
            for popupItem in button_popups:
                #Core.pretty_print(popupItem)
                popupLabel = popupItem['shortName']

                command_data = popupItem.get('command_data', {})
                popupCommand = command_data.get('command', '')
                popupSourceType = command_data.get('sourceType', 'python')
                item_type = popupItem.get('type', False)

                # black list commands
                blackList = ['Delete', 'Edit Popup', 'Open', 'Edit']
                if popupLabel not in blackList:
                    # dividers
                    if item_type == 'divider':
                        cls.cmds.menuItem(parent=popMenu, divider=True)

                    # regular items
                    elif item_type == 'menuItem':
                        cls.cmds.menuItem(parent=popMenu, label=popupLabel, command=popupCommand, sourceType=popupSourceType)

                    # submenus, TODO
                    '''
                    if item_type == 'subMenu':
                        submenuParent = cls.cmds.menuItem(parent=popMenu, submenu=True, label=popupLabel)
                        for si in popupSubmenu:
                            si_label = si['label']
                            si_command = si['command']
                            si_sourceType = si['sourceType']

                            # black list
                            if si_label not in blackList:
                                # make the submenu item
                                cls.cmds.menuItem(parent=submenuParent, label=popupLabel, command=si_command,
                                              sourceType=si_sourceType)
                    '''


    @classmethod
    def sort_buttons_on_shelf(cls, shelf, priority_ids):
        def get_sort_template():
            t = {}
            t['package_id'] = ''
            t['priority'] = 0
            t['button'] = ''
            return t

        '''
        get all buttons
        '''
        all_button_info = cls.get_all_buttons_from_shelf(shelf)
        #Utils.pretty_print(all_button_info)
        if not all_button_info:
            return False

        '''
        prepare
        '''
        button_data = []
        for package_id, button in all_button_info:
            d = get_sort_template()
            d['package_id'] = package_id
            d['button'] = button

            '''
            priority
            '''
            if package_id in priority_ids:
                d['priority'] = 0
            else:
                d['priority'] = 1

            '''
            '''
            button_data.append(d)

        '''
        sort data
        '''
        sorted_button_data = sorted(button_data, key=itemgetter('priority', 'package_id'))
        #Utils.pretty_print(sorted_button_data)

        '''
        shuffle shelf buttons
        '''
        for data in reversed(sorted_button_data):
            #print(data['id'])
            '''
            button
            '''
            button = data['button']
            '''
            move to front
            '''
            cls.cmds.shelfLayout(shelf, edit=True, position=(button, 1))

        '''
        save prefs
        '''
        #cls.savePrefs()

    @classmethod
    def get_all_buttons_from_shelf(cls, shelf):
        '''
        set active shelf
        '''
        cls.set_active_shelf(shelf)

        '''
        check that shelf exists
        '''
        if not cls.cmds.shelfLayout(shelf, exists=True, query=True):
            return []

        '''
        iterate through child buttons of shelf
        '''
        buttons_data = []
        child_array = cls.cmds.shelfLayout(shelf, query=True, childArray=True, fullPathName=True)
        if not child_array:
            return []
        for shelf_button in child_array:
            command_str = cls.cmds.shelfButton(shelf_button, query=True, command=True)
            '''
            check package_id
            '''
            split_lines = command_str.splitlines()
            for line in split_lines:
                '''
                isolate package_id line
                '''
                match = Core.are_all_strings_in_string(line, ['package_id', '='])
                if match:
                    '''
                    check package_id value
                    '''
                    component, component_value = line.split('=')
                    component_type, component_value = Core.inspect_component(component_value)
                    '''
                    store
                    '''
                    buttons_data.append([component_value, shelf_button])
                    break
        '''
        results
        '''
        return buttons_data

    @classmethod
    def get_package_buttons_from_shelf(cls, shelf, package_id):
        '''
        set active shelf
        '''
        cls.set_active_shelf(shelf)

        '''
        check that shelf exists
        '''
        if not cls.cmds.shelfLayout(shelf, exists=True, query=True):
            return []

        '''
        iterate through child buttons of shelf
        '''
        matching_buttons = []
        child_array = cls.cmds.shelfLayout(shelf, query=True, childArray=True, fullPathName=True)
        if not child_array:
            return []
        for shelf_button in child_array:
            command_str = cls.cmds.shelfButton(shelf_button, query=True, command=True)
            '''
            check package_id
            '''
            split_lines = command_str.splitlines()
            for line in split_lines:
                '''
                isolate package_id line
                '''
                match = Core.are_all_strings_in_string(line, ['package_id', '='])
                if match:
                    '''
                    check package_id value
                    '''
                    component, component_value = line.split('=')
                    component_type, component_value = Core.inspect_component(component_value)
                    if component_value == package_id:
                        if shelf_button not in matching_buttons:
                            matching_buttons.append(shelf_button)
                            break
        '''
        results
        '''
        return matching_buttons

    @classmethod
    def savePrefs(cls):
        if cls.is_maya_loaded():
            cls.cmds.savePrefs()

    @classmethod
    def getPixmapForPath(cls, fullPathVar):
        # clean path
        path = os.path.split(fullPathVar)[-1]

        # prepare return
        returnPixmap = False

        # init
        try:
            cls.pixmapLookupCache
        except:
            cls.pixmapLookupCache = {}

        # lookup and return
        if path in cls.pixmapLookupCache and cls.pixmapLookupCache[path]:
            return cls.pixmapLookupCache[path]

        # cache resource info
        if not cls.resourceCache:
            cls.resourceCache = cls.resourceManager(nameFilter='*')

        # native icons
        # isNative = cls.resourceManager(nameFilter=path)
        isNative = False
        if path in cls.resourceCache:
            isNative = True
        if isNative:
            pixmap = Qt.QtGui.QPixmap(':/{0}'.format(path))
            if pixmap.width():
                cls.pixmapLookupCache[path] = pixmap

        # non native
        if path not in cls.pixmapLookupCache.keys() or not cls.pixmapLookupCache[path]:
            fullpath = cls.findIconFullImagePath(path)
            if fullpath:
                if os.path.isfile(fullpath):
                    pixmap = Qt.QtGui.QPixmap(fullpath)
                    if pixmap.width():
                        cls.pixmapLookupCache[path] = pixmap
            else:
                '''
                for paths not in icon directory
                '''
                pixmap = Qt.QtGui.QPixmap(fullPathVar)
                if pixmap.width():
                    cls.pixmapLookupCache[path] = pixmap
                else:
                    #print('PixMapPathNotFound', path)
                    pass

        # fallback
        if path not in cls.pixmapLookupCache.keys() or not cls.pixmapLookupCache[path]:
            color = [0.847, 0.263, 0.145]  # red
            color = [int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)]
            pixMap = Qt.QtGui.QPixmap(100, 100)  # pixMap
            pixMap.fill(Qt.QtGui.QColor(*color))  #
            cls.pixmapLookupCache[path] = pixMap

        # return
        return cls.pixmapLookupCache[path]

    @classmethod
    def resourceManager(cls, *args, **kwargs):
        if not cls.is_maya_loaded():
            return False
        return cls.cmds.resourceManager(*args, **kwargs)

    @classmethod
    def findIconFullImagePath(cls, path, *args, **kwargs):
        # cache image paths
        if not cls.shelfIconPaths:
            cls.shelfIconPaths = cls.getShelfIconPaths()
            cls.shelfIconLookup = {}

        # load images
        if not cls.shelfIconLookup:
            imageFiles = []
            for shelfIconPath in cls.shelfIconPaths:
                imageFiles += FileUtils.getFilesInFolder(shelfIconPath, ['png', 'jpg'])
            for imageFile in imageFiles:
                shortName = os.path.split(imageFile)[-1]
                shortName = shortName.lower()
                if shortName not in cls.shelfIconLookup.keys():
                    cls.shelfIconLookup[shortName] = []
                cls.shelfIconLookup[shortName].append(imageFile)

        # return
        lowercasepath = path.lower()
        if lowercasepath in cls.shelfIconLookup.keys():
            return cls.shelfIconLookup[lowercasepath][0]
        else:
            return False

    @classmethod
    def getShelfIconPaths(cls, *args, **kwargs):
        iconPathsString = cls.getIconPaths()
        iconDirs = []
        if iconPathsString:
            # determine split string
            splitString = ''
            if '%B' in iconPathsString:
                splitString = '%B'
            elif ';' in iconPathsString:
                splitString = ';'

            # cleanup
            for path in iconPathsString.split(splitString):
                # remove leading ':'
                if path.startswith(':'):
                    path = path[1:]

                #
                if len(path) <= 1:
                    continue

                # norm path
                path = os.path.normpath(path)

                # add path
                iconDirs.append(path)

        return iconDirs

    @classmethod
    def getIconPaths(cls):
        if not cls.is_maya_loaded():
            return False
        return cls.mel.eval('string $iconPaths = `getenv XBMLANGPATH`')

class QTHelpers():

    @classmethod
    def get_key_modifiers(cls):
        QModifiers = Qt.QtWidgets.QApplication.keyboardModifiers()
        modifiers = []
        if (QModifiers & Qt.QtCore.Qt.ShiftModifier) == Qt.QtCore.Qt.ShiftModifier:
            modifiers.append('shift')
        if (QModifiers & Qt.QtCore.Qt.ControlModifier) == Qt.QtCore.Qt.ControlModifier:
            modifiers.append('control')
        if (QModifiers & Qt.QtCore.Qt.AltModifier) == Qt.QtCore.Qt.AltModifier:
            modifiers.append('alt')
        return modifiers

    @classmethod
    def getStringFromUser(cls, parentWidget = False, titleText = 'Input Dialog', labelText = 'Input Below', successCallbacks = []):
        '''
        ask the user to provide a string
        '''
        # get input from user
        returnText, okState = Qt.QtWidgets.QInputDialog.getText(parentWidget, titleText, labelText)
        if okState and returnText:
            '''
            run callbacks
            '''
            if successCallbacks:
                for c in successCallbacks:
                    try:
                        c(returnText)
                    except:
                        pass

    @classmethod
    def getYesNoFromUser(cls, parentWidget = False, titleText = 'Title Text', messageText = 'Message Text', successCallback = False):
        '''
        ask the user to click yes or no
        '''
        reply = Qt.QtWidgets.QMessageBox.question(parentWidget, titleText, messageText, Qt.QtWidgets.QMessageBox.Yes | Qt.QtWidgets.QMessageBox.No, Qt.QtWidgets.QMessageBox.No)
        if reply == Qt.QtWidgets.QMessageBox.Yes:
            '''
            run callback
            '''
            try:
                if successCallback:
                    successCallback()
            except:
                pass

    @classmethod
    def get_files_from_user(cls, parent_widget=False, file_types='Archive (*.zip)', title='window title',
                            target_folder=False, allow_multiples = True):
        '''
        setup parent
        '''
        if not parent_widget:
            parent_widget = cls.get_main_window()
        '''
        target folder
        '''
        if not target_folder:
            target_folder = Qt.QtCore.QDir.currentPath()

        '''
        get filepath from user
        '''
        filepaths = []
        if allow_multiples:
            filepaths = Qt.QtWidgets.QFileDialog.getOpenFileNames(parent_widget, title, target_folder, file_types)
        else:
            filepaths = Qt.QtWidgets.QFileDialog.getOpenFileName(parent_widget, title, target_folder, file_types)
            if filepaths:
                filepaths = [filepaths]

        '''
        remove filepath list from tupple
        (['filepathA.txt', 'filepathB.txt'], u'Text Files (*.txt)'))
        '''
        if filepaths:
            filepaths = filepaths[0]
        '''
        return
        '''
        return filepaths

    @classmethod
    def get_folder_from_user(cls, parent_widget=False, title='window title', target_folder=False):
        '''
        setup parent
        '''
        if not parent_widget:
            parent_widget = cls.get_main_window()
        '''
        target folder
        '''
        if not target_folder:
            target_folder = Qt.QtCore.QDir.currentPath()

        '''
        get filepath from user
        '''
        filepath = Qt.QtWidgets.QFileDialog.getExistingDirectory(None, title, target_folder, Qt.QtWidgets.QFileDialog.ShowDirsOnly)
        '''
        return
        '''
        return filepath

    @classmethod
    def get_main_window(cls):
        """Return Maya's main window"""
        for obj in Qt.QtWidgets.QApplication.instance().topLevelWidgets():
            if obj.objectName() == 'MayaWindow':
                return obj

        return False

class VBoxLayout(Qt.QtWidgets.QVBoxLayout):

    def __init__(self, *args, **kwargs):
        #
        super(VBoxLayout, self).__init__(*args, **kwargs)

        self.setSpacing(0)
        self.setContentsMargins(0, 0, 0, 0)

class GridLayout(Qt.QtWidgets.QGridLayout):

    def __init__(self, *args, **kwargs):
        #
        super(GridLayout, self).__init__(*args, **kwargs)

        self.setSpacing(2)
        self.setContentsMargins(3, 3, 3, 3)

class StackedLayout(Qt.QtWidgets.QStackedLayout):

    def __init__(self, *args, **kwargs):
        #
        super(StackedLayout, self).__init__(*args, **kwargs)

        self.setSpacing(0)
        self.setContentsMargins(0, 0, 0, 0)

class Core:

    @classmethod
    def install_package(cls, for_real = True, filepaths = False, callback = False):
        '''
        ask user for package
        '''
        target_folder = PrefsManager.getProperty('target_folder', False)
        if not filepaths:
            filepaths = QTHelpers.get_files_from_user(title='Open eblabs Package (*.zip)', target_folder=target_folder)
            if not filepaths:
                return False

        '''
        store path in prefs, for auto suggesting next time
        '''
        if filepaths:
            token_filepath = filepaths[0]
            folder_path = False
            if os.path.isdir(token_filepath):
                folder_path = token_filepath
            elif os.path.isfile(token_filepath):
                folder_path = os.path.dirname(token_filepath)
            if folder_path:
                PrefsManager.setProperty('target_folder', folder_path)

        '''
        batch
        * todo: optimize confirmations to only ask the user once
        '''
        SummaryManager.reset()
        for filepath in filepaths:
            '''
            validate package
            '''
            data = cls.validate_package(filepath)
            if not data:
                #print('Checking Package, Not Valid: ', filepath)
                continue
            else:
                #print('Checking Package, Is Valid: ', data)
                pass

            '''
            allow for dry runs
            '''
            if for_real:
                '''
                remove old contents, ask user if ok
                also remove old shelf buttons
                '''
                cls.pre_install_cleanup(data)


                '''
                unpack zip file into folders
                '''
                data = cls.unpack_package(filepath, data)

                '''
                create eblabs shelf if not there
                '''
                shelf = cls.get_user_shelf_name()
                MayaUtils.create_shelf(shelf)

                '''
                add new buttons
                '''
                shelf_data = data.get('shelf_data', [])
                if shelf_data:
                    for button_data in shelf_data:
                        MayaUtils.create_shelf_button(target_shelf=shelf, button_data=button_data)


                '''
                ##### Summary #####
                * Package Name, Version
                * path
                * does path exist
                * list contents of path
                '''
                package_name = data.get('package', 'PACKAGE?')
                package_version = data.get('version', 'VERSION?')
                root_install_path = cls.get_user_path()
                package_id = data['package_id']
                package_install_path = os.path.normpath(os.path.join(root_install_path, package_id))
                package_install_path_exists = os.path.exists(package_install_path)
                package_path_contents = FileUtils.getFilesInFolder(package_install_path, False)
                SummaryManager.set_versions(version=package_version, version_date=' ')
                SummaryManager.append_item('Summary: {0}, {1}'.format(package_name, package_version), new_group=True)
                SummaryManager.append_item('Path: {0}'.format(package_install_path))
                SummaryManager.append_item('Exists: {0}'.format(package_install_path_exists))
                SummaryManager.append_item('Files List:')
                if package_path_contents:
                    for p in package_path_contents:
                        SummaryManager.append_item('{0}'.format(p))
        '''
        store prefs
        '''
        if for_real and filepaths:
            shelf = cls.get_user_shelf_name()
            MayaUtils.sort_buttons_on_shelf(shelf, ['PackageManager'])
            MayaUtils.savePrefs()

        '''
        summary
        '''
        SummaryManager.print_summary()

        '''
        callback
        '''
        if callback:
            try:
                callback()
            except:
                pass

    @classmethod
    def get_potential_versions(cls, filepath):
        '''
        find local install paths based on installed version
        '''
        filepath = os.path.normpath(filepath)
        split_path = FileUtils.split_path_all(filepath)
        #split_path = filepath.split(os.sep)
        split_path = list(filter(None, split_path))
        split_path = split_path[:-2] # remove 'data', 'eblabs.data'
        split_path.append('versions')
        folder_path = os.path.normpath(os.path.join(*split_path ))

        '''
        get zip files
        '''
        zip_files = FileUtils.getFilesInFolder(folder_path, ['zip'])

        '''
        data
        '''
        version_data = {}
        for zip_file in zip_files:
            data = cls.get_data_file_from_archive(zip_file)
            version = False
            try:
                version = data['version']
            except:
                continue
            if version:
                version_data[version] = zip_file

        '''
        '''
        return version_data

    @classmethod
    def modify_nested_data(cls, obj, modify_function, key=False):
        """
        Recursively goes through the dictionary obj and replaces keys with the modify_function function.
        https://stackoverflow.com/questions/11700705/python-recursively-replace-character-in-keys-of-nested-dictionary
        """
        if isinstance(obj, (str, int, float)):
            return modify_function(key, obj)
        if isinstance(obj, dict):
            new = obj.__class__()
            for k, v in obj.items():
                new[k] = cls.modify_nested_data(modify_function(k, v), modify_function, key=k)
        elif isinstance(obj, (list, set, tuple)):
            new = obj.__class__(cls.modify_nested_data(modify_function(key, v), modify_function, key=False) for v in obj)
        else:
            return modify_function(key, obj)
        return new

    @classmethod
    def localize_images_paths(cls, data, root_path=False):
        '''
        pull out shelf data
        '''
        shelf_data = data.get('shelf_data', [])
        if not shelf_data:
            return data

        '''
        rebuild new shelf data
        '''
        new_shelf_data = []
        for i in range(len(shelf_data)):
            button_data = copy.deepcopy(shelf_data[i])
            button_data['icon']['image'] = cls.get_icon_path_from_data(data, i, root_path = root_path)
            new_shelf_data.append(button_data)

        '''
        replace
        '''
        data['shelf_data'] = copy.deepcopy(new_shelf_data)

        return data

    @classmethod
    def localize_scripts_paths(cls, data, root_path = False):
        '''
        recursively search through data for 'command
        '''
        replace_data = {}
        replace_data['root_path'] = root_path
        replace_data['package_id'] = data['package_id']

        data = cls.modify_nested_data(data, partial(cls.localize_scripts_paths_modify_function, replace_data))

        return data

    @classmethod
    def localize_scripts_paths_modify_function(cls, replace_data, key, value):
        root_path = replace_data['root_path']
        package_id = replace_data['package_id']
        if key == 'command':
            #print(2163, type(value), root_path, value, package_id)
            if isinstance(value, (str, unicode)):
                value = cls.localize_script_paths_string_processing(root_path, value, package_id)
        return value

    @classmethod
    def localize_script_paths_string_processing(cls, root_path, script_string, package_id):
        '''
        make replacements
        split into lines
        '''
        split_lines = script_string.splitlines()
        new_lines = []
        for line in split_lines:
            '''
            looking for: 
            install_path = ''
            package_id = 'myTool'
            '''
            if cls.are_all_strings_in_string(line, ['install_path', '=']):
                line = "install_path = '{0}'".format(root_path)
            elif cls.are_all_strings_in_string(line, ['package_id', '=']):
                line = "package_id = '{0}'".format(package_id)

            '''
            assemble
            '''
            new_lines.append(line)

        '''
        assemble
        '''
        split_lines = '\n'.join(new_lines)
        return split_lines

    @classmethod
    def unpack_package(cls, filepath, data):
        '''
        define folder names
        '''
        filepath = os.path.normpath(filepath)
        root_install_path = cls.get_user_path()
        package_id = data['package_id']
        package_install_path = os.path.normpath(os.path.join(root_install_path, package_id))

        '''
        store a copy locally
        '''
        versions_folder = os.path.normpath(os.path.join(package_install_path, 'versions'))
        version_file = os.path.normpath(os.path.join(package_install_path, 'versions', os.path.basename(filepath)))
        if not os.path.exists(versions_folder):
            os.makedirs(versions_folder)
        if version_file != filepath:
            shutil.copy2(filepath, version_file)

        '''
        unzip into install path
        '''
        with zipfile.ZipFile(filepath, 'r') as z:
            z.extractall(package_install_path)

        '''
        add init files
        '''
        init_files = []
        path = os.path.normpath(os.path.join(package_install_path, '__init__.py'))
        init_files.append(path)
        path = os.path.normpath(os.path.join(package_install_path, 'scripts', '__init__.py'))
        init_files.append(path)
        for f in init_files:
            if not os.path.isfile(f):
                FileUtils.touch(f)

        '''
        modify icon paths
        '''
        data = cls.localize_images_paths(data, root_path=cls.get_user_path())
        data = cls.localize_scripts_paths(data, root_path=cls.get_user_path())

        '''
        write updated data file
        '''
        path = os.path.normpath(os.path.join(package_install_path, 'data', 'eblabs.data'))
        FileUtils.write_json_file(path, data)

        '''
        return 
        '''
        return data

    @classmethod
    def pre_install_cleanup(cls, data):
        '''
        define folder names
        '''
        root_install_path = cls.get_user_path()
        package_install_path = os.path.normpath(os.path.join(root_install_path, data['package_id']))

        '''
        remove previous version if there
        todo, ask if user wants to update, show change of versions
        '''
        previous_data_filepath = os.path.normpath(os.path.join(package_install_path, 'data', 'eblabs.data'))
        previous_data = FileUtils.read_json_file(previous_data_filepath)
        if previous_data:
            '''
            todo, 
            '''
            #print(170, 'Previous Data Exists, todo, ask user for downgrade? ', previous_data)

        '''
        remove old data
        '''
        core_folders = DataTemplates.Templates.get_core_folders_list()
        for core_folder in core_folders:
            remove_path = os.path.normpath(os.path.join(package_install_path, core_folder))
            if os.path.exists(remove_path):
                try:
                    shutil.rmtree(remove_path)
                    #print(174, 'Cleaning Up Folder: ', remove_path)
                except Exception as e:
                    #print(175, 'Unable to remove Previous Install', remove_path, Exception, e)
                    return False

        '''
        generate new folders
        '''
        try:
            if not os.path.exists(package_install_path):
                os.makedirs(package_install_path)
                #print(186, 'Generating Folder: ', package_install_path)
        except Exception as e:
            #print(185, 'generate new folders FAILED', Exception, e)
            return False

        '''
        remove old shelf buttons
        todo
        '''
        shelf = cls.get_user_shelf_name()
        package_id = data['package_id']
        MayaUtils.remove_package_buttons_from_shelf(shelf, package_id)

    @classmethod
    def validate_package(cls, filepath):
        '''
        makes sure that:
        1. data file is readable
        2. has correct folders
        '''
        required_folder_list = DataTemplates.Templates.get_core_folders_list()
        data = False
        try:
            data = cls.get_data_file_from_archive(filepath)
        except Exception as e:
            #print(130, Exception, e)
            return False
        if not data:
            return False
        '''
        check file contents
        '''
        archive_contents = cls.list_zip_file_contents(filepath)
        folder_names = []
        for zinfo in archive_contents:
            filename = zinfo.filename
            folder_name, base_file_name, file_extension = FileUtils.getFileNameParts(filename)
            if folder_name in required_folder_list:
                #folder_name = os.path.basename(os.path.normpath(filename))
                folder_names.append(folder_name)

        '''
        check that all members are present
        subset comparisons
        https://stackoverflow.com/questions/16579085/python-verifying-if-one-list-is-a-subset-of-the-other
        '''
        if not set(required_folder_list) <= set(folder_names):
            #print(1861, 'required_folder_list FAIL', required_folder_list, folder_names)
            return False

        '''
        ok all good, return data
        '''
        return data

    @classmethod
    def get_data_file_from_archive(cls, filepath):
        '''
        check that the file exists
        '''
        json_data = False
        if filepath and os.path.isfile(filepath):
            '''
            examine file
            '''
            with zipfile.ZipFile(filepath) as z:
                '''
                itterate members
                '''
                for finfo in z.infolist():
                    '''
                    skip folders, last part of filename will be '' if a folder
                    '''
                    filename = finfo.filename
                    path_parts = filename.split(os.sep)
                    # print path_parts
                    if path_parts[-1]:  # skip folders
                        '''
                        find data file
                        '''
                        if finfo.filename == 'data/eblabs.data':
                            with z.open(finfo) as zfile:
                                '''
                                extract json data
                                '''
                                json_data = json.loads(zfile.read())
        '''
        return
        '''
        return json_data

    @classmethod
    def list_zip_file_contents(cls, filepath):
        '''
        check that the file exists
        '''
        finfo_list = []
        if filepath and os.path.isfile(filepath):
            '''
            examine file
            '''
            with zipfile.ZipFile(filepath) as z:
                '''
                iterate members
                '''
                for finfo in z.infolist():
                    '''
                    skip folders, last part of filename will be '' if a folder
                    '''
                    #filename = finfo.filename
                    #pathParts = filename.split(os.sep)
                    # print pathParts
                    # if pathParts[-1]:  # skip folders
                    '''
                    store finfo
                    '''
                    finfo_list.append(finfo)

        '''
        return
        '''
        return finfo_list


    @classmethod
    def get_packages_basic_info(cls, root_path=False):
        '''
        get working path, either for user or dev
        '''
        if not root_path:
            return False
        if not os.path.exists(root_path):
            return False

        '''
        get list of folders
        '''
        sub_folders = FileUtils.get_sub_folders(root_path)

        '''
        get data file for each path
        '''
        data_file_basic_info = []
        for sub_folder in sub_folders:
            data_file_path = os.path.normpath(os.path.join(root_path, sub_folder, 'data', 'eblabs.data'))
            data_file_basic_info.append([sub_folder, data_file_path])

        return data_file_basic_info

    @classmethod
    def get_icon_path_from_data(cls, data, shelf_button_index = 0, root_path = False):
        '''
        icon path
        '''
        #(1998, <type 'exceptions.Exception'>, TypeError('list indices must be integers, not str',), {u'description': u'tool for doing xyz', u'package': u'World Space Tools', u'shelf_data': [{u'color': [0.2, 0.2, 0.2], u'children': [{u'command_data': [{u'sourceType': u'python', u'altCommand': u'', u'command': u"\npath = '/u/ecb/Pictures/eblabs-hub/'\n\nimport os\nimport sys\nif not path in sys.path:\n    sys.path.append(path)\n\nimport eblabs_hub.WorldSpaceTools.scripts.worldspace as tool\n\ntool.window.load()", u'longName': u'', u'shortName': u'', u'annotation': u''}], u'tags': [u'modelingMenuSet'], u'color': [0.388, 0.737, 0.808, 1], u'type': u'standardButton', u'children': [], u'subType': u'', u'longName': u'', u'id': u'31668d5c3afb4600bd45afba600e5fe7', u'shortName': u'World Space Tools', u'data': {}, u'annotation': u'', u'icon': {u'image': u'/u/ecb/Pictures/eblabs-hub/eblabs_hub/WorldSpaceTools/images/eblabs_worldSpaceTools.png', u'label': u''}}], u'subType': u'', u'longName': u'', u'shortName': u'', u'type': u'root', u'annotation': u''}], u'legacy': [], u'package_id': u'WorldSpaceTools', u'version': u'1.5'})
        try:
            icon_filename = data['shelf_data'][shelf_button_index]['icon']['image']
        except Exception as e:
            #print(1998, Exception, e, data)
            #print (traceback.format_exc())
            return False
        try:
            package_folder = data['package_id']
        except Exception as e:
            #print(2003, Exception, e)
            return False

        '''
        filename parts
        '''
        folderName, baseFileName, fileExtension = FileUtils.getFileNameParts(icon_filename)

        '''
        calculate path
        '''
        #root_path = Utils.get_working_path( mode = mode)
        #print(2657, mode, 'root_path, package_folder, baseFileName, fileExtension')
        #print(2658, root_path, package_folder, baseFileName, fileExtension)
        file_path = os.path.normpath(os.path.join(root_path, package_folder, 'images', '{0}.{1}'.format(baseFileName, fileExtension)))

        '''
        check if full path or shortpath
        '''
        if os.path.isfile(file_path):
            return file_path
        else:
            return '{0}.{1}'.format(baseFileName, fileExtension)

    @classmethod
    def get_user_shelf_name(cls):
        return 'eblabs_HUB'

    @classmethod
    def are_all_strings_in_string(cls, str_item, str_list):
        return all(s in str_item for s in str_list)

    @classmethod
    def inspect_component(cls, component):
        '''
        prep returns
        '''
        component_type = ''
        component_cleaned = ''

        '''
        validate
        '''
        if component is None:
            return False

        '''
        break down component
        '''
        component = str(component).strip()
        component_cleaned = eval(component)

        '''
        type check
        '''
        type_check = ''
        try:
            type_check = type(eval(component))
        except:
            pass

        '''
        casting
        '''
        if type_check:
            if type_check in [int, float]:
                component_type = 'number'
                component_cleaned = float(component_cleaned)
            elif type_check == bool:
                component_type = 'boolean'
            elif type_check == list:
                component_type = 'list'
            elif type_check == str:
                component_type = 'string'

        return[component_type, component_cleaned]

    @classmethod
    def pretty_print(cls, stuff):
        pretty = json.dumps(stuff, sort_keys=True, indent=4)
        print(pretty)

    @classmethod
    def get_user_path(cls):
        user_app_dir = MayaUtils.get_user_app_dir_path()
        default_value = os.path.normpath(os.path.join(user_app_dir, 'scripts', 'eblabs_hub'))
        path = PrefsManager.getProperty('install_path', default_value)
        return path

    @classmethod
    def update_package_manager(cls):
        '''
        todo
        '''
        eblabs_drag_drop_install.Installer.run_installer()



class SummaryManager(object):
    summary_data = []
    version = False
    version_date = ' '

    @classmethod
    def set_versions(cls, version=False, version_date = ' '):
        cls.version = version
        cls.version_date = version_date

    @classmethod
    def reset(cls):
        cls.summary_data = [[]]

    @classmethod
    def append_item(cls, item, new_group = False):
        '''
        create new group
        '''
        if new_group:
            cls.summary_data.append([])

        '''
        append
        '''
        if '\n' in item:
            buffer = item.split('/n')
            for b in buffer:
                cls.summary_data[-1].append(b)
        else:
            cls.summary_data[-1].append(item)

    @classmethod
    def print_summary(cls):
        summary = '''
       _      _         _          
      | |    | |       | |         
  ___ | |__  | |  __ _ | |__   ___ 
 / _ \| '_ \ | | / _` || '_ \ / __|
|  __/| |_) || || (_| || |_) |\__ \\
 \___||_.__/ |_| \__,_||_.__/ |___/

 Package Manager Install Summary
 {0} {1}
        '''.format(cls.version, cls.version_date)
        print(summary)
        if not cls.summary_data:
            return False

        '''
        iterate groups
        '''
        print_buffer = ''
        for summary_group in cls.summary_data:
            if summary_group:
                '''
                header
                '''
                print_buffer += '+----------------------------------------\n'

                '''
                items
                '''
                for item in summary_group:
                    print_buffer += '|{0}\n'.format(item)

                '''
                footer
                '''
                print_buffer += '+----------------------------------------\n'
        print(print_buffer)


