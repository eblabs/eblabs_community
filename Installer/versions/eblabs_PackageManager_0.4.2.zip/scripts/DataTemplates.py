#import Qt

import copy
import os
import traceback
import random
import re
import json
import Scandir
import uuid
import time

from functools import partial



class Templates(object):

    @classmethod
    def getTimeStamp(cls):
        return time.time()

    @classmethod
    def getID(cls):
        return uuid.uuid4().hex

    @classmethod
    def getDataTemplate(cls):
        data = {}
        data['color'] = [0.2] * 3
        data['short_name'] = ''
        data['long_name'] = ''
        data['annotation'] = ''

        data['children'] = []
        data['type'] = 'root'
        data['sub_type'] = ''

        # data['tags'] = []

        return copy.deepcopy(data)

    @classmethod
    def getCommandTemplate(cls):
        data = {}
        data['short_name'] = ''
        data['long_name'] = ''
        data['annotation'] = ''
        data['command'] = ''
        data['alt_command'] = ''
        data['source_type'] = 'python'

        return copy.deepcopy(data)

    @classmethod
    def getIconTemplate(cls):
        data = {}
        data['image'] = ''
        data['label'] = ''

        return copy.deepcopy(data)

    @classmethod
    def getContentsTemplate(cls):
        data = cls.getDataTemplate()
        data['color'] = ColorPalette.getDefaultColor()
        data['annotation'] = ''
        data['command_data'] = cls.getCommandTemplate()
        data['type'] = 'placeholder'
        data['icon'] = cls.getIconTemplate()

        data['tags'] = []
        data['id'] = cls.getID()

        '''
        data that's used for the specific widget, no format defined here, just a dict
        '''
        data['data'] = {}

        return copy.deepcopy(data)


    @classmethod
    def get_template_script(cls):
        template = '''
install_path = ''
package_id = 'myTool'

import os
import sys
if not install_path in sys.path:
    sys.path.append(install_path)

import WorldSpaceTools.scripts.worldspace as tool

tool.window.load()
'''
        return template

    @classmethod
    def get_shelf_button_template_data(cls):
        template = {
                "annotation": "",
                "children": [],
                "color": [
                    0.388,
                    0.737,
                    0.808,
                    1
                ],
                'command_data': cls.getCommandTemplate(),
                "data": {},
                "icon": {
                    "image": "commandButton.png",
                    "label": ""
                },
                "id": cls.getID(),
                "long_name": "Shelf Button Template",
                "short_name": "Shelf Button Template",
                "sub_type": "",
                "tags": [],
                "type": "standardButton"
            }

        '''
        set template script
        '''
        template['command_data']['command'] = cls.get_template_script()


        return template

    @classmethod
    def get_core_folders_list(cls):
        d = ['data', 'images', 'scripts']
        return d

    @classmethod
    def get_dev_folders_list(cls):
        d = ['dev']
        return d

    @classmethod
    def get_core_folders_list_and_types(cls):
        d = {}
        d['data'] = ['data']
        d['images'] = ['jpg', 'jpeg', 'png']
        d['scripts'] = ['py']
        return d

    @classmethod
    def get_package_data_template(cls):
        d = {}
        d['package'] = 'User Facing Name'
        #d['location'] = 'ShortFolderName'
        d['package_id'] = 'ShortFolderName'
        d['version'] = '0.0'
        d['shelf_data'] = []
        d['website'] = 'http://www.eblabs.com'
        d['support'] = 'https://github.com/eblabs/eblabs_docs/issues'
        d['description'] = 'tool for doing xyz'

        return d


class ColorPalette(object):

    @classmethod
    def getColors(self):
        colorList = []
        colorList.append([1, 1, 1, 1])  # white
        colorList.append([0.365, 0.365, 0.365, 1])  # default grey

        # sublime subtle colors
        # http://www.color-hex.com/color-palette/17335
        colorList.append([0.596, 0.467, 0.839, 1])
        colorList.append([0.573, 0.737, 0.231, 1])
        colorList.append([0.761, 0.224, 0.416, 1])
        colorList.append([0.388, 0.737, 0.808, 1])
        colorList.append([0.894, 0.553, 0.153, 1])
        return colorList

    @classmethod
    def getDefaultColor(cls):
        '''
        random fallback color
        '''
        randomColor = random.choice(cls.getColors())
        return randomColor
