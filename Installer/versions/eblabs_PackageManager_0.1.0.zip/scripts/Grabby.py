import os
import copy
import math

import Qt

import PixoShop
reload(PixoShop)

handIconPath = '/u/ecb/Pictures/eblabs-hub/eblabs_hub/Hub/Images/Move.gif'
if os.path.isfile(handIconPath):
    pass
else:
    handIconPath = 'E:/Git/eblabs-hub/eblabs_hub/Hub/Images/Move.gif'

class Window(Qt.QtWidgets.QDialog):

    def __init__(self, *args, **kwargs):
        parent = QTHelpers.get_main_window()

        '''
        set parent
        '''
        super(Window, self).__init__(parent)

        '''
        set title
        '''
        windowTitle = "Dev"

        '''
        '''
        self.setObjectName(windowTitle)
        self.setWindowTitle(windowTitle)

        '''
        main layout for Document
        '''
        self.main_layout = Qt.QtWidgets.QVBoxLayout(self)
        self.main_layout.setSpacing(0)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setObjectName('main_layout')
        self.main_layout.setAlignment(Qt.QtCore.Qt.AlignTop)
        self.setLayout(self.main_layout)

        '''
        rubber band test
        '''
        #kwargs = {}
        #kwargs['parent'] = self
        #kwargs['releaseCallback'] = self.grabbyReleaseCallback
        #kwargs['validateCallback'] = self.grabbyValidateCallback
        #kwargs['grabbyType'] = Qt.QtWidgets.QPushButton
        w = GrabbyWidget(self)

        self.main_layout.addWidget(w)

        '''
        test
        '''
        test = Qt.QtWidgets.QPushButton('test', self)
        self.main_layout.addWidget(test)


    def display(self, mode = False):
        '''
        set size
        '''
        self.resize(200, 200)
        self.show()

class QTHelpers():


    @classmethod
    def get_main_window(cls):
        """Return Maya's main window"""
        for obj in Qt.QtWidgets.QApplication.instance().topLevelWidgets():
            if obj.objectName() == 'MayaWindow':
                return obj

        return False


class BehaviourModes(object):
    Inactive = 1
    Active = 2


class GrabbyWidget(Qt.QtWidgets.QLabel):

    def __init__(self, *args, **kwargs):
        #
        super(GrabbyWidget, self).__init__(*args, **kwargs)
        '''
        attributes
        '''
        self.release_callback = False
        self.is_valid_check = False
        self.target_widget_types = False
        self.behaviour_mode = BehaviourModes.Inactive
        self.size_scale_factor = 1

        '''
        overlay widget
        '''
        self.app_parent = QtUtils.getMainWindow()
        self.overlay_widget = False
        self.overlay_cursor = False
        self.overlay_dots = []

        '''
        set display
        '''
        self.set_display(self)

        '''
        event filter
        '''
        self.installEventFilter(self)

    def set_dpi_scale_factor(self, value):
        self.size_scale_factor = value

    def get_dpi_scale_factor(self,):
        return self.size_scale_factor

    def get_dpi_scaled_value(self, value):
        return value * self.size_scale_factor

    def set_release_callback(self, callback):
        self.release_callback = callback

    def set_is_valid_check(self, state):
        self.is_valid_check = state

    def set_target_widget_types(self, target_types):
        self.target_widget_types = target_types

    def get_is_valid(self, widget):
        '''
        enable valid checking
        '''
        is_valid = False
        if not self.is_valid_check:
            is_valid = True

        '''
        '''
        if not is_valid:
            if widget:
                is_valid = True

        return is_valid


    def get_widget_under_mouse(self):
        widget = QtUtils.getWidgetOfTypesUnderMouse(self.target_widget_types, callback=False, debug=False)
        return widget

    def create_overlay_widget(self):
        '''
        overlay widget
        '''
        w = OverlayLineWidget()
        return w

    def set_display(self, widget):
        '''
        set icon
        '''
        color = [0.2,0.2,0.2,1]
        #fillColor =  Qt.QtGui.QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255), int(color[3] * 255))
        qimage = PixoShop.Actions.qImageCanvas(width=60, height=60)
        qimage = PixoShop.Actions.drawQimagePolygon_roundedSquare(qimage, radius=8, color=[0.2,0.2,0.2, 1], x=0, y=0, w=1, h=1)

        if self.behaviour_mode == BehaviourModes.Inactive:
            color = [1, 1, .4, 1]
            qimage = PixoShop.Templates.drawQImageShape_Grabby(qimage, 0,0,1,1, color=color)

        '''
        '''
        pixmap = PixoShop.Actions.convertToPixmap(qimage)
        self.setPixmap(pixmap)


    def get_cursor_position(self, widget):
        '''
        cursor pos
        '''
        pos = Qt.QtGui.QCursor.pos()

        '''
        map to local
        '''
        #pos = widget.mapFromGlobal(pos)
        return pos

    def eventFilter(self, obj, event):

        if not obj.isWidgetType():
            return False

        eventType = event.type()
        if eventType != Qt.QtCore.QEvent.MouseButtonPress and \
                eventType != Qt.QtCore.QEvent.MouseButtonRelease and \
                eventType != Qt.QtCore.QEvent.MouseMove:
            return False

        '''
        modifier keys
        '''
        modifiers = QtUtils.getKeyModifiers()

        '''
        events
        '''
        if eventType == Qt.QtCore.QEvent.MouseButtonPress:
            '''
            press
            '''
            self.OnPressAction()

        elif eventType == Qt.QtCore.QEvent.MouseMove:
            '''
            move
            '''
            self.OnMoveAction()

        elif eventType == Qt.QtCore.QEvent.MouseButtonRelease:
            '''
            release
            '''
            self.OnReleaseAction()


        super(GrabbyWidget, self).eventFilter(obj, event)

    def OnPressAction(self):
        '''
        OnPressAction
        '''

        '''
        behaviour Mode
        '''
        self.behaviour_mode = BehaviourModes.Active
        self.set_display(self)

        '''
        points
        '''
        cursor_point = self.mapToGlobal( self.rect().center() )

        '''
        create overlay cursor
        '''
        self.overlay_cursor = OverlayCursorWidget()
        self.overlay_cursor.set_dpi_scale_factor(self.get_dpi_scale_factor())
        self.overlay_cursor.set_relative_position_ratio(1)
        self.overlay_cursor.setVisible(True)

        self.overlay_cursor.set_start_point(cursor_point)
        self.overlay_cursor.set_end_point(cursor_point)


        '''
        '''
        self.overlay_dots = []
        for i in range(1, 10+1):
            pos = i / float(10)
            w = OverlayDotWidget()
            w.set_dpi_scale_factor(self.get_dpi_scale_factor())
            w.set_relative_position_ratio(pos)
            w.setVisible(True)

            w.set_start_point(cursor_point)
            w.set_end_point(cursor_point)
            self.overlay_dots.append(w)

        #widget = self.get_widget_under_mouse()
        #self.overlay_widget.set_is_valid(self.get_is_valid(widget))
        self.overlay_cursor.refresh()

        '''
        invisible cursor
        '''
        if True:
            rgb = [1, 1, .4, 0]  # yellow
            size = self.get_dpi_scaled_value(32)
            qcolor = Qt.QtGui.QColor(int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255))
            pixmap = QtUtils.pixmapCanvas(size, size, fillColor=qcolor)
            cursor = Qt.QtGui.QCursor(pixmap)
            Qt.QtWidgets.QApplication.setOverrideCursor(cursor)

    def OnMoveAction(self):
        '''
        OnMoveAction
        '''

        '''
        points
        '''
        cursor_point = self.get_cursor_position(self.app_parent)
        '''
        overlay widget
        '''
        """
        self.overlay_widget.set_end_point(cursor_point)
        widget = self.get_widget_under_mouse()
        self.overlay_widget.set_is_valid(self.get_is_valid(widget))
        self.overlay_widget.refresh()
        """

        '''
        cursor overlay widget
        '''
        self.overlay_cursor.set_end_point(cursor_point)
        #widget = self.get_widget_under_mouse()
        #self.overlay_widget.set_is_valid(self.get_is_valid(widget))
        self.overlay_cursor.refresh()


        '''
        '''
        for w in self.overlay_dots:
            w.set_end_point(cursor_point)
            w.refresh()

    def OnReleaseAction(self):
        '''
        OnReleaseAction
        '''
        Qt.QtWidgets.QApplication.restoreOverrideCursor()

        '''
        behaviour Mode
        '''
        self.behaviour_mode = BehaviourModes.Inactive
        self.set_display(self)

        '''
        '''
        """
        self.overlay_widget.setVisible(False)
        self.overlay_widget.deleteLater()
        self.overlay_widget = False
        """

        '''
        '''
        self.overlay_cursor.setVisible(False)
        self.overlay_cursor.deleteLater()
        self.overlay_cursor = False
        '''
        '''
        for w in self.overlay_dots:
            w.setVisible(False)
            w.deleteLater()
            w = False
        self.overlay_dots = []

        '''
        get widget and callback
        '''
        widget = self.get_widget_under_mouse()
        self.on_grabby_release_callback(widget)


    def on_grabby_release_callback(self, widget):
        if widget:
            '''
            get maya pointer
            '''
            mayaPointer = MayaUtils.getMayaObjectForQTWidget(widget)

            '''
            callback
            '''
            self.release_callback(mayaPointer)


class OverlayLineWidget(Qt.QtWidgets.QSplashScreen):
    def __init__(self, *args, **kwargs):
        '''
        init
        '''
        flags = Qt.QtCore.Qt.FramelessWindowHint | Qt.QtCore.Qt.WindowStaysOnTopHint
        pixmap = PixoShop.Actions.pixmapCanvas()
        Qt.QtWidgets.QSplashScreen.__init__(self, pixmap, flags)

        '''
        properties
        '''
        self.setAttribute(Qt.QtCore.Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.QtCore.Qt.WA_TransparentForMouseEvents)

        '''
        attributes
        '''
        self.start_point = Qt.QtCore.QPoint(0,0)
        self.end_point = Qt.QtCore.QPoint(0, 0)

        self.is_valid = False
        self.color_band = [1, 1, .4, 1]  # yellow
        self.color_tip_valid = [0.255, 0.518, 0.953, 1] # blue
        self.color_tip_non_valid = [0.952, 0.262, 0.254, 1] # red/orangy

        '''
        test image
        '''
        pixmap = self.get_pixmap()
        self.setPixmap(pixmap)
        self.setMask(pixmap.mask())


    def set_start_point(self, qpoint):
        self.start_point = qpoint

    def set_end_point(self, qpoint):
        self.end_point = qpoint

    def set_is_valid(self, state):
        self.is_valid = state

    def get_is_valid(self):
        return self.is_valid

    def get_is_valid_color(self):
        if self.get_is_valid():
            return self.color_tip_valid
        else:
            return self.color_tip_non_valid

    def get_bounding_rect(self):
        '''
        calculate bounds
        '''
        top = max(self.start_point.y(), self.end_point.y())
        bot = min(self.start_point.y(), self.end_point.y())

        right = max(self.start_point.x(), self.end_point.x())
        left = min(self.start_point.x(), self.end_point.x())

        top_left = Qt.QtCore.QPoint(left, top)
        bot_right = Qt.QtCore.QPoint(right, bot)

        '''
        creatre rect
        '''
        rect = Qt.QtCore.QRect(top_left, bot_right).normalized()

        '''
        enlarge by 32 px to include icon
        '''
        size = self.get_dpi_scaled_value(32)
        margin = Qt.QtCore.QMargins(size,size,size,size)
        rect = rect.marginsAdded(margin)


        return rect

    def get_relative_point(self, rect, point):
        '''
        get some info
        '''
        width = rect.width()
        height = rect.height()

        left = rect.left()
        right = rect.right()
        top = rect.top()
        bottom = rect.bottom()

        #local_x = round((point.x() - left)/float(width))
        #local_y = round((point.y() - top) / float(height))

        local_x = (point.x() - left)/float(width)
        local_y = (point.y() - top) / float(height)

        if False:
            print('###################')

            print('point.x()', point.x())
            print('point.y()', point.y())

            print('width', width)
            print('height', height)
            print('left', left)
            print('right', right)
            print('top', top)
            print('bottom', bottom)

            print('xdif',  (point.x() - left))
            print('ydif', (point.y() - bottom))


            print('local_x',  local_x)
            print('local_y', local_y)

        return [local_x, local_y]

    def get_is_valid_color(self):
        if self.get_is_valid():
            return self.color_tip_valid
        else:
            return self.color_tip_non_valid

    def get_pixmap(self):
        '''
        create canvas
        '''
        rect = self.get_bounding_rect()
        rect_width = rect.width()
        rect_height = rect.height()
        qimage = PixoShop.Actions.qImageCanvas(width=rect_width, height=rect_height)

        '''
        draw line
        '''
        start_point = self.get_relative_point(rect, self.start_point)
        end_point = self.get_relative_point(rect, self.end_point)

        color = [1, 1, .4, 1]  # yellow
        x = 0
        y = 0
        width = 1
        height = 1
        points = []
        points.append(start_point)
        points.append(end_point)
        qimage = PixoShop.Actions.drawPolygonOutline(qimage, x, y, width, height, points, color, lineWidth = 4, absoluteLineWidth=True)

        '''
        rotation
        '''
        center_point = Vector3( self.start_point.x(), 0, self.start_point.y())
        ref_vector = Vector3(0,0,1)
        target_point = Vector3( self.end_point.x(), 0, self.end_point.y())
        angle = 360 - Utils.get_signed_angle(center_point, ref_vector, target_point) + 180

        '''
        draw circle at end point
        '''
        """
        #color = self.get_is_valid_color()
        color = [1, 1, .4, 1]  # yellow
        icon_size = 32
        relative_width = icon_size/float(rect_width)
        relative_height = icon_size/ float(rect_height)
        relative_x =  end_point[0] - (relative_width/2.0)
        relative_y = end_point[1] - (relative_height / 2.0)
        qimage = PixoShop.Templates.drawQImageShape_Grabby(qimage, relative_x, relative_y, relative_width,
                                                           relative_height, color=color, angle = angle)
        """
        '''
        convert to pixmap
        '''
        pixmap = PixoShop.Actions.convertToPixmap(qimage)

        '''
        return 
        '''
        return pixmap

    def refresh(self):
        rect = self.get_bounding_rect()
        self.setGeometry(rect)
        self.resize(rect.size())
        self.repaint()

    def paintEvent(self, *args, **kwargs):
        #https://stackoverflow.com/questions/49773745/qsplashscreen-setpixmap-moves-splashscreen-back-to-default-position
        painter =  Qt.QtGui.QPainter(self)
        pixmap = self.get_pixmap()
        self.setMask(pixmap.mask()) # optional for transparency painting
        painter.drawPixmap(0, 0, pixmap)

class OverlayCursorWidget(Qt.QtWidgets.QSplashScreen):
    def __init__(self, *args, **kwargs):
        '''
        init
        '''
        flags = Qt.QtCore.Qt.FramelessWindowHint | Qt.QtCore.Qt.WindowStaysOnTopHint
        pixmap = PixoShop.Actions.pixmapCanvas()
        Qt.QtWidgets.QSplashScreen.__init__(self, pixmap, flags)

        '''
        properties
        '''
        self.setAttribute(Qt.QtCore.Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.QtCore.Qt.WA_TransparentForMouseEvents)

        '''
        attributes
        '''
        self.start_point = Qt.QtCore.QPoint(0,0)
        self.end_point = Qt.QtCore.QPoint(0, 0)
        self.relative_position_ratio = 0.5

        self.is_valid = False
        self.color_band = [1, 1, .4, 1]  # yellow
        self.color_tip_valid = [0.255, 0.518, 0.953, 1] # blue
        self.color_tip_non_valid = [0.952, 0.262, 0.254, 1] # red/orangy
        self.size_scale_factor = 1

        '''
        image
        '''
        pixmap = self.get_pixmap()
        self.setPixmap(pixmap)
        self.setMask(pixmap.mask())

    def set_dpi_scale_factor(self, value):
        self.size_scale_factor = value

    def get_dpi_scaled_value(self, value):
        return value * self.size_scale_factor

    def set_relative_position_ratio(self, value):
        '''
        set a ratio between start and end points
        '''
        self.relative_position_ratio =value

    def get_position(self):
        inv_ratio = 1 - self.relative_position_ratio
        x = self.start_point.x() * inv_ratio + self.end_point.x() * self.relative_position_ratio
        y = self.start_point.y() * inv_ratio + self.end_point.y() * self.relative_position_ratio
        return Qt.QtCore.QPoint(x,y)

    def set_start_point(self, qpoint):
        self.start_point = qpoint

    def set_end_point(self, qpoint):
        self.end_point = qpoint

    def set_is_valid(self, state):
        self.is_valid = state

    def get_is_valid(self):
        return self.is_valid

    def get_is_valid_color(self):
        if self.get_is_valid():
            return self.color_tip_valid
        else:
            return self.color_tip_non_valid

    def get_bounding_rect(self):
        '''
        calculate bounds
        '''
        size = self.get_dpi_scaled_value(32)
        pos = self.get_position()
        rect = Qt.QtCore.QRect(pos.x() - (size/2), pos.y() - (size/2), size, size)

        return rect

    def get_relative_point(self, rect, point):
        '''
        get some info
        '''
        width = rect.width()
        height = rect.height()

        left = rect.left()
        right = rect.right()
        top = rect.top()
        bottom = rect.bottom()

        local_x = (point.x() - left)/float(width)
        local_y = (point.y() - top) / float(height)

        return [local_x, local_y]

    def get_is_valid_color(self):
        if self.get_is_valid():
            return self.color_tip_valid
        else:
            return self.color_tip_non_valid

    def get_pixmap(self):
        '''
        create canvas
        '''
        rect = self.get_bounding_rect()
        rect_width = rect.width()
        rect_height = rect.height()
        qimage = PixoShop.Actions.qImageCanvas(width=rect_width, height=rect_height)

        '''
        draw line
        '''
        #start_point = self.get_relative_point(rect, self.start_point)
        #end_point = self.get_relative_point(rect, self.end_point)
        """
        color = [1, 1, .4, 1]  # yellow
        x = 0
        y = 0
        width = 1
        height = 1
        points = []
        points.append(start_point)
        points.append(end_point)
        #qimage = PixoShop.Actions.drawPolygonOutline(qimage, x, y, width, height, points, color, lineWidth = 4, absoluteLineWidth=True)
        """
        '''
        rotation
        '''
        center_point = Vector3( self.start_point.x(), 0, self.start_point.y())
        ref_vector = Vector3(0,0,1)
        target_point = Vector3( self.end_point.x(), 0, self.end_point.y())
        angle = 360 - Utils.get_signed_angle(center_point, ref_vector, target_point) + 180

        '''
        draw shape at end point
        '''
        #color = self.get_is_valid_color()
        color = [1, 1, .4, 1]  # yellow
        icon_size = 32
        #relative_width = icon_size/float(rect_width)
        #relative_height = icon_size/ float(rect_height)
        #relative_x =  end_point[0] - (relative_width/2.0)
        #relative_y = end_point[1] - (relative_height / 2.0)
        qimage = PixoShop.Templates.drawQImageShape_Grabby(qimage, 0, 0, 1, 1, color=color, angle=angle)

        '''
        convert to pixmap
        '''
        pixmap = PixoShop.Actions.convertToPixmap(qimage)

        '''
        return 
        '''
        return pixmap

    def refresh(self):
        rect = self.get_bounding_rect()
        self.setGeometry(rect)
        self.resize(rect.size())
        self.repaint()


    def paintEvent(self, *args, **kwargs):
        #https://stackoverflow.com/questions/49773745/qsplashscreen-setpixmap-moves-splashscreen-back-to-default-position
        painter =  Qt.QtGui.QPainter(self)
        pixmap = self.get_pixmap()
        self.setMask(pixmap.mask()) # optional for transparency painting
        painter.drawPixmap(0, 0, pixmap)

class OverlayDotWidget(OverlayCursorWidget):
    def __init__(self):
        super(OverlayDotWidget, self).__init__()

    def get_bounding_rect(self):
        '''
        calculate bounds
        '''
        size = self.get_dpi_scaled_value(5)
        pos = self.get_position()
        rect = Qt.QtCore.QRect(pos.x() - (size/2), pos.y() - (size/2), size, size)

        return rect

    def get_pixmap(self):
        '''
        create canvas
        '''
        rect = self.get_bounding_rect()
        rect_width = rect.width()
        rect_height = rect.height()
        qimage = PixoShop.Actions.qImageCanvas(width=rect_width, height=rect_height)

        '''
        draw shape at end point
        '''
        color = [1, 1, .4, 1]  # yellow
        qimage = PixoShop.Templates.drawQImageShape_circle(qimage, 0, 0, 1, 1, color=color)

        '''
        convert to pixmap
        '''
        pixmap = PixoShop.Actions.convertToPixmap(qimage)

        '''
        return 
        '''
        return pixmap

class GrabbyWidget_back(Qt.QtWidgets.QLabel):

    def __init__(self, parent=False, releaseCallback=False, grabbyType=False, validateCallback=False):
        #
        super(GrabbyWidget_back, self).__init__(parent)

        self.pressState = False
        self.dragIcon = False
        self.releaseCallback = releaseCallback
        self.validateCallback = validateCallback
        self.grabbyType = grabbyType
        #self.grabby = GrabbyAnimator()
        self.validationWidget = False
        self.testWidget = False
        self.overrideCount = 0
        # self.restoreCursor = Qt.QtWidgets.QApplication.cursor()

        self.movie = Qt.QtGui.QMovie(handIconPath)

        # state tracking
        self.mouseDown = False
        self.installEventFilter(self)

        filepath = handIconPath
        height = width = 30
        # pixmap = Qt.QtGui.QPixmap(filepath)
        # pixmap = PS.loadPixmapFromPath(filepath, width, height)
        # pixmap = Qt.QtGui.QPixmap(filepath)
        pixmap = Qt.QtGui.QPixmap(filepath)
        # self.setPixmap(Qt.QtGui.QPixmap.fromImage(pixmap, Qt.QtCore.Qt.AutoColor))
        self.setPixmap(pixmap)

        '''
        set initial state
        '''
        self.setDisplayState('valid', True)

    def eventFilter(self, obj, event):

        if not obj.isWidgetType():
            return False

        eventType = event.type()
        if eventType != Qt.QtCore.QEvent.MouseButtonPress and \
                eventType != Qt.QtCore.QEvent.MouseButtonRelease and \
                eventType != Qt.QtCore.QEvent.MouseMove:
            return False

        '''
        modifier keys
        '''
        modifiers = QtUtils.getKeyModifiers()

        '''
        events
        '''
        if eventType == Qt.QtCore.QEvent.MouseButtonPress:
            '''
            press
            '''
            self.OnPressAction()

        elif eventType == Qt.QtCore.QEvent.MouseMove:
            '''
            move
            '''
            self.OnMoveAction()

        elif eventType == Qt.QtCore.QEvent.MouseButtonRelease:
            '''
            release
            '''
            self.OnReleaseAction()

        super(Grabby, self).eventFilter(obj, event)

    def setDisplayState(self, state, parameter):
        '''
        handle various display states
        '''
        if state == 'valid':
            '''
            stylesheet
            '''
            styleSheet = ''

            '''
            background color
            '''
            rgbColor = [0.2, 0.2, .2, 1]
            if parameter:
                rgbColor = [.7, .7, .7, 1]
            styleElement = 'background-color: rgba({0},{1},{2},{3})'.format(int(rgbColor[0] * 255),
                                                                            int(rgbColor[1] * 255),
                                                                            int(rgbColor[2] * 255),
                                                                            int(rgbColor[3] * 255))
            styleSheet += '{0};; '.format(styleElement)

            '''
            border color
            '''
            # rgbColor = [0,0,0,0]
            # colorStyle = 'border: 0px solid rgba({0},{1},{2},{3})'.format(int(rgbColor[0] * 255), int(rgbColor[1] * 255), int(rgbColor[2] * 255),  int(rgbColor[3] * 255))
            # styleSheet += '{0};; '.format(colorStyle)

            '''
            encapsulate
            '''
            styleSheet = 'Grabby{{ {0} }}'.format(styleSheet)

            '''
            set
            '''
            self.setStyleSheet(styleSheet)

    def OnPressAction(self):
        print('OnPressAction')
        '''
        reset initial states
        '''
        # self.setDisplayState('valid', False)
        #self.grabby.Start()

        '''
        hide cursor
        '''

        # Qt.QtWidgets.QApplication.setOverrideCursor(Qt.QtGui.QCursor(Qt.QtCore.Qt.BlankCursor))
        pixmap = self.movie.currentPixmap()
        pixmap = Qt.QtGui.QPixmap(handIconPath)
        pixmap = pixmap.scaled(64, 64, Qt.QtCore.Qt.IgnoreAspectRatio,
                               transformMode=Qt.QtCore.Qt.SmoothTransformation)
        cursor = Qt.QtGui.QCursor(pixmap)

        Qt.QtWidgets.QApplication.setOverrideCursor(cursor)
        self.overrideCount += 1

        '''
        test
        '''
        if not self.testWidget:
            # self.testWidget = AnimatedSplash(handIconPath)

            # self.testWidget = AnimatedLabel(handIconPath)
            # self.testWidget = AnimatedQDialog(handIconPath)

            '''
            #self.testWidget = Qt.QtWidgets.QLabel(Utils.getMainWindow(), Qt.QtCore.Qt.FramelessWindowHint|Qt.QtCore.Qt.WindowStaysOnTopHint)
            self.testWidget.setAttribute(Qt.QtCore.Qt.WA_TranslucentBackground)
            self.testWidget.setAttribute(Qt.QtCore.Qt.WA_TransparentForMouseEvents)

            self.testWidget.setPixmap(pixmap)
            self.testWidget.setMask(pixmap.mask())

            styleSheet = ''
            rgbColor = [1,1,1,1]
            styleElement = 'background-color: rgba({0},{1},{2},{3})'.format(int(rgbColor[0] * 255), int(rgbColor[1] * 255), int(rgbColor[2] * 255),  int(rgbColor[3] * 255))
            styleSheet += '{0};; '.format(styleElement)
            self.testWidget.setStyleSheet(styleSheet)
            '''
            # self.testWidget.onNextFrame()
        # self.testWidget.setOn()

        '''
        '''
        # self.OnMoveAction()

    def OnMoveAction(self):

        self.movie.jumpToNextFrame()
        pixmap = self.movie.currentPixmap()
        pixmap = pixmap.scaled(64, 64, Qt.QtCore.Qt.IgnoreAspectRatio,
                               transformMode=Qt.QtCore.Qt.SmoothTransformation)
        self.pixmap_frame = pixmap
        cursor = Qt.QtGui.QCursor(pixmap)
        # Qt.QtWidgets.QApplication.restoreOverrideCursor()
        Qt.QtWidgets.QApplication.setOverrideCursor(cursor)
        self.overrideCount += 1

        '''
        print(258, 'OnMoveAction')

        # Qt.QtWidgets.QApplication.setOverrideCursor(self.cursor)

        if self.testWidget:
            cursorPos = Qt.QtGui.QCursor().pos()
            centerPosition = Qt.QtCore.QPoint(cursorPos.x() - (self.testWidget.width() / 2),
                                              cursorPos.y() - (self.testWidget.height() / 2))

            #self.testWidget.move(centerPosition)
            #self.testWidget.setPosition(centerPosition)
            #self.testWidget.onNextFrame()
            # self.testWidget.setPixmap(self.testWidget.pixmap_frame)

            # self.testWidget.move(centerPosition)
        '''
        """
        '''
        set states
        '''
        self.pressState = True
        """
        '''
        update position
        '''
        # if self.grabby:
        #    self.grabby.OnMove()

    def OnReleaseAction(self):
        try:

            '''
            testing
            '''
            for i in range(self.overrideCount):
                Qt.QtWidgets.QApplication.restoreOverrideCursor()
            self.overrideCount = 0
            '''
            get widget under mouse
            '''
            debug = False
            widget = QtUtils.getWidgetOfTypesUnderMouse(self.grabbyType, callback=self.releaseCallback, debug=debug)
            print(241, 'widgetFound', widget)
            '''
            test
            '''
            #self.grabby.Stop()



        finally:
            if self.testWidget:
                self.testWidget.setOff()
            '''
            restore cursor
            '''
            #
            print('restore cursor')
            Qt.QtWidgets.QApplication.restoreOverrideCursor()
            # Qt.QtWidgets.QApplication.setOverrideCursor(Qt.QtGui.QCursor(Qt.QtCore.Qt.ArrowCursor))
            # Qt.QtWidgets.QApplication.setOverrideCursor(Qt.QtGui.QCursor(Qt.QtCore.Qt.ArrowCursor))
            # Qt.QtWidgets.QApplication.setOverrideCursor(self.restore )

    def grabbyReleaseCallback(self, widget):
        if widget:
            '''
            get maya button data
            '''
            mayaPointer = QtUtils.MayaUtils.getMayaObjectForQTWidget(widget)
            buttonData = QtUtils.MayaUtils.extractShelfButtonData(mayaPointer)
            # print(172, buttonData)
            '''
            add new item
            '''
            if buttonData:
                '''
                testData = Utils.Misc.getContainerTemplate()
                childData = Utils.Misc.getContentsTemplate()
                childData['type'] = 'standardButton'
                childData['shortName'] = buttonData['shortName']
                childData['longName'] = buttonData['label']
                childData['data'] = buttonData
                testData['children'].append(childData)
                '''
                # self.scrollAreaLeft.addNewItem(testData)
                self.scrollAreaLeft.addNewItem(buttonData)

                '''
                call data save event
                '''
                eventIndex = 'dataChange'
                Core.EM.callEvent(eventIndex)

            # print(200, 'grabbyCallback>>', widget, mayaPointer, buttonData)

    def grabbyValidateCallback(self, widget):
        if not widget:
            return False

        isValid = False
        mayaPointer = QtUtils.MayaUtils.getMayaObjectForQTWidget(widget)
        buttonData = QtUtils.MayaUtils.extractShelfButtonData(mayaPointer)
        if buttonData:
            isValid = True

        return isValid


class Vector3:
    # https://gist.github.com/MartenMoti/7dacaff8e8f59d4aafac5560d66a089c
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    # Used for debugging. This method is called when you print an instance
    def __str__(self):
        return "(" + str(self.x) + ", " + str(self.y) + ", " + str(self.z) + ")"

    def length(self):
        return self.get_length(self)

    def __add__(self, v):
        return Vector3(self.x + v.x, self.y + v.y, self.z + v.z)

    def __sub__(self, v):
        return Vector3(self.x - v.x, self.y - v.y, self.z - v.z)

    def __mul__(self, n):
        return Vector3(self.x * n, self.y * n, self.z * n)

    def __div__(self, var):
        return self.__truediv__(var)

    def __truediv__(self, var):
        # https://stackoverflow.com/questions/3188666/python-operator-overloading-a-specific-type
        return self * (1 / var)

    def normalized(self):
        length = self.length()
        if length == 0:
            return self
        else:
            return self * (1 / length)

    @classmethod
    def dot_product(cls, v1, v2):
        return (v1.x * v2.x + v1.y * v2.y + v1.z * v2.z)

    @classmethod
    def get_angle(cls, v1, v2):
        dot = cls.dot_product(v1, v2)
        length1 = cls.get_length(v1)
        lengthB = cls.get_length(v2)
        costheta = dot / (length1 * lengthB)
        return math.acos(costheta)

    @classmethod
    def get_length(cls, v1):
        return math.sqrt(v1.x ** 2 + v1.y ** 2 + v1.z ** 2)

class Utils(object):

    @classmethod
    def get_signed_angle(cls, centerPoint, refvec, pointVar):
        # https://stackoverflow.com/questions/41855695/sorting-list-of-two-dimensional-coordinates-by-clockwise-angle-using-python
        # Vector between point and the origin: v = p - o
        point = copy.deepcopy(pointVar)
        point.y = 0
        vector = point - centerPoint
        vector.y = 0

        # Length of vector: ||v||
        lenvector = vector.length()  # math.hypot(vector[0], vector[1])

        # If length is zero there is no angle
        if lenvector == 0:
            return math.degrees(-math.pi)

        # Normalize vector: v/||v||
        normalized = vector / lenvector
        dotprod = normalized.x * refvec.x + normalized.z * refvec.z
        diffprod = refvec.z * normalized.x - refvec.x * normalized.z
        radians = math.atan2(diffprod, dotprod)

        # Negative angles represent counter-clockwise angles so we need to subtract them
        # from 2*pi (360 degrees)
        while radians < 0:
            radians = 2 * math.pi + radians

        # I return first the angle because that's the primary sorting criterium
        # but if two vectors have the same angle then the shorter distance should come first.
        angle = math.degrees(radians)

        return angle

class MayaUtils(object):
    try:
        from maya import cmds
        from maya import mel
        import maya.OpenMayaUI as OpenMayaUI
        import maya.api.OpenMaya as OpenMaya
        mayaLoaded = True
    except Exception, e:
        pass
    import Qt
    resourceCache = False
    shelfIconLookup = {}
    shelfIconPaths = []

    @classmethod
    def isMayaLoaded(cls):
        return cls.mayaLoaded

    @classmethod
    def getQtObjectForMayaWidget(cls, widgetPath):
        '''
        get pointer
        '''
        pointer = cls.OpenMayaUI.MQtUtil.findControl(widgetPath)
        '''
        get wrap function
        '''
        func = False
        qtWidget = False
        try:
            try:
                import sip
                func = sip.wrapinstance
                qtWidget = func(long(pointer), Qt.QtWidgets.QWidget)
            except:
                import c
                func = shiboken.wrapInstance
                qtWidget = func(long(pointer), Qt.QtWidgets.QWidget)
        except:
            try:
                import shiboken2
                func = shiboken2.wrapInstance
                qtWidget = func(long(pointer), Qt.QtWidgets.QWidget)
            except:
                pass

        return qtWidget
        # qtWidget = func(long(pointer), Qt.QtWidgets.QWidget)

    @classmethod
    def getMayaObjectForQTWidget(cls, widget):
        pointer = cls.unwrapInstance(widget)
        try:
            mayaPointer = cls.OpenMayaUI.MQtUtil.fullName(long(pointer))
        except:
            mayaPointer = cls.OpenMayaUI.MQtUtil.fullName(int(pointer))
        return mayaPointer

    @classmethod
    def unwrapInstance(cls, pointer):
        unwrapped = False
        try:
            try:
                import sip
                unwrapped = long(sip.unwrapinstance(pointer))
            except:
                import shiboken
                unwrapped = shiboken.getCppPointer(pointer)[0]
        except:
            try:
                import shiboken2
                unwrapped = shiboken2.getCppPointer(pointer)[0]
            except:
                pass

        return unwrapped


class QtUtils(object):
    @classmethod
    def clampFloat(cls, minVal, current, maxVal):
        return max(min(current, maxVal), minVal)

    @classmethod
    def getMainWindow(cls):
        """Return Maya's main window"""
        # for obj in Qt.QtWidgets.qApp.topLevelWidgets():
        for obj in Qt.QtWidgets.QApplication.instance().topLevelWidgets():
            # print 570, 'getMainWindow', obj.objectName()
            if obj.objectName() == 'MayaWindow':
                return obj

        return False

    @classmethod
    def getWidgetOfTypesUnderMouse(cls, widgetTypes, callback=False, debug=False):
        '''
        '''
        foundWidget = False
        pos = Qt.QtGui.QCursor.pos()
        widgetAt = Qt.QtWidgets.QApplication.instance().widgetAt(pos)
        debugList = []
        if not widgetTypes:
            return widgetAt
        if widgetAt:
            while widgetAt:
                '''
                track for debugging
                '''
                debugItem = MayaUtils.getMayaObjectForQTWidget(widgetAt)
                debugList.append((widgetAt, debugItem))

                '''
                its a match
                '''
                if isinstance(widgetAt, widgetTypes):
                    foundWidget = widgetAt
                    break

                '''
                go up a level
                '''
                widgetAt = widgetAt.parent()
        '''
        debugging, print list of found widgets
        '''
        if debug:
            print(271, 'debugging>>', debugList)

        if callback:
            try:
                callback(foundWidget)
            except Exception, e:
                print(268, foundWidget, Exception, e)
                print(traceback.format_exc())

        '''
        return
        '''
        return foundWidget

    @classmethod
    def getKeyModifiers(cls):
        QModifiers = Qt.QtWidgets.QApplication.keyboardModifiers()
        modifiers = []
        if QModifiers == Qt.QtCore.Qt.ShiftModifier:
            modifiers.append('shift')
        if QModifiers == Qt.QtCore.Qt.ControlModifier:
            modifiers.append('control')
        if QModifiers == Qt.QtCore.Qt.AltModifier:
            modifiers.append('alt')
        return modifiers

    @classmethod
    def pixmapCanvas(cls, width=100, height=100, fillColor=Qt.QtCore.Qt.GlobalColor.transparent):
        '''
        create transparent qimage
        '''
        qimage = Qt.QtGui.QImage(Qt.QtCore.QSize(width, height), Qt.QtGui.QImage.Format_ARGB32)
        qimage.fill(fillColor)

        qpixmap = Qt.QtGui.QPixmap(width, height)
        qpixmap.convertFromImage(qimage)
        # icon = Qt.QtGui.QIcon(qpixmap)

        return qpixmap