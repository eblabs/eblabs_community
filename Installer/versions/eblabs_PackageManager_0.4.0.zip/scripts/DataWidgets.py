from functools import partial
import re


import Qt


class DataWidget(object):

    def __init__(self, *args, **kwargs):
        super(DataWidget, self).__init__(*args, **kwargs)
        '''
        internal data
        '''
        self.data_key = False
        self.data_value = False
        self.data_optional_value = False
        self.data_parent = False
        self.dirty_state = None
        self.block_updates = None
        self.on_dirty_callbacks = []
        self.on_change_keyword_callbacks = {}

        '''
        layout
        '''
        self.do_layout()

    def set_parent_data(self, value):
        self.data_parent = value

    def get_parent_data(self):
        return self.data_parent

    def set_block_updates(self, value):
        self.block_updates = value

    def get_block_updates(self):
        return self.block_updates

    def set_optional_value(self, value):
        self.data_optional_value = value

    def get_optional_value(self):
        return self.data_optional_value

    def set_value(self, value):
        self.data_value = value

    def get_value(self):
        return self.data_value

    def set_key(self, key):
        self.data_key = key

    def get_key(self):
        return self.data_key

    def get_dirty(self):
        return self.dirty_state

    def set_dirty(self, state, *args, **kwargs):
        '''
        detect change
        '''
        on_change = False
        if state != self.dirty_state:
            on_change = True

        '''
        set
        '''
        self.dirty_state = state

        '''
        trigger dirty event
        '''
        if on_change:
            self.on_dirty_event()

    def do_layout(self):
        '''
        virtual override
        '''

    def update_from_widget(self):
        '''
        virtual override
        '''

    def update_to_widget(self):
        '''
        virtual override
        '''

    def update_indicators(self):
        '''
        virtual override
        '''

    def on_dirty_event(self):
        '''
        allow for blocking callbacks
        '''
        if self.get_block_updates():
            return False

        '''
        callback
        '''
        if self.on_dirty_callbacks:
            for c in self.on_dirty_callbacks:
                try:
                    #print(86, 'on_change_callback', c)
                    c()
                except Exception as e:
                    pass
                    #print(59, 'self.on_dirty_callbacks', Exception, e)

    def add_on_dirty_callback(self, callback):
        self.on_dirty_callbacks.append(callback)

    def clear_on_dirty_callbacks(self):
        self.on_dirty_callbacks = []

    def clear_keyword_callbacks(self):
        self.on_change_keyword_callbacks = {}

    def add_keyword_callback(self, key, callback):
        if key not in self.on_change_keyword_callbacks.keys():
            self.on_change_keyword_callbacks[key] = []
        self.on_change_keyword_callbacks[key].append(callback)

    def call_keyword_callback(self, key):
        if key not in self.on_change_keyword_callbacks.keys():
            self.on_change_keyword_callbacks[key] = []

        if self.on_change_keyword_callbacks[key]:
            for c in self.on_change_keyword_callbacks[key]:
                try:
                    c()
                except Exception as e:
                    print(130, 'call_keyword_callback', Exception, e)

    @classmethod
    def camel_case_to_label(cls, string_var):
        try:
            return_string = re.sub(r'((?<=[a-z])[A-Z]|(?<!\A)[A-Z](?=[a-z]))', r' \1', string_var)
            return_string = return_string.replace('_', ' ')
            return return_string
        except:
            return string_var


class DataWidgetCollection(DataWidget):

    def __init__(self, *args, **kwargs):

        '''
        '''
        self.widgets_list = []

        super(DataWidgetCollection, self).__init__(*args, **kwargs)


    def add_widget(self, k, w):
        '''
        store to internal list
        '''
        self.widgets_list.append([k, w])

    def set_all_dirty(self, state):
        #print(127, 'DataWidgetCollection.set_dirty', state)
        '''
        iterate all widgets
        '''
        for k, w in self.widgets_list:
            w.set_dirty(state)

        '''
        also set itself dirty
        '''
        self.set_dirty(state)

    def update_all_from_widget(self):
        '''
        iterate all widgets
        '''
        for k, w in self.widgets_list:
            w.update_from_widget()

    def get_all_value(self, data={}):
        '''
        iterate all widgets
        '''
        for k, w in self.widgets_list:
            data[w.get_key()] = w.get_value()
        return data

    def get_matching_widget_for_key(self, keyword):
        for k, w in self.widgets_list:
            if k == keyword:
                return w
        return False



class TextLineEdit(DataWidget, Qt.QtWidgets.QWidget ):

    def __init__(self, *args, **kwargs):
        super(TextLineEdit, self).__init__(*args, **kwargs)
        self.setFixedHeight(50)

    def do_layout(self):
        '''
        layout
        '''
        self.main_layout = Qt.QtWidgets.QGridLayout(self)
        self.main_layout.setSpacing(5)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.setLayout(self.main_layout)

        '''
        color indicator
        '''
        self.color_indicator = Qt.QtWidgets.QLabel(self)
        self.color_indicator.setFixedWidth(5)
        self.main_layout.addWidget(self.color_indicator, 0, 0, 1, 1, Qt.QtCore.Qt.AlignLeft)

        '''
        Key Label
        '''
        self.key_field = Qt.QtWidgets.QLabel('Main')
        self.main_layout.addWidget(self.key_field, 0, 1, 1, 1, Qt.QtCore.Qt.AlignLeft)
        self.key_field.setFixedWidth(100)

        '''
        Value Field
        '''
        self.value_field = Qt.QtWidgets.QLineEdit('Sub')
        self.main_layout.addWidget(self.value_field, 0, 2, 1, 1)
        self.value_field.textEdited.connect(partial(self.set_dirty, True))
        self.add_on_dirty_callback(partial(self.update_indicators))

    def update_indicators(self):
        '''
        indicator colors
        '''
        rgb_lookup = {}
        rgb_lookup[False] = [1,1,1,0.5]  # green
        rgb_lookup[True] = [0.639, .824, .455, 1]  # green
        # colors[True] = [0.847, .263, .145]  # red
        rgb = rgb_lookup[self.get_dirty()]
        rgb = [int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255)]

        '''
        setup stylesheet
        '''
        styleSheet = ''

        '''
        background color
        '''
        styleElement = 'background-color: rgb({0},{1},{2})'.format(*rgb)
        styleSheet += '{0};; '.format(styleElement)

        self.color_indicator.setStyleSheet(styleSheet)


    def update_from_widget(self):
        '''
        virtual override
        '''

        '''
        store value from widget into data
        '''
        self.set_value(self.value_field.text())

        '''
        clear dirty flags
        '''
        self.set_dirty(False)

    def update_to_widget(self):
        '''
        virtual override
        '''
        self.key_field.setText( self.camel_case_to_label(self.get_key()))
        self.value_field.setText(self.get_value())
        self.set_dirty(False)

class TextMultiEdit(DataWidget, Qt.QtWidgets.QWidget ):

    def __init__(self, *args, **kwargs):
        super(TextMultiEdit, self).__init__(*args, **kwargs)
        self.setFixedHeight(100)
        #self.setSizePolicy(Qt.QtWidgets.QSizePolicy.Minimum, Qt.QtWidgets.QSizePolicy.Minimum)

    def do_layout(self):
        '''
        layout
        '''
        self.main_layout = Qt.QtWidgets.QGridLayout(self)
        self.main_layout.setSpacing(5)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.setLayout(self.main_layout)
        #self.main_layout.setRowStretch(0, 0)
        #self.main_layout.setRowStretch(1, 1)

        '''
        color indicator
        '''
        self.color_indicator = Qt.QtWidgets.QLabel(self)
        self.color_indicator.setFixedWidth(5)
        self.main_layout.addWidget(self.color_indicator, 0, 0, 1, 1, Qt.QtCore.Qt.AlignLeft)

        '''
        Key Label
        '''
        self.key_field = Qt.QtWidgets.QLabel('Main')
        self.main_layout.addWidget(self.key_field, 0, 1, 1, 1, Qt.QtCore.Qt.AlignLeft)
        self.key_field.setFixedWidth(100)
        #self.main_label.setSizePolicy(Qt.QtWidgets.QSizePolicy.Expanding, Qt.QtWidgets.QSizePolicy.Expanding)
        #self.main_label.sizePolicy().setHorizontalStretch(10)

        '''
        Value Field
        '''
        self.value_field = Qt.QtWidgets.QTextEdit('Sub')
        self.main_layout.addWidget(self.value_field, 0, 2, 1, 1)

        self.value_field.textChanged.connect(partial(self.set_dirty, True))
        self.add_on_dirty_callback(partial(self.update_indicators))
        #self.sub_label.setSizePolicy(Qt.QtWidgets.QSizePolicy.Expanding, Qt.QtWidgets.QSizePolicy.Expanding)
        #self.sub_label.sizePolicy().setHorizontalStretch(1)

    def update_indicators(self):
        '''
        indicator colors
        '''
        rgb_lookup = {}
        rgb_lookup[False] = [1,1,1,0.5]  # green
        rgb_lookup[True] = [0.639, .824, .455, 1]  # green
        # colors[True] = [0.847, .263, .145]  # red
        rgb = rgb_lookup[self.get_dirty()]
        rgb = [int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255)]

        '''
        setup stylesheet
        '''
        styleSheet = ''

        '''
        background color
        '''
        styleElement = 'background-color: rgb({0},{1},{2})'.format(*rgb)
        styleSheet += '{0};; '.format(styleElement)


        self.color_indicator.setStyleSheet(styleSheet)


    def update_from_widget(self):
        '''
        virtual override
        '''

        '''
        store value from widget into data
        '''
        value = self.value_field.toPlainText()
        #value = json.loads(value)
        self.set_value(value)

        '''
        clear dirty flags
        '''
        self.set_dirty(False)

    def update_to_widget(self):
        '''
        virtual override
        '''
        self.key_field.setText( self.camel_case_to_label(self.get_key()))

        value = self.get_value()
        #value = json.dumps(value, sort_keys=True, indent=4)

        self.value_field.setText(value)
        self.set_dirty(False)




class TextLineDisplayHeader(DataWidget, Qt.QtWidgets.QWidget ):

    def __init__(self, *args, **kwargs):
        super(TextLineDisplayHeader, self).__init__(*args, **kwargs)
        self.setFixedHeight(50)

    def do_layout(self):
        '''
        layout
        '''
        self.main_layout = Qt.QtWidgets.QGridLayout(self)
        self.main_layout.setSpacing(5)
        self.main_layout.setContentsMargins(5, 0, 10, 0)
        self.main_layout.setColumnStretch(2, 1)
        self.setLayout(self.main_layout)

        '''
        Value Field
        '''
        self.value_field = Qt.QtWidgets.QLabel('Sub')
        self.main_layout.addWidget(self.value_field, 0, 2, 1, 1)


    def update_to_widget(self):
        '''
        virtual override
        '''
        #self.key_field.setText( self.camel_case_to_label(self.get_key()))
        self.value_field.setText(self.get_value())

        '''
        set labels
        https://html-online.com/editor/
        '''
        text = self.get_value()
        text = '<h1><strong>{0}</strong></h1>'.format(text)
        self.value_field.setText(text)


class TextLineDisplay(DataWidget, Qt.QtWidgets.QWidget):

    def __init__(self, *args, **kwargs):
        super(TextLineDisplay, self).__init__(*args, **kwargs)
        self.setFixedHeight(50)

    def do_layout(self):
        '''
        layout
        '''
        self.main_layout = Qt.QtWidgets.QGridLayout(self)
        self.main_layout.setSpacing(5)
        self.main_layout.setContentsMargins(5, 0, 10, 0)
        self.main_layout.setColumnStretch(2, 1)
        self.setLayout(self.main_layout)

        '''
        Value Field
        '''
        self.value_field = Qt.QtWidgets.QLabel('Sub')
        self.main_layout.addWidget(self.value_field, 0, 2, 1, 1)

    def update_to_widget(self):
        '''
        virtual override
        '''
        #self.key_field.setText( self.camel_case_to_label(self.get_key()))
        self.value_field.setText(self.get_value())

class URLDisplay(DataWidget, Qt.QtWidgets.QWidget ):

    def __init__(self, *args, **kwargs):
        super(URLDisplay, self).__init__(*args, **kwargs)
        self.setFixedHeight(50)

    def do_layout(self):
        '''
        layout
        '''
        self.main_layout = Qt.QtWidgets.QGridLayout(self)
        self.main_layout.setSpacing(5)
        self.main_layout.setContentsMargins(5, 0, 10, 0)
        self.main_layout.setColumnStretch(2, 1)
        self.setLayout(self.main_layout)

        '''
        Value Field
        '''
        self.value_field = Qt.QtWidgets.QPushButton('Sub', self)
        self.main_layout.addWidget(self.value_field, 0, 2, 1, 1, Qt.QtCore.Qt.AlignLeft)

        self.value_field.clicked.connect(self.on_click)

    def on_click(self):

        link = self.get_value()
        print(473, 'On Click', link)
        Qt.QtGui.QDesktopServices.openUrl(link)

    def update_to_widget(self):
        '''
        virtual override
        '''
        #self.key_field.setText( self.camel_case_to_label(self.get_key()))

        self.value_field.setText(self.camel_case_to_label(self.get_key()))
        #self.value_field.setText(self.get_value())

class TextMultiDisplay(DataWidget, Qt.QtWidgets.QWidget):

    def __init__(self, *args, **kwargs):
        super(TextMultiDisplay, self).__init__(*args, **kwargs)
        self.setFixedHeight(100)

    def do_layout(self):
        '''
        layout
        '''
        self.main_layout = Qt.QtWidgets.QGridLayout(self)
        self.main_layout.setSpacing(5)
        self.main_layout.setContentsMargins(5, 0, 10, 0)
        self.main_layout.setColumnStretch(0, 1)
        self.setLayout(self.main_layout)

        '''
        Value Field
        '''
        self.value_field = Qt.QtWidgets.QLabel('Sub')
        self.value_field.setWordWrap(True)
        self.main_layout.addWidget(self.value_field, 0, 0, 1, 1)

    def update_to_widget(self):
        '''
        virtual override
        '''
        value = self.get_value()
        self.value_field.setText(value)

class ComboBoxEdit(DataWidget, Qt.QtWidgets.QWidget):

    def __init__(self, *args, **kwargs):
        super(ComboBoxEdit, self).__init__(*args, **kwargs)
        self.setFixedHeight(50)
        self.optional_values = False

    def do_layout(self):
        '''
        layout
        '''
        self.main_layout = Qt.QtWidgets.QGridLayout(self)
        self.main_layout.setSpacing(5)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.setLayout(self.main_layout)
        self.main_layout.setAlignment(Qt.QtCore.Qt.AlignTop | Qt.QtCore.Qt.AlignLeft)

        '''
        color indicator
        '''
        self.color_indicator = Qt.QtWidgets.QLabel(self)
        self.color_indicator.setFixedWidth(5)
        self.main_layout.addWidget(self.color_indicator, 0, 0, 1, 1, Qt.QtCore.Qt.AlignLeft)

        '''
        Key Label
        '''
        self.key_field = Qt.QtWidgets.QLabel('Main')
        self.main_layout.addWidget(self.key_field, 0, 1, 1, 1)
        self.key_field.setFixedWidth(100)

        '''
        Value Field
        '''
        self.value_field = Qt.QtWidgets.QComboBox(self)
        #self.value_field.setFixedWidth(200)
        self.main_layout.addWidget(self.value_field, 0, 2, 1, 1)
        self.value_field.activated['QString'].connect(partial(self.set_dirty, True))
        self.add_on_dirty_callback(partial(self.update_indicators))

    def update_indicators(self):
        '''
        indicator colors
        '''
        rgb_lookup = {}
        rgb_lookup[False] = [1,1,1,0.5]  # green
        rgb_lookup[True] = [0.639, .824, .455, 1]  # green
        # colors[True] = [0.847, .263, .145]  # red
        rgb = rgb_lookup[self.get_dirty()]
        rgb = [int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255)]

        '''
        setup stylesheet
        '''
        styleSheet = ''

        '''
        background color
        '''
        styleElement = 'background-color: rgb({0},{1},{2})'.format(*rgb)
        styleSheet += '{0};; '.format(styleElement)

        self.color_indicator.setStyleSheet(styleSheet)


    def update_from_widget(self):
        '''
        virtual override
        '''

        '''
        store value from widget into data
        '''
        self.set_value(self.value_field.currentText())

        '''
        clear dirty flags
        '''
        #self.set_dirty(False)

    def update_to_widget(self):
        self.set_block_updates(True)
        '''
        virtual override
        '''
        self.key_field.setText(self.get_key())

        '''
        add test numbers
        '''
        optional_values = self.get_optional_value()
        if not optional_values:
            optional_values = [self.get_value()]

        kwargs = {}
        kwargs['setCurrentItem'] = self.get_value()
        kwargs['sortItems'] = True
        kwargs['reverseSortOrder'] = True
        self.populateComboBox(self.value_field, optional_values, **kwargs)
        self.set_dirty(False)
        self.set_block_updates(False)

    @classmethod
    def populateComboBox(cls, combo_box, combo_items, **kwargs):
        reverseSortOrder = kwargs.get('reverseSortOrder', False)
        showBlank = kwargs.get('showBlank', False)
        setCurrentItem = kwargs.get('setCurrentItem', False)
        sortItems = kwargs.get('sortItems', False)

        '''
        signal blcokign
        '''
        combo_box.blockSignals(True)

        '''
        clear
        '''
        combo_box.clear()

        '''
        iterate items
        '''
        if combo_items:

            '''
            sorting
            '''
            if sortItems:
                combo_items = sorted(list(set(combo_items)), reverse=reverseSortOrder)

            '''
            first blank
            '''
            if showBlank:
                items = [''] + combo_items
            '''
            add items
            '''
            reference_index = 0
            for i, combo_item in enumerate(combo_items):
                item = Qt.QtGui.QStandardItem(str(combo_item))
                '''
                color
                '''
                if setCurrentItem:
                    if combo_item == setCurrentItem:
                        item.setForeground(Qt.QtGui.QColor(175, 255, 175, 255))
                        reference_index = i
                combo_box.model().appendRow(item)

            '''
            set current item
            '''
            combo_box.setCurrentIndex(reference_index)
        '''
        signal blcokign
        '''
        combo_box.blockSignals(False)

    def set_dirty(self, state, *args, **kwargs):
        '''
        detect change
        '''
        on_change = True
        '''
        if state != self.dirty_state:
            on_change = True
        '''
        self.update_from_widget()
        '''
        set
        '''
        self.dirty_state = state

        '''
        trigger dirty event
        '''
        if on_change:
            self.on_dirty_event()


class OptionsButtonEdit(DataWidget, Qt.QtWidgets.QWidget):

    def __init__(self, *args, **kwargs):
        super(OptionsButtonEdit, self).__init__(*args, **kwargs)
        self.setFixedHeight(50)
        self.optional_values = False
        self.active_value = False

    def do_layout(self):
        '''
        layout
        '''
        self.main_layout = Qt.QtWidgets.QGridLayout(self)
        self.main_layout.setSpacing(5)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.setLayout(self.main_layout)
        self.main_layout.setAlignment(Qt.QtCore.Qt.AlignTop | Qt.QtCore.Qt.AlignLeft)

        '''
        color indicator
        '''
        self.color_indicator = Qt.QtWidgets.QLabel(self)
        self.color_indicator.setFixedWidth(5)
        self.main_layout.addWidget(self.color_indicator, 0, 0, 1, 1, Qt.QtCore.Qt.AlignLeft)

        '''
        Key Label
        '''
        self.key_field = Qt.QtWidgets.QLabel('Main')
        self.main_layout.addWidget(self.key_field, 0, 1, 1, 1)
        self.key_field.setFixedWidth(100)

        '''
        Value Field
        '''
        self.value_field = Qt.QtWidgets.QLabel(self)
        self.main_layout.addWidget(self.value_field, 0, 2, 1, 1)
        self.add_on_dirty_callback(partial(self.update_indicators))

        '''
        info field, latest, newer available, etc
        '''

        '''
        right click menu
        '''
        self.popup_menu = Qt.QtWidgets.QMenu(self)
        self.setContextMenuPolicy(Qt.QtCore.Qt.CustomContextMenu)
        self.customContextMenuRequested.connect(self.right_click_menu)

    def right_click_menu(self, *args, **kwargs):
        self.popup_menu.clear()

        '''
        insert contents
        '''
        optional_values = self.get_optional_value()
        if not optional_values:
            optional_values = [self.get_value()]

        current_item = self.get_value()
        for v in optional_values:
            marker = ''
            if current_item == v:
                marker = '* '
            self.popup_menu.addAction('{0}{1}'.format(marker, v), partial(self.on_click_item, v))

        global_point= Qt.QtGui.QCursor.pos()
        self.popup_menu.exec_(global_point)

    def on_click_item(self, item):
        self.active_value = item
        self.set_dirty(True)

    def update_indicators(self):
        '''
        indicator colors
        '''
        rgb_lookup = {}
        rgb_lookup[False] = [1,1,1,0.5]  # green
        rgb_lookup[True] = [0.639, .824, .455, 1]  # green
        # colors[True] = [0.847, .263, .145]  # red
        rgb = rgb_lookup[self.get_dirty()]
        rgb = [int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255)]

        '''
        setup stylesheet
        '''
        styleSheet = ''

        '''
        background color
        '''
        styleElement = 'background-color: rgb({0},{1},{2})'.format(*rgb)
        styleSheet += '{0};; '.format(styleElement)

        self.color_indicator.setStyleSheet(styleSheet)

    def update_from_widget(self):
        '''
        store value from widget into data
        '''
        if self.active_value:
            self.set_value(self.active_value)

    def update_to_widget(self):
        self.set_block_updates(True)
        '''
        virtual override
        '''
        self.key_field.setText(self.get_key())

        '''
        add test numbers
        '''
        optional_values = self.get_optional_value()
        if not optional_values:
            optional_values = [self.get_value()]

        kwargs = {}
        kwargs['setCurrentItem'] = self.get_value()
        kwargs['sortItems'] = True
        kwargs['reverseSortOrder'] = True
        self.value_field.setText(self.get_value())
        self.active_value = self.get_value()
        self.set_dirty(False)
        self.set_block_updates(False)

    def set_dirty(self, state, *args, **kwargs):
        '''
        detect change
        '''
        on_change = True
        '''
        if state != self.dirty_state:
            on_change = True
        '''
        self.update_from_widget()
        '''
        set
        '''
        self.dirty_state = state

        '''
        trigger dirty event
        '''
        if on_change:
            self.on_dirty_event()