import zipfile
import os
import json
import shutil
import Scandir
from functools import partial
import sys
import traceback
import string
import copy
import re

from maya import cmds
from maya import mel

import Qt

import Prefs
import DataWidgets
reload(DataWidgets)
import DataTemplates
reload(DataTemplates)

import Grabby
reload(Grabby)

import PixoShop

'''
todo:

Prio

* drag/drop installer

* bug: clean up old buttons not working * fixed

* Package Manager Front end
    * Display contents with links to URLs * Done
    * product image * done

* Change logs

* When grabbing buttons, make sure to copy icon into images

* Setup github issues page, links to website

* simplify data structure, multiple buttons * done

* Button Builder
    * fix icon paths * done
    * remove old buttons * done
    * replace section of button command with correct paths * done

* __init__.py files in roots  * done

* validate dev package * done
* create template package * done
'''

'''
* package manager
1. Open Zip File
2. Remove old tool? version up?
3. Decompress file into right places
4. Create shelf if it doesnt exist
5. Add buttons from data file
'''

'''
* developer package maker
'''

'''
* pre installer
1. installer for the installer
2. create shelf
3. Add installer package and button
4. configure instal location
'''

'''
tool: "myTool"
version: "2.0.1"
location: "myTool"
description: "tool for doing xyz"
shelfData: []
'''


'''
#                      Package Manager Dev                       [CodePuncher Header Info] 
#/u/ecb/maya/scripts/CodePuncher/default.codepuncherpro [CodePuncher Header Info] 
import os
import sys
pathA = 'E:/Git/eblabs-hub/eblabs_hub/PackageManager/scripts'
pathB = '/u/ecb/Pictures/eblabs-hub/eblabs_hub/PackageManager/scripts' #
paths = [pathA, pathB]
for p in paths:
    if p not in sys.path:
        sys.path.append(p)
import PackageManager
reload(PackageManager)

w = PackageManager.Window()
w.display(mode = PackageManager.Mode.Dev)
#w.display(mode = PackageManager.Mode.User)

'''
__author__ = "Eric Bates, eblabs.com"
__copyright__ = "Copyright 2019, Eric Bates"
__credits__ = ["Eric Bates"]
__maintainer__ = "Eric Bates"
__email__ = "eric@eric-bates.com"
__status__ = "Production"
__version__ = '0.1.2019.08.27'

class UserModes:
    User = 1
    Dev = 2


class PrefsManager(Prefs.PrefsManager):
    instance = False

    @classmethod
    def getInstance(cls):
        '''
        override this method to set prefs group
        '''
        if not cls.instance:
            kwargs = {}
            kwargs['prefsGroup'] = 'PackageManagerEditor'
            cls.instance = Prefs.Prefs(**kwargs)
        return cls.instance

    @classmethod
    def print_basic_info(cls):
        default_value = os.path.normpath(os.path.join(cmds.internalVar(userAppDir=True), 'scripts', 'eblabs_hub'))
        user_path = PrefsManager.getProperty('install_path', default_value)
        dev_path =  PrefsManager.getProperty('dev_folder', False)

        print('##### Package Manager #####')
        print('version: {0}'.format(__version__))
        print('user_path: {0}'.format(user_path))
        print('dev_path: {0}'.format(dev_path))


class Window(Qt.QtWidgets.QDialog):

    def __init__(self, *args, **kwargs):
        parent = QTHelpers.get_main_window()

        '''
        set parent
        '''
        super(Window, self).__init__(parent)

        '''
        set title
        '''
        windowTitle = "eblabs Package Manager"

        '''
        '''
        self.setObjectName(windowTitle)
        self.setWindowTitle(windowTitle)

        '''
        main layout for Document
        '''
        self.main_layout = VBoxLayout(self)
        self.main_layout.setObjectName('main_layout')
        self.main_layout.setAlignment(Qt.QtCore.Qt.AlignTop)
        self.setLayout(self.main_layout)

    def display(self, mode = UserModes.User):
        '''
        set mode
        '''
        PrefsManager.setProperty('mode', mode)

        '''
        set mode
        '''
        mode = PrefsManager.getProperty('mode', UserModes.User)
        windowTitle = "eblabs Package Manager"
        if mode == UserModes.Dev:
            windowTitle += '** Developer'
        self.setObjectName(windowTitle)
        self.setWindowTitle(windowTitle)

        '''
        deffered add document
        '''
        self.main_document = Document(self)
        self.main_layout.addWidget(self.main_document)

        '''
        set size
        '''
        self.resize(900, 700)
        self.show()

        '''
        debugging
        '''
        if mode == UserModes.Dev:
            PrefsManager.print_basic_info()


class Document(Qt.QtWidgets.QWidget):
    '''
    Display Packages and Information
    '''

    def __init__(self, *args, **kwargs):
        super(Document, self).__init__(*args, **kwargs)
        '''
        internal data
        '''
        self.internal_data = {}
        self.pages = {}
        mode = PrefsManager.getProperty('mode', UserModes.User)

        '''
        on change callback
        '''
        self.onChangeCallback = False

        '''
        main layout
        '''
        self.main_layout = GridLayout(self)
        self.main_layout.setAlignment(Qt.QtCore.Qt.AlignTop | Qt.QtCore.Qt.AlignLeft)

        '''
        menu bar
        '''
        self.main_menu_bar = Qt.QtWidgets.QMenuBar(self)
        self.main_layout.addWidget(self.main_menu_bar, 0, 0, 1, 2)
        self.main_layout.setAlignment(self.main_menu_bar, Qt.QtCore.Qt.AlignLeft)

        '''
        build menus
        '''
        self.add_user_menu_items(self.main_menu_bar)
        if mode == UserModes.Dev:
            self.add_dev_menu_items(self.main_menu_bar)

        '''
        right tabs
        '''
        self.right_tab_area = Qt.QtWidgets.QTabWidget(self)
        self.main_layout.addWidget(self.right_tab_area, 1, 2, 1, 1)

        '''
        User Tab
        '''
        self.user_tab = UserPage(self)
        self.right_tab_area.addTab(self.user_tab, 'Info')

        '''
        check mode
        '''
        mode = PrefsManager.getProperty('mode', UserModes.User)

        '''
        Dev Tab
        '''
        if mode == UserModes.Dev:
            '''
            add dev mode tab
            '''
            self.dev_tab = DevPage(self)
            self.right_tab_area.addTab(self.dev_tab, 'Dev')

            '''
            on change callback
            '''
            self.dev_tab.add_keyword_callback('on_save', self.update_package_list_data)

            '''
            set current
            '''
            self.right_tab_area.setCurrentIndex(1)

        '''
        left options
        '''
        self.page_list = Qt.QtWidgets.QListWidget(self)
        self.page_list.setVerticalScrollMode(Qt.QtWidgets.QAbstractItemView.ScrollPerPixel)
        self.page_list.itemPressed.connect(self.on_selection_change)

        self.main_layout.addWidget(self.page_list, 1, 0, 1, 1)
        self.page_list.setFixedWidth(300)

        '''
        populate list
        '''
        self.populate_package_list()
        self.package_list_set_initial_selection()
        self.on_selection_change()

    def package_list_set_initial_selection(self):
        '''
        '''
        if self.page_list.count():
            self.page_list.setCurrentRow(0)

    def add_dev_menu_items(self, menu):
        '''
        add menu
        '''
        dev_menu = menu.addMenu("Dev Menu")

        '''
        Confix
        '''
        sub_menu = dev_menu.addMenu('Config')
        sub_menu.addAction("Set Dev Folder", self.set_dev_folder)

        '''
        Packages
        '''
        sub_menu = dev_menu.addMenu('Packages')
        sub_menu.addAction("Create Package", self.create_package)
        sub_menu.addAction("Validate Package", self.validate_package)

        '''
        Templates
        '''
        sub_menu = dev_menu.addMenu('Templates')
        sub_menu.addAction("Create Empty Package Structure", self.create_empty_package_structure)
        sub_menu.addAction("Reset Current Package Data File", self.reset_current_data_file)

        '''
        shelf
        '''
        sub_menu = dev_menu.addMenu('Shelf')
        sub_menu.addAction("Create Template Button", self.create_template_button)


    def add_user_menu_items(self, menu):
        '''
        main menu, User
        '''
        main_menu = menu.addMenu("Main Menu")

        '''
        Packages
        '''
        sub_menu = main_menu.addMenu('Packages')
        sub_menu.addAction("Add Package", self.install_package)

    def reset_current_data_file(self):
        '''
        get current package location
        data_filepath = /u/ecb/Pictures/eblabs-hub/eblabs_hub/WorldSpaceTools/data/eblabs.data
        '''
        data_filepath = self.get_current_data_filepath()
        data_filepath = os.path.normpath(data_filepath)
        split_path = data_filepath.split(os.sep)
        split_path = list(filter(None, split_path))

        '''
        package location
        (331, 'data_filepath', [u'u', u'ecb', u'Pictures', u'eblabs-hub', u'eblabs_hub', u'WorldSpaceTools', u'data', u'eblabs.data'])
        '''
        location = split_path[-3]
        #print(342, 'location', location)

        '''
        get root path
        '''
        root_path = Utils.get_working_path(mode = UserModes.Dev)

        '''
        get new data
        '''
        data = DataTemplates.Templates.get_package_data_template()
        data['location'] = location
        data['package'] = Utils.camel_case_to_label(location)

        '''
        save
        '''
        #path = os.path.normpath(os.path.join(root_path, location, 'data', 'eblabs.data'))
        FileUtils.write_json_file(data_filepath, data)

        '''
        update UI
        '''
        self.update_package_list_data()
        self.on_selection_change()

    def create_empty_package_structure(self):
        '''
        get locationName from user
        '''
        kwargs = {}
        kwargs['parentWidget'] = self
        kwargs['titleText'] = 'New Package Location'
        kwargs['labelText'] = 'Input Below'
        kwargs['successCallback'] = self.create_empty_package_structure_exec
        QTHelpers.getStringFromUser(**kwargs)


    def create_empty_package_structure_exec(self, return_text):
        '''
        validate text
        '''
        valid_text = FileUtils.validateText(return_text)
        if not valid_text:
            return False

        '''
        create subfolder 
        '''
        root_path = Utils.get_working_path(mode = UserModes.Dev)
        package_path = os.path.normpath(os.path.join(root_path, valid_text))

        '''
        create core folders
        '''
        core_folders = DataTemplates.Templates.get_core_folders_list()
        for c in core_folders:
            core_path = os.path.normpath(os.path.join(package_path, c))
            '''
            generate new folder
            '''
            try:
                if not os.path.exists(core_path):
                    os.makedirs(core_path)
            except Exception as e:
                pass

        '''
        get new data
        '''
        data = DataTemplates.Templates.get_package_data_template()
        data['location'] = valid_text
        data['package'] = valid_text + ' NEW'

        '''
        add init files
        '''
        init_files = []
        path = os.path.normpath(os.path.join(package_path, '__init__.py'))
        init_files.append(path)
        path = os.path.normpath(os.path.join(package_path, 'scripts', '__init__.py'))
        init_files.append(path)
        path = os.path.normpath(os.path.join(package_path, 'images', 'placeholder.jpg'))
        init_files.append(path)
        for f in init_files:
            if not os.path.isfile(f):
                FileUtils.touch(f)

        '''
        save
        '''
        data_filepath = os.path.normpath(os.path.join(package_path, 'data', 'eblabs.data'))
        FileUtils.write_json_file(data_filepath, data)

        '''
        update UI
        '''
        self.populate_package_list()
        self.update_package_list_data()
        self.on_selection_change()


    def create_package(self):
        '''
        create package output name, using version, and package name, store to "versions" folder
        '''
        dev_path = Utils.get_working_path(mode = UserModes.Dev)
        if not dev_path:
            print(291)
            return False
        data_value = self.get_current_data()
        if not data_value:
            print
            return False

        '''
        generate folder and output path
        '''
        output_file = 'eblabs_{0}_{1}.zip'.format(data_value['location'], data_value['version'])
        output_path = os.path.normpath(os.path.join(dev_path, data_value['location'], 'versions'))

        '''
        generate new folders
        '''
        try:
            if not os.path.exists(output_path):
                os.makedirs(output_path)
        except Exception as e:
            print(310, 'generate new folders FAILED', Exception, e)
            return False
        output_path = os.path.normpath(os.path.join(output_path, output_file))

        '''
        overwrite?
        '''
        proceed = True
        if os.path.isfile(output_path):
            print(320, 'Overwriting:', output_path)

        '''
        gather files
        '''
        files_list = {}
        d = DataTemplates.Templates.get_core_folders_list_and_types()
        for sub_folder, file_types in d.iteritems():
            path = os.path.normpath(os.path.join(dev_path, data_value['location'], sub_folder ))
            files = FileUtils.getFilesInFolder(path, file_types)
            files_list[sub_folder] = files

        '''
        write package
        '''
        with zipfile.ZipFile(output_path, 'w') as z:
            '''
            itterate subfolder groups
            '''
            for subfolder, files in files_list.iteritems():
                '''
                iterate files
                '''
                for f in files:
                    '''
                    breakdown for zip archive
                    '''
                    folderName, baseFileName, fileExtension = FileUtils.getFileNameParts(f)
                    '''
                    add file
                    '''
                    z.write(f, '{0}//{1}.{2}'.format(subfolder, baseFileName, fileExtension))


    def create_template_button(self):
        '''
        '''
        Utils.create_template_button()

    def get_current_data(self):
        '''
        get active datafile
        '''
        data_file = self.get_current_data_filepath()
        if not data_file:
            return False
        '''
        load json data 
        '''
        data_value = {}
        try:
            data_value = FileUtils.read_json_file(data_file)
        except Exception as e:
            data_value = {}
        if not data_value:
            data_value = {}
        return data_value


    def get_current_data_filepath(self):
        '''
        get selected items
        '''
        current_item = self.page_list.currentItem()
        if not current_item:
            return False
        '''
        get widget from item
        '''
        widget = self.page_list.itemWidget(current_item)
        data_file = False
        try:
            data_file = widget.get_key()
        except Exception as e:
            print(283, Exception, e)
        if not data_file:
            return False
        return data_file

    def on_selection_change(self, *args, **kwargs):
        '''
        check mode
        '''
        mode = PrefsManager.getProperty('mode', UserModes.User)

        '''
        get active datafile
        '''
        data_file = self.get_current_data_filepath()
        if not data_file:
            return False

        '''
        User Page
        '''
        self.user_tab.set_key(data_file)
        self.user_tab.update_to_widget()
        '''
        Dev Page
        '''
        if mode == UserModes.Dev:
            self.dev_tab.set_key(data_file)
            self.dev_tab.update_to_widget()

    def set_dev_folder(self):
        '''
        setup query
        '''
        title = 'Set Development Folder'
        target_folder = PrefsManager.getProperty('dev_folder', False)

        '''
        get folder from user
        '''
        filepath = QTHelpers.get_folder_from_user(title=title, target_folder=target_folder)

        '''
        set dev path
        '''
        if filepath:
            PrefsManager.setProperty('dev_folder', filepath)

    def validate_package(self):
        Utils.install_package(for_real = False)

    def install_package(self):
        print(170, 'add package')
        '''
        browse and install package
        '''
        Utils.install_package()

        '''
        refresh view
        '''
        self.populate_package_list()


    def update_package_list_data(self):
        '''
        get selected items
        '''
        current_item = self.page_list.currentItem()
        if not current_item:
            return False
        '''
        get widget from item
        '''
        widget = self.page_list.itemWidget(current_item)
        try:
            data_file = widget.get_key()
            widget.set_key(data_file)
            widget.update_to_widget()
        except Exception as e:
            print(283, Exception, e)


    def populate_package_list(self):
        '''
        clear list
        '''
        self.page_list.clear()

        '''
        get packages
        '''
        self.internal_data = Utils.get_packages_basic_info()
        if not self.internal_data:
            return False

        '''
        test
        '''
        for sub_folder, data_file_path in self.internal_data:
            '''
            create labels and info
            '''
            widget = PackageListItemWidget()
            item = Qt.QtWidgets.QListWidgetItem('', self.page_list)
            item.setSizeHint(Qt.QtCore.QSize(self.page_list.contentsSize().width(), 40))

            '''
            set list items/widgets
            '''
            self.page_list.addItem(item)
            self.page_list.setItemWidget(item, widget)

            '''
            set labels
            '''
            widget.set_key(data_file_path)
            widget.update_to_widget()


class PackageListItemWidget(DataWidgets.DataWidget, Qt.QtWidgets.QWidget):
    def __init__(self, *args, **kwargs):
        super(PackageListItemWidget, self).__init__(*args, **kwargs)

    def do_layout(self):
        '''
        layout
        '''
        self.main_layout = GridLayout(self)
        self.setLayout(self.main_layout)

        '''
        Main Label
        '''
        self.main_label = Qt.QtWidgets.QLabel('Main')
        self.main_layout.addWidget(self.main_label, 0, 0, 1, 1)

        '''
        Sub Label
        '''
        self.sub_label = Qt.QtWidgets.QLabel('Sub')
        self.main_layout.addWidget(self.sub_label, 0, 1, 1, 1, Qt.QtCore.Qt.AlignRight)

    def set_key(self, key):
        '''
        store key
        '''
        self.data_key = key

        '''
        load json data internally
        '''
        data_value = {}
        try:
            data_value = FileUtils.read_json_file(self.data_key)
        except Exception as e:
            data_value = {}
        if not data_value:
            data_value = {}

        '''
        store
        '''
        self.set_value(data_value)

    def update_to_widget(self):
        '''
        set labels
        https://html-online.com/editor/
        '''
        data = self.get_value()
        text = data.get('package', 'NOT SET')
        text = '<h3><strong>{0}</strong></h3>'.format(text)
        self.main_label.setText(text)
        text = data.get('version', 'NOT SET')
        self.sub_label.setText(text)


class UserPage(DataWidgets.DataWidgetCollection, Qt.QtWidgets.QWidget):

    def __init__(self, *args, **kwargs):
        #
        self.version_widget = False
        super(UserPage, self).__init__(*args, **kwargs)



    def do_layout(self):
        '''
        update blocking
        '''
        self.set_block_updates(True)

        '''
        layout
        '''
        page_layout = Qt.QtWidgets.QGridLayout(self)
        page_layout.setColumnStretch(0,1)
        self.setLayout(page_layout)

        '''
        scroll area layout
        '''
        scroll_area_widget = Qt.QtWidgets.QScrollArea(self)
        scroll_area_widget.setWidgetResizable(True)
        scroll_area_widget.setVerticalScrollBarPolicy(Qt.QtCore.Qt.ScrollBarAsNeeded)
        page_layout.addWidget(scroll_area_widget, 0,0,1,1)

        '''
        layout + widget
        '''
        w = Qt.QtWidgets.QWidget(self)
        self.main_layout = Qt.QtWidgets.QVBoxLayout(w)
        w.setLayout(self.main_layout)
        scroll_area_widget.setWidget(w)

        self.main_layout.setAlignment(Qt.QtCore.Qt.AlignLeft | Qt.QtCore.Qt.AlignTop)
        self.main_layout.setSpacing(3)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        '''
        widget types
        '''
        widget_types = {}
        widget_types['singleLine'] = DataWidgets.TextLineDisplay
        widget_types['singleLineHeader'] = DataWidgets.TextLineDisplayHeader
        widget_types['multiLine'] = DataWidgets.TextMultiDisplay
        widget_types['url'] = DataWidgets.URLDisplay
        widget_types['versionCombo'] = DataWidgets.ComboBoxEdit
        widget_types['shelfButtonGroup'] = ButtonListWidgetViewer



        #widget_types['shelfButtonGroup'] = EditorButtonWidget

        '''
        add widgets for keywords
        '''
        keywords_config = []
        keywords_config.append(['package', 'singleLineHeader'])
        #keywords_config.append(['location', 'singleLine'])
        keywords_config.append(['version', 'versionCombo'])
        keywords_config.append(['shelf_data', 'shelfButtonGroup'])
        keywords_config.append(['website', 'url'])
        keywords_config.append(['support', 'url'])
        keywords_config.append(['description', 'multiLine'])
        self.keyword_lookup = {}
        for k, t in keywords_config:
            '''
            create widget
            '''
            w = widget_types[t](self)
            self.add_widget(k, w)

            '''
            set data
            '''
            w.set_key(k)
            w.set_value('')
            w.set_parent_data(False)
            w.update_to_widget()

            '''
            widget callbacks
            '''
            #w.add_on_dirty_callback(partial(self.set_dirty, True))
            #w.add_on_dirty_callback(self.update_indicators)

            '''
            layout
            '''
            self.main_layout.addWidget(w, stretch=1)
            self.keyword_lookup[k] = w

        '''
        setup version box
        '''
        self.version_widget = self.get_matching_widget_for_key('version')
        if self.version_widget:
            self.version_widget.add_on_dirty_callback(self.on_version_combo_box_change)

        '''
        update blocking
        '''
        self.set_dirty(False)
        self.set_block_updates(False)


    def debugging(self, widget):
        '''
        indicator colors
        '''
        rgb = [1,1,1,0.5]  # white
        rgb = [int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255)]

        '''
        setup stylesheet
        '''
        styleSheet = ''

        '''
        background color
        '''
        styleElement = 'background-color: rgb({0},{1},{2},{3})'.format(*rgb)
        styleSheet += '{0};; '.format(styleElement)

        widget.setStyleSheet(styleSheet)

    def set_key(self, key):
        '''
        update blocking
        '''
        self.set_block_updates(True)

        '''
        store key
        '''
        self.data_key = key

        '''
        load json data internally
        '''
        data_value = {}
        try:
            data_value = FileUtils.read_json_file(self.data_key)
        except Exception as e:
            data_value = {}
        if not data_value:
            data_value = {}

        '''
        store
        '''
        self.set_value(data_value)

        '''
        update blocking
        '''
        self.set_dirty(False)
        self.set_block_updates(False)


    def update_to_widget(self):
        '''
        update blocking
        '''
        self.set_block_updates(True)

        '''
        data
        '''
        for (k, w) in self.keyword_lookup.items():
            value = self.get_value().get(k, 'NOT SET')
            w.set_block_updates(True)
            w.set_key(k)
            w.set_value(value)
            w.set_parent_data(self.get_value())
            w.update_to_widget()
            w.set_block_updates(False)


        '''
        setup version box
        '''
        #version_widget = self.get_matching_widget_for_key('version')
        if self.version_widget:
            '''
            block updates
            '''
            self.version_widget.set_block_updates(True)

            '''
            get potential version
            '''
            data_filepath = os.path.normpath(self.get_key())
            potential_versions = Utils.get_potential_versions(data_filepath)
            #print(958, 'set_optional_value', potential_versions)
            self.set_optional_value(potential_versions)

            '''
            update combobox            
            '''
            versions = potential_versions.keys()
            self.version_widget.set_optional_value(versions)
            self.version_widget.update_to_widget()

            '''
            block updates
            '''
            self.version_widget.set_block_updates(False)

        '''
        update blocking
        '''
        self.set_dirty(False)
        self.set_all_dirty(False)
        self.set_block_updates(False)


    def on_version_combo_box_change(self, *args, **kwargs):
        if not self.get_block_updates():
            if self.version_widget:
                '''
                get data
                '''
                current_version = self.version_widget.get_value()
                version_data = self.get_optional_value()
                install_package = version_data.get(current_version, False)
                if not install_package:
                    return False

                '''
                install command
                '''
                command = partial(Utils.install_package, filepaths = [install_package])

                '''
                package file
                '''
                kwargs = {}
                kwargs['parentWidget'] = self
                kwargs['titleText'] = 'Install Package'
                kwargs['messageText'] = 'Install Version {0}'.format(current_version)
                kwargs['successCallback'] = command
                QTHelpers.getYesNoFromUser(**kwargs)


class DevPage( DataWidgets.DataWidgetCollection, Qt.QtWidgets.QWidget ):

    def __init__(self, *args, **kwargs):
        super(DevPage, self).__init__(*args, **kwargs)

    def do_layout(self):
        '''
        update blocking
        '''
        self.set_block_updates(True)

        '''
        layout
        '''
        page_layout = Qt.QtWidgets.QGridLayout(self)
        self.setLayout(page_layout)

        '''
        path button
        '''
        self.path_button = Qt.QtWidgets.QPushButton('', self)
        self.path_button.clicked.connect(self.on_click_path_button)
        page_layout.addWidget(self.path_button, 0, 0, 1, 1)

        '''
        scroll area layout
        '''
        scroll_area_widget = Qt.QtWidgets.QScrollArea(self)
        scroll_area_widget.setWidgetResizable(True)
        scroll_area_widget.setVerticalScrollBarPolicy(Qt.QtCore.Qt.ScrollBarAsNeeded)

        page_layout.addWidget(scroll_area_widget, 1,0,1,1)

        '''
        popup  save button
        '''
        self.save_button = Qt.QtWidgets.QPushButton('Save', self )
        self.save_button.clicked.connect(self.on_click_save)
        page_layout.addWidget(self.save_button, 2, 0, 1, 1)

        '''
        layout + widget
        '''
        w = Qt.QtWidgets.QWidget(self)
        self.main_layout = Qt.QtWidgets.QVBoxLayout(w)
        w.setLayout(self.main_layout)
        scroll_area_widget.setWidget(w)

        self.main_layout.setAlignment(Qt.QtCore.Qt.AlignLeading | Qt.QtCore.Qt.AlignTop)
        self.main_layout.setSpacing(0)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        '''
        widget types
        '''
        widget_types = {}
        widget_types['singleLine'] = DataWidgets.TextLineEdit
        widget_types['multiLine'] = DataWidgets.TextMultiEdit
        widget_types['shelfButtonGroup'] = ButtonListWidgetEdit

        '''
        add widgets for keywords
        '''
        keywords_config = []
        keywords_config.append(['package', 'singleLine'])
        keywords_config.append(['location', 'singleLine'])
        keywords_config.append(['version', 'singleLine'])
        keywords_config.append(['shelf_data', 'shelfButtonGroup'])
        keywords_config.append(['website', 'singleLine'])
        keywords_config.append(['support', 'singleLine'])
        keywords_config.append(['description', 'multiLine'])
        self.keyword_lookup = {}
        for k, t in keywords_config:
            '''
            create widget
            '''
            w = widget_types[t](self)
            self.add_widget(k, w)

            '''
            set data
            '''
            w.set_key(k)
            w.set_value('')
            w.set_parent_data(False)

            w.update_to_widget()

            '''
            widget callbacks
            '''
            w.add_on_dirty_callback(partial(self.set_dirty, True))
            w.add_on_dirty_callback(self.update_indicators)

            '''
            layout
            '''
            self.main_layout.addWidget(w, stretch=0)
            self.keyword_lookup[k] = w

        '''
        self callback
        '''
        self.add_on_dirty_callback(self.update_indicators)

        '''
        update blocking
        '''
        self.set_block_updates(False)
        self.set_dirty(False)

    def on_click_path_button(self):
        file_path =self.get_key()
        folderName, filename = os.path.split(file_path)
        FileUtils.browseFolder(folderName)

    def on_click_save(self):
        '''
        get data
        '''
        self.update_all_from_widget()
        data = self.get_value()
        data = self.get_all_value(data=data)

        '''
        make sure that location and actual path match
        '''
        path_parts = self.get_key().split(os.sep)
        subfolder = path_parts[-3]
        if subfolder != data['location']:
            print('Correcting Location to :', subfolder)
            data['location'] = subfolder

        '''
        '''
        self.set_value(data)

        '''
        write data to json file
        '''
        FileUtils.write_json_file(self.get_key(), self.get_value())

        '''
        reset all indicators
        '''
        self.set_all_dirty(False)
        self.call_keyword_callback('on_save')

    def set_key(self, key):
        '''
        update blocking
        '''
        self.set_block_updates(True)

        '''
        store key
        '''
        self.data_key = key

        '''
        load json data internally
        '''
        data_value = {}
        try:
            data_value = FileUtils.read_json_file(self.data_key)
        except Exception as e:
            data_value = {}
        if not data_value:
            data_value = {}

        '''
        store
        '''
        self.set_value(data_value)


        '''
        update blocking
        '''
        self.set_block_updates(False)
        self.set_dirty(False)

    def update_from_widget(self):
        '''
        virtual override
        '''

    def update_to_widget(self):
        '''
        update blocking
        '''
        self.set_block_updates(True)

        '''
        data
        '''
        for (k, w) in self.keyword_lookup.items():
            value = self.get_value().get(k, 'NOT SET')
            w.set_key(k)
            w.set_value(value)
            w.set_parent_data(self.get_value())
            w.update_to_widget()

        '''
        path button
        '''
        self.path_button.setText(self.get_key())

        '''
        update blocking
        '''
        self.set_block_updates(False)
        self.set_dirty(False)
        self.update_indicators()

    def update_indicators(self):
        '''
        indicator colors
        '''
        rgb_lookup = {}
        rgb_lookup[False] = [0.3, 0.3, 0.3, 1]  # white
        rgb_lookup[True] = [0.639, .824, .455, 1]  # green
        # colors[True] = [0.847, .263, .145]  # red
        state = self.get_dirty()
        if not state:
            state = False
        rgb = rgb_lookup[state]
        rgb = [int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255)]

        '''
        setup stylesheet
        '''
        styleSheet = ''

        '''
        background color
        '''
        styleElement = 'background-color: rgb({0},{1},{2})'.format(*rgb)
        styleSheet += '{0};; '.format(styleElement)

        self.save_button.setStyleSheet(styleSheet)


class ButtonListWidgetEdit(DataWidgets.DataWidget, Qt.QtWidgets.QWidget):

    def __init__(self, *args, **kwargs):
        super(ButtonListWidgetEdit, self).__init__(*args, **kwargs)

    def do_layout(self):
        '''
        layout
        '''
        page_layout = Qt.QtWidgets.QGridLayout(self)
        page_layout.setSpacing(10)
        page_layout.setContentsMargins(0,0,0,0)
        self.setLayout(page_layout)
        page_layout.setColumnStretch(2,1)

        '''
        general sizing
        '''
        height = MayaUtils.get_dpi_scaled_value(60)

        '''
        color indicator
        '''
        self.color_indicator = Qt.QtWidgets.QLabel(self)
        self.color_indicator.setFixedSize(Qt.QtCore.QSize(5, height))
        page_layout.addWidget(self.color_indicator, 0,0,1,1, Qt.QtCore.Qt.AlignLeft)

        '''
        grabby
        '''
        add_button = Grabby.GrabbyWidget(self) # Qt.QtWidgets.QPushButton('+', self)
        add_button.set_dpi_scale_factor(MayaUtils.get_dpi_scaling())
        add_button.set_target_widget_types((Qt.QtWidgets.QPushButton))
        add_button.set_is_valid_check(True)
        add_button.set_release_callback(self.grabby_callback)

        size = MayaUtils.get_dpi_scaled_value(60)

        add_button.setFixedSize(Qt.QtCore.QSize(size,size))
        page_layout.addWidget(add_button, 0, 1, 1, 1, Qt.QtCore.Qt.AlignLeft)

        '''
        button icon list
        '''
        self.button_list = Qt.QtWidgets.QToolBar(self)
        self.button_list.setSizePolicy(Qt.QtWidgets.QSizePolicy.Maximum, Qt.QtWidgets.QSizePolicy.Expanding)
        size = MayaUtils.get_dpi_scaled_value(60)
        self.button_list.setIconSize(Qt.QtCore.QSize(size,size))
        page_layout.addWidget(self.button_list, 0, 2, 1, 1, Qt.QtCore.Qt.AlignLeft)

        '''
        callbacks
        '''
        self.add_on_dirty_callback(partial(self.update_indicators))


    def grabby_callback(self, mayaPointer):
        '''
        extract shelf data
        '''
        shelf_data = MayaUtils.extractShelfButtonData(mayaPointer)

        '''
        append button to data
        '''
        data = self.get_value()
        data.append(shelf_data)
        self.set_value(data)

        '''
        indicate change
        '''
        self.update_indicators()
        self.update_to_widget(dirty_state=True)

    def get_parent_data(self):
        '''
        inject new data to 'parent data as well'
        '''
        if self.data_parent:
            self.data_parent['shelf_data'] = self.get_value()
        return self.data_parent

    def update_indicators(self):
        '''
        indicator colors
        '''
        rgb_lookup = {}
        rgb_lookup[False] = [1,1,1,0.5]  # green
        rgb_lookup[True] = [0.639, .824, .455, 1]  # green
        # colors[True] = [0.847, .263, .145]  # red
        rgb = rgb_lookup[self.get_dirty()]
        rgb = [int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255)]

        '''
        setup stylesheet
        '''
        styleSheet = ''

        '''
        background color
        '''
        styleElement = 'background-color: rgb({0},{1},{2})'.format(*rgb)
        styleSheet += '{0};; '.format(styleElement)

        self.color_indicator.setStyleSheet(styleSheet)

    def update_from_widget(self):
        '''
        clear dirty flags
        '''
        self.set_dirty(False)

    def update_to_widget(self, dirty_state = False):
        '''
        clear list
        '''
        self.button_list.clear()

        '''
        get data
        '''
        value = self.get_value()

        '''
        set icons
        '''
        for i, d in enumerate(value):
            '''
            item
            '''
            #item = Qt.QtWidgets.QListWidgetItem('', self.button_list)
            #item.setSizeHint(Qt.QtCore.QSize(32,32))

            '''
            check if icon exists
            '''
            #print(1224, i, d)
            qpixmap = self.get_pixmap_for_data_icon(i)

            '''
            add image
            '''
            if not qpixmap:
                w = 32
                h = 32
                #rgb = [1, 1, .4, 1]  # yellow
                rgb = [0.847, .263, .145, 1]  # red
                qcolor = Qt.QtGui.QColor(int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255))
                qpixmap = PixoShop.Actions.qImageCanvas(width=w, height=h, fillColor=qcolor)
                #qicon = PixoShop.Actions.convertToIcon(qimage)


            qicon = PixoShop.Actions.convertToIcon(qpixmap)


            #item.setIcon(qicon)

            '''
            set list items/widgets
            '''
            #self.button_list.addItem(item)

            '''
            test toolbar
            '''
            w = Qt.QtWidgets.QToolButton()
            #w = Qt.QtWidgets.QPushButton()
            w.setIcon(qicon)
            #w.setIconSize(Qt.QtCore.QSize(20,20))
            #btn_close.setFixedSize(16, 16)
            w.clicked.connect(partial(self.on_tool_button_press, i))

            #menu = Qt.QtWidgets.QMenu()
            w.setContextMenuPolicy(Qt.QtCore.Qt.CustomContextMenu)
            w.customContextMenuRequested.connect(partial(self.on_tool_button_right_click,w, i))


            self.button_list.addWidget(w)
            #self.button_list.addAction(qicon, '')

        '''
        add spacer for left align
        '''
        #spacer = Qt.QtWidgets.QWidget(self.button_list)
        #spacer.setSizePolicy( Qt.QtWidgets.QSizePolicy.Expanding,  Qt.QtWidgets.QSizePolicy.Expanding)
        #self.button_list.addWidget(spacer)

        '''
        dirty update
        '''
        self.set_dirty(dirty_state)

    def on_tool_button_right_click(self, widget, index_int, position):
        # create menu
        popupMenu = Qt.QtWidgets.QMenu(self)


        # sync selections state
        popupMenu.addSeparator()
        description = 'Delete Button {0}'.format(index_int)
        command = partial(self.delete_shelf_button, index_int)
        action = popupMenu.addAction(description, command)
        #action.setCheckable(True)
        #action.setChecked(self.getSyncMayaSelectionsState())
        #action.toggled.connect(command)


        # draw popup
        popupMenu.exec_(widget.mapToGlobal(position))

    def delete_shelf_button(self, index_int):
        '''
        set button data
        '''
        data = self.get_value()
        del data[index_int]
        self.set_value(data)

        '''
        indicate change
        '''
        self.update_indicators()
        self.update_to_widget(dirty_state=True)

    def on_tool_button_press(self, index_int):
        print(1009, 'on_tool_button_press', index_int)
        pretty = json.dumps(self.get_value()[index_int], sort_keys=True, indent=4)
        print(pretty)

    def set_value(self, value):
        '''
        store value
        '''
        if not value:
            value = []
        self.data_value = value

    def get_pixmap_for_data_icon(self, shelf_button_index):
        data = self.get_parent_data()
        if not data:
            return False

        '''
        find icon in local folder
        '''
        #print(1331, 'data', len(data), type(data), data, 'shelf_button_index')
        #print(1331, 'shelf_button_index', shelf_button_index)
        icon_filename = Utils.get_icon_path_from_data(data, shelf_button_index = shelf_button_index, mode = UserModes.Dev)
        if not icon_filename:
            return False

        '''
        check if full path or shortpath
        '''
        if os.path.isfile(icon_filename):
            pixmap = PixoShop.Actions.loadPixmapFromPathSimple(icon_filename)
        else:
            pixmap = MayaUtils.getPixmapForPath(icon_filename)

        '''
        scale up to fit within 100x100
        '''
        target_dimension = 100
        longest_dimension = max(pixmap.width(), pixmap.height())
        scale_factor = target_dimension / float(longest_dimension)
        new_width = pixmap.width() * scale_factor
        new_height = pixmap.height() * scale_factor
        pixmap = pixmap.scaled(new_width, new_height, Qt.QtCore.Qt.KeepAspectRatio,
                                         Qt.QtCore.Qt.SmoothTransformation)

        return pixmap



class ButtonListWidgetViewer(DataWidgets.DataWidget, Qt.QtWidgets.QWidget):

    def __init__(self, *args, **kwargs):
        super(ButtonListWidgetViewer, self).__init__(*args, **kwargs)

    def do_layout(self):
        '''
        general sizing
        '''
        height = MayaUtils.get_dpi_scaled_value(60)

        '''
        layout
        '''
        page_layout = Qt.QtWidgets.QGridLayout(self)
        page_layout.setAlignment(Qt.QtCore.Qt.AlignLeading | Qt.QtCore.Qt.AlignTop)
        page_layout.setSpacing(10)
        page_layout.setContentsMargins(0,0,0,0)
        self.setFixedHeight(height)
        self.setLayout(page_layout)
        page_layout.setColumnStretch(2,1)

        '''
        button icon list
        '''
        self.button_list = Qt.QtWidgets.QToolBar(self)
        #self.button_list.setSizePolicy(Qt.QtWidgets.QSizePolicy.Maximum, Qt.QtWidgets.QSizePolicy.Expanding)
        size = MayaUtils.get_dpi_scaled_value(50)
        self.button_list.setIconSize(Qt.QtCore.QSize(size,size))
        page_layout.addWidget(self.button_list, 0, 2, 1, 1, Qt.QtCore.Qt.AlignLeft)

        '''
        callbacks
        '''
        self.add_on_dirty_callback(partial(self.update_indicators))

    def update_to_widget(self, dirty_state = False):
        '''
        clear list
        '''
        self.button_list.clear()

        '''
        get data
        '''
        value = self.get_value()

        '''
        set icons
        '''
        for i, d in enumerate(value):
            '''
            add image
            '''
            qpixmap = self.get_pixmap_for_data_icon(i)
            if not qpixmap:
                w = 32
                h = 32
                #rgb = [1, 1, .4, 1]  # yellow
                rgb = [0.847, .263, .145, 1]  # red
                qcolor = Qt.QtGui.QColor(int(rgb[0] * 255), int(rgb[1] * 255), int(rgb[2] * 255), int(rgb[3] * 255))
                qpixmap = PixoShop.Actions.qImageCanvas(width=w, height=h, fillColor=qcolor)
            qicon = PixoShop.Actions.convertToIcon(qpixmap)

            '''
            test toolbar
            '''
            w = Qt.QtWidgets.QToolButton()
            w.setIcon(qicon)
            self.button_list.addWidget(w)

        '''
        dirty update
        '''
        self.set_dirty(dirty_state)

    def get_pixmap_for_data_icon(self, shelf_button_index):
        data = self.get_parent_data()
        if not data:
            return False

        '''
        find icon in local folder
        '''
        icon_filename = Utils.get_icon_path_from_data(data, shelf_button_index = shelf_button_index, mode = UserModes.Dev)
        if not icon_filename:
            return False

        '''
        check if full path or shortpath
        '''
        if os.path.isfile(icon_filename):
            pixmap = PixoShop.Actions.loadPixmapFromPathSimple(icon_filename)
        else:
            pixmap = MayaUtils.getPixmapForPath(icon_filename)

        '''
        scale up to fit within 100x100
        '''
        target_dimension = 100
        longest_dimension = max(pixmap.width(), pixmap.height())
        scale_factor = target_dimension / float(longest_dimension)
        new_width = pixmap.width() * scale_factor
        new_height = pixmap.height() * scale_factor
        pixmap = pixmap.scaled(new_width, new_height, Qt.QtCore.Qt.KeepAspectRatio,
                                         Qt.QtCore.Qt.SmoothTransformation)

        return pixmap


class VBoxLayout(Qt.QtWidgets.QVBoxLayout):

    def __init__(self, *args, **kwargs):
        #
        super(VBoxLayout, self).__init__(*args, **kwargs)

        self.setSpacing(0)
        self.setContentsMargins(0, 0, 0, 0)


class GridLayout(Qt.QtWidgets.QGridLayout):

    def __init__(self, *args, **kwargs):
        #
        super(GridLayout, self).__init__(*args, **kwargs)

        self.setSpacing(2)
        self.setContentsMargins(3, 3, 3, 3)


class StackedLayout(Qt.QtWidgets.QStackedLayout):

    def __init__(self, *args, **kwargs):
        #
        super(StackedLayout, self).__init__(*args, **kwargs)

        self.setSpacing(0)
        self.setContentsMargins(0, 0, 0, 0)


class MayaUtils(object):
    try:
        from maya import cmds
        from maya import mel
        import maya.OpenMayaUI as OpenMayaUI
        import maya.api.OpenMaya as OpenMaya
        mayaLoaded = True
    except Exception as e:
        pass
    resourceCache = False
    shelfIconLookup = {}
    shelfIconPaths = []

    @classmethod
    def isMayaLoaded(cls):
        return cls.mayaLoaded

    @classmethod
    def savePrefs(cls):
        cls.cmds.savePrefs()

    @classmethod
    def get_dpi_scaling(cls):
        value = cls.cmds.mayaDpiSetting( query=True, realScaleValue=True )
        return value

    @classmethod
    def get_dpi_scaled_value(cls, v):
        return v * cls.get_dpi_scaling()

    @classmethod
    def getQtObjectForMayaWidget(cls, widgetPath):
        '''
        get pointer
        '''
        pointer = cls.OpenMayaUI.MQtUtil.findControl(widgetPath)
        '''
        get wrap function
        '''
        func = False
        qtWidget = False
        try:
            try:
                import sip
                func = sip.wrapinstance
                qtWidget = func(long(pointer), Qt.QtWidgets.QWidget)
            except:
                import shiboken
                func = shiboken.wrapInstance
                qtWidget = func(long(pointer), Qt.QtWidgets.QWidget)
        except:
            try:
                import shiboken2
                func = shiboken2.wrapInstance
                qtWidget = func(long(pointer), Qt.QtWidgets.QWidget)
            except:
                pass

        return qtWidget
        # qtWidget = func(long(pointer), Qt.QtWidgets.QWidget)

    @classmethod
    def getMayaObjectForQTWidget(cls, widget):
        pointer = cls.unwrapInstance(widget)
        try:
            mayaPointer = cls.OpenMayaUI.MQtUtil.fullName(long(pointer))
        except:
            mayaPointer = cls.OpenMayaUI.MQtUtil.fullName(int(pointer))
        return mayaPointer

    @classmethod
    def unwrapInstance(cls, pointer):
        unwrapped = False
        try:
            try:
                import sip
                unwrapped = long(sip.unwrapinstance(pointer))
            except:
                import shiboken
                unwrapped = shiboken.getCppPointer(pointer)[0]
        except:
            try:
                import shiboken2
                unwrapped = shiboken2.getCppPointer(pointer)[0]
            except:
                pass

        return unwrapped

    @classmethod
    def extractShelfButtonData(cls, n, *args, **kwargs):
        if not cls.isMayaLoaded():
            return False

        # set data
        itemData = DataTemplates.Templates.getContentsTemplate()
        #
        try:
            if cls.cmds.objectTypeUI(n) == 'shelfButton':

                '''
                template
                '''
                itemData = DataTemplates.Templates.getContentsTemplate()
                itemData['shortName'] = cls.cmds.shelfButton(n, query=True, label=True)
                itemData['longName'] = cls.cmds.shelfButton(n, query=True, annotation=True)
                itemData['annotation'] = cls.cmds.shelfButton(n, query=True, annotation=True)

                commandData = DataTemplates.Templates.getCommandTemplate()
                commandData['command'] = cls.processCommandString(cls.cmds.shelfButton(n, query=True, command=True))
                commandData['altCommand'] = cls.processCommandString(
                    cls.cmds.shelfButton(n, query=True, doubleClickCommand=True))
                commandData['sourceType'] = cls.cmds.shelfButton(n, query=True, sourceType=True)
                itemData['command_data'] = commandData

                '''
                icon
                '''
                iconPath = cls.cmds.shelfButton(n, query=True, image=True)
                itemData['icon']['image'] = iconPath
                itemData['icon']['label'] = cls.cmds.shelfButton(n, query=True, imageOverlayLabel=True)

                '''
                check through menu items
                '''
                popupMenus = cls.cmds.shelfButton(n, query=True, popupMenuArray=True)
                if popupMenus:
                    for popupMenu in popupMenus:
                        menuItems = cls.cmds.popupMenu(popupMenu, query=True, itemArray=True)
                        if menuItems:
                            for menuItem in menuItems:
                                # try:
                                path = cls.cmds.menuItem(menuItem, query=True, label=True)
                                itemData['children'] += cls.getMenuItems(menuItem, menuItem, path)

                '''
                add extra info
                '''
                itemData['type'] = 'standardButton'
                itemData['tags'] = [cls.get_active_shelf()]

        except Exception as e:
            print(2960, Exception, e)
            print (traceback.format_exc())

        return itemData

    @classmethod
    def get_active_shelf(cls):
        parent = cls.mel.eval("global string $gShelfTopLevel; $temp = $gShelfTopLevel;")
        active_tab = cls.cmds.tabLayout(parent, query=True, selectTab=True)
        return active_tab

    @classmethod
    def set_active_shelf(cls, shelf):
        '''
        create if it doesnt exist
        '''
        cls.create_shelf(shelf)

    @classmethod
    def create_shelf(cls, shelf):
        '''
        create shelf if it doesnt exist
        '''
        parent = mel.eval("global string $gShelfTopLevel; $temp = $gShelfTopLevel;")
        if not cls.cmds.shelfLayout(shelf, exists=True, query=True):
            # trying mel to avoid odd race condition
            #mel.eval('if (!`shelfLayout -exists {0} `) deleteUI {0};'.format(shelf))
            #mel.eval('if (!`shelfLayout -exists {0} `) ${0} = `shelfLayout -cellHeight 32 -p $gShelfTopLevel {0}`;'.format(shelf))
            mel.eval('${0} = `shelfLayout -cellHeight 32 -p $gShelfTopLevel {0}`;'.format(shelf))

        '''
        set active shelf
        '''
        cls.cmds.tabLayout(parent, edit=True, selectTab=shelf)

    @classmethod
    def getMenuItems(cls, rootMenu, thisMenu, path):

        blackList = ['Open', 'Edit', 'Edit Popup', 'Delete']
        returnItems = []
        '''
        attempt to rebuild menu
        otherwise itll be empty
        '''
        try:
            postMenuCommand = cls.cmds.menuItem(thisMenu, query=True, postMenuCommand=True)
            if postMenuCommand:
                cls.mel.eval(postMenuCommand)
        except Exception as e:
            print(329, e)
            pass

        # create popup item
        itemData = DataTemplates.Templates.getContentsTemplate()

        if cls.cmds.menuItem(thisMenu, query=True, subMenu=True):
            '''
            submenus
            '''

            # skip default items
            shortName = cls.cmds.menuItem(thisMenu, query=True, label=True)
            if shortName in blackList:
                return []

            '''
            info
            '''
            itemData['shortName'] = shortName
            itemData['longName'] = shortName
            itemData['type'] = 'subMenu'
            newPath = '{0}|{1}'.format(path, shortName)
            '''
            recursively search for more sub items
            '''
            subMenuItems = cls.cmds.menu(thisMenu, query=True, itemArray=True)
            if subMenuItems:
                for si in subMenuItems:
                    itemData['children'] += cls.getMenuItems(rootMenu, si, newPath)


        elif cls.cmds.menuItem(thisMenu, query=True, divider=True):
            '''
            dividers
            '''
            itemData['type'] = 'divider'

        else:
            '''
            regular items
            '''
            shortName = cls.cmds.menuItem(thisMenu, query=True, label=True)
            if shortName in blackList:
                return []
            itemData['shortName'] = shortName
            itemData['longName'] = shortName

            commandData = DataTemplates.Templates.getCommandTemplate()
            commandData['command'] = cls.processCommandString(cls.cmds.menuItem(thisMenu, query=True, command=True))
            commandData['altCommand'] = cls.processCommandString(
                cls.cmds.menuItem(thisMenu, query=True, dragDoubleClickCommand=True))
            commandData['sourceType'] = cls.cmds.menuItem(thisMenu, query=True, sourceType=True)
            itemData['command_data'] = commandData

            itemData['type'] = 'menuItem'

        '''
        append new items
        '''
        returnItems.append(itemData)
        '''
        '''
        return returnItems

    @classmethod
    def processCommandString(cls, txtString):
        '''
        fix escape issues
        '''
        if txtString:
            txtString = txtString.replace("\\", "\\\\")
        return txtString

    @classmethod
    def getPixmapForPath(cls, fullPathVar):
        # clean path
        path = os.path.split(fullPathVar)[-1]

        # prepare return
        returnPixmap = False

        # init
        try:
            cls.pixmapLookupCache
        except:
            cls.pixmapLookupCache = {}

        # lookup and return
        if path in cls.pixmapLookupCache and cls.pixmapLookupCache[path]:
            return cls.pixmapLookupCache[path]

        # cache resource info
        if not cls.resourceCache:
            cls.resourceCache = cls.resourceManager(nameFilter='*')

        # native icons
        # isNative = cls.resourceManager(nameFilter=path)
        isNative = False
        if path in cls.resourceCache:
            isNative = True
        if isNative:
            pixmap = Qt.QtGui.QPixmap(':/{0}'.format(path))
            if pixmap.width():
                cls.pixmapLookupCache[path] = pixmap

        # non native
        if path not in cls.pixmapLookupCache.keys() or not cls.pixmapLookupCache[path]:
            fullpath = cls.findIconFullImagePath(path)
            if fullpath:
                if os.path.isfile(fullpath):
                    pixmap = Qt.QtGui.QPixmap(fullpath)
                    if pixmap.width():
                        cls.pixmapLookupCache[path] = pixmap
            else:
                '''
                for paths not in icon directory
                '''
                pixmap = Qt.QtGui.QPixmap(fullPathVar)
                if pixmap.width():
                    cls.pixmapLookupCache[path] = pixmap
                else:
                    print('PixMapPathNotFound', path)

        # fallback
        if path not in cls.pixmapLookupCache.keys() or not cls.pixmapLookupCache[path]:
            color = [0.847, 0.263, 0.145]  # red
            color = [int(color[0] * 255), int(color[1] * 255), int(color[2] * 255)]
            pixMap = Qt.QtGui.QPixmap(100, 100)  # pixMap
            pixMap.fill(Qt.QtGui.QColor(*color))  #
            cls.pixmapLookupCache[path] = pixMap

        # return
        return cls.pixmapLookupCache[path]

    @classmethod
    def resourceManager(cls, *args, **kwargs):
        if not cls.isMayaLoaded():
            return False
        return cls.cmds.resourceManager(*args, **kwargs)

    @classmethod
    def findIconFullImagePath(cls, path, *args, **kwargs):
        # cache image paths
        if not cls.shelfIconPaths:
            cls.shelfIconPaths = cls.getShelfIconPaths()
            cls.shelfIconLookup = {}

        # load images
        if not cls.shelfIconLookup:
            imageFiles = []
            for shelfIconPath in cls.shelfIconPaths:
                imageFiles += FileUtils.getFilesInFolder(shelfIconPath, ['png', 'jpg'])
            for imageFile in imageFiles:
                shortName = os.path.split(imageFile)[-1]
                shortName = shortName.lower()
                if shortName not in cls.shelfIconLookup.keys():
                    cls.shelfIconLookup[shortName] = []
                cls.shelfIconLookup[shortName].append(imageFile)

        # return
        lowercasepath = path.lower()
        if lowercasepath in cls.shelfIconLookup.keys():
            return cls.shelfIconLookup[lowercasepath][0]
        else:
            return False

    @classmethod
    def getShelfIconPaths(cls, *args, **kwargs):
        iconPathsString = cls.getIconPaths()
        iconDirs = []
        if iconPathsString:
            # determine split string
            splitString = ''
            if '%B' in iconPathsString:
                splitString = '%B'
            elif ';' in iconPathsString:
                splitString = ';'

            # cleanup
            for path in iconPathsString.split(splitString):
                # remove leading ':'
                if path.startswith(':'):
                    path = path[1:]

                #
                if len(path) <= 1:
                    continue

                # norm path
                path = os.path.normpath(path)

                # add path
                iconDirs.append(path)

        return iconDirs

    @classmethod
    def getIconPaths(cls):
        if not cls.isMayaLoaded():
            return False
        return cls.mel.eval('string $iconPaths = `getenv XBMLANGPATH`')

    @classmethod
    def create_shelf_button(cls, target_shelf = False, button_data = False):
        print(1691, 'create_shelf_button', button_data)
        '''
        annotation 
        '''
        button_annotation = button_data['annotation']

        '''
        children/popups 
        '''
        button_popups = button_data['children']

        '''
        icon
        '''
        icon_path = button_data['icon']['image']

        '''
        overlay label
        '''
        icon_label = button_data['icon']['label']

        '''
        list label
        '''
        list_label = button_data['shortName']

        '''
        command
        '''
        try:
            button_command_data = button_data['command_data']
        except:
            button_command_data = DataTemplates.Templates.getCommandTemplate()
        button_command = button_command_data['command']
        button_source_type = button_command_data['sourceType']

        '''
        get target shelf
        '''
        parent = cls.cmds.shelfLayout(target_shelf, query=True, fullPathName=True)
        # make button
        button_data = cls.cmds.shelfButton(parent =parent,  annotation=button_annotation, image=icon_path, image1=icon_path, c=button_command,
                                       sourceType=button_source_type)
        cls.cmds.shelfButton(button_data, edit=True, imageOverlayLabel=icon_label)
        cls.cmds.shelfButton(button_data, edit=True, label=list_label)

        #print(1712, parent, button_data)
        # add popups
        if button_popups:
            popMenu = cls.cmds.popupMenu(button_data, button=3)
            for popupItem in button_popups:
                popupDivider = popupItem['divider']
                popupSubmenu = popupItem['subMenu']
                popupLabel = popupItem['label']
                popupCommand = popupItem['command']
                popupSourceType = popupItem['sourceType']

                # black list commands
                blackList = ['Delete', 'Edit Popup', 'Open', 'Edit']
                if popupLabel not in blackList:
                    # regular items
                    if not popupDivider and not popupSubmenu:
                        cls.cmds.menuItem(parent=popMenu, label=popupLabel, command=popupCommand, sourceType=popupSourceType)

                    # dividers
                    if popupDivider:
                        cls.cmds.menuItem(parent=popMenu, divider=True)

                    # submenus
                    if popupSubmenu:
                        submenuParent = cls.cmds.menuItem(parent=popMenu, submenu=True, label=popupLabel)
                        for si in popupSubmenu:
                            si_label = si['label']
                            si_command = si['command']
                            si_sourceType = si['sourceType']

                            # black list
                            if si_label not in blackList:
                                # make the submenu item
                                cls.cmds.menuItem(parent=submenuParent, label=popupLabel, command=si_command,
                                              sourceType=si_sourceType)

    @classmethod
    def remove_package_buttons_from_shelf(cls, shelf, tool_id):
        '''
        look up buttons
        '''
        remove_shelf_buttons = cls.get_package_buttons_from_shelf(shelf, tool_id)
        if not remove_shelf_buttons:
            return False
        '''
        delete
        '''
        cls.cmds.deleteUI(*remove_shelf_buttons, control=True)


    @classmethod
    def get_package_buttons_from_shelf(cls, shelf, tool_id):
        '''
        set active shelf
        '''
        cls.set_active_shelf(shelf)

        '''
        check that shelf exists
        '''
        if not cls.cmds.shelfLayout(shelf, exists=True, query=True):
            return []

        '''
        iterate through child buttons of shelf
        '''
        matching_buttons = []
        child_array = cls.cmds.shelfLayout(shelf, query=True, childArray=True, fullPathName=True)
        if not child_array:
            return []
        for shelf_button in child_array:
            command_str = cls.cmds.shelfButton(shelf_button, query=True, command=True)
            '''
            check tool_id
            '''
            split_lines = command_str.splitlines()
            for line in split_lines:
                '''
                isolate tool_id line
                '''
                if Utils.are_all_strings_in_string(line, ['tool_id', '=']):
                    '''
                    check tool_id value
                    '''
                    component, component_value = line.split('=')
                    component_type, component_value = Utils.inspect_component(component_value)
                    if component_value == tool_id:
                        if shelf_button not in matching_buttons:
                            matching_buttons.append(shelf_button)
                            break
        '''
        results
        '''
        return matching_buttons



class Utils:

    @classmethod
    def install_package(cls, for_real = True, filepaths = False):
        '''
        ask user for package
        '''
        target_folder =  PrefsManager.getProperty('target_folder', False)
        if not filepaths:
            filepaths = QTHelpers.get_files_from_user(title='Open eblabs Package (*.zip)', target_folder=target_folder)
            if not filepaths:
                return False

        '''
        store path in prefs, for auto suggesting next time
        '''
        if filepaths:
            token_filepath = filepaths[0]
            folder_path = False
            if os.path.isdir(token_filepath):
                folder_path = token_filepath
            elif os.path.isfile(token_filepath):
                folder_path = os.path.dirname(token_filepath)
            if folder_path:
                PrefsManager.setProperty('target_folder', folder_path)

        '''
        batch
        * todo: optimize confirmations to only ask the user once
        '''
        for filepath in filepaths:
            '''
            validate package
            '''
            data = cls.validate_package(filepath)
            if not data:
                print('Checking Package, Not Valid: ', filepath)
                continue
            else:
                print('Checking Package, Is Valid: ', data)

            '''
            allow for dry runs
            '''
            if for_real:
                '''
                remove old contents, ask user if ok
                also remove old shelf buttons
                '''
                cls.pre_install_cleanup(data)


                '''
                unpack zip file into folders
                '''
                data = cls.unpack_package(filepath, data)

                '''
                create eblabs shelf if not there
                '''
                shelf = cls.get_working_shelf_name(mode = UserModes.User)
                MayaUtils.create_shelf(shelf)

                '''
                add new buttons
                '''
                shelf_data = data.get('shelf_data', [])
                if shelf_data:
                    for button_data in shelf_data:
                        MayaUtils.create_shelf_button(target_shelf=shelf, button_data=button_data)
        '''
        store prefs
        '''
        if for_real and filepaths:
            MayaUtils.savePrefs()

    @classmethod
    def get_potential_versions(cls, filepath):
        '''
        find local install paths based on installed version
        '''
        filepath = os.path.normpath(filepath)
        split_path = FileUtils.split_path_all(filepath)
        #split_path = filepath.split(os.sep)
        split_path = list(filter(None, split_path))
        split_path = split_path[:-2] # remove 'data', 'eblabs.data'
        split_path.append('versions')
        folder_path = os.path.normpath(os.path.join(*split_path ))

        '''
        get zip files
        '''
        zip_files = FileUtils.getFilesInFolder(folder_path, ['zip'])

        '''
        data
        '''
        version_data = {}
        for zip_file in zip_files:
            data = cls.get_data_file_from_archive(zip_file)
            version = False
            try:
                version = data['version']
            except:
                continue
            if version:
                version_data[version] = zip_file

        '''
        '''
        return version_data

    @classmethod
    def modify_nested_data(cls, obj, modify_function, key=False):
        """
        Recursively goes through the dictionary obj and replaces keys with the modify_function function.
        https://stackoverflow.com/questions/11700705/python-recursively-replace-character-in-keys-of-nested-dictionary
        """
        if isinstance(obj, (str, int, float)):
            return modify_function(key, obj)
        if isinstance(obj, dict):
            new = obj.__class__()
            for k, v in obj.items():
                new[k] = cls.modify_nested_data(modify_function(k, v), modify_function, key=k)
        elif isinstance(obj, (list, set, tuple)):
            new = obj.__class__(cls.modify_nested_data(modify_function(key, v), modify_function, key=False) for v in obj)
        else:
            return modify_function(key, obj)
        return new

    @classmethod
    def localize_images_paths(cls, data, mode = UserModes.User):
        '''
        pull out shelf data
        '''
        shelf_data = data.get('shelf_data', [])
        if not shelf_data:
            return data

        '''
        rebuild new shelf data
        '''
        new_shelf_data = []
        for i in range(len(shelf_data)):
            button_data = copy.deepcopy(shelf_data[i])
            button_data['icon']['image'] = cls.get_icon_path_from_data(data, i, mode=mode)
            new_shelf_data.append(button_data)

        '''
        replace
        '''
        data['shelf_data'] = copy.deepcopy(new_shelf_data)

        return data

    @classmethod
    def localize_scripts_paths(cls, data, mode = UserModes.User):
        '''
        recursively search through data for 'command
        '''
        replace_data = {}
        replace_data['root_path'] = cls.get_working_path(mode = UserModes.User)
        replace_data['tool_id'] = data['location']

        data = cls.modify_nested_data(data, partial(cls.localize_scripts_paths_modify_function, replace_data))

        return data

    @classmethod
    def localize_scripts_paths_modify_function(cls, replace_data, key, value):
        root_path = replace_data['root_path']
        tool_id = replace_data['tool_id']
        if key == 'command':
            print(2163, type(value), root_path, value, tool_id)
            if isinstance(value, (str, unicode)):
                value = cls.localize_script_paths_string_processing(root_path, value, tool_id)
        return value

    @classmethod
    def localize_script_paths_string_processing(cls, root_path, script_string, tool_id):
        '''
        make replacements
        split into lines
        '''
        split_lines = script_string.splitlines()
        new_lines = []
        for line in split_lines:
            '''
            looking for: 
            install_path = ''
            tool_id = 'myTool'
            '''
            if cls.are_all_strings_in_string(line, ['install_path', '=']):
                line = "install_path = '{0}'".format(root_path)
            elif cls.are_all_strings_in_string(line, ['tool_id', '=']):
                line = "tool_id = '{0}'".format(tool_id)

            '''
            assemble
            '''
            new_lines.append(line)

        '''
        assemble
        '''
        split_lines = '\n'.join(new_lines)
        return split_lines

    @classmethod
    def unpack_package(cls, filepath, data):
        '''
        define folder names
        '''
        filepath = os.path.normpath(filepath)
        root_install_path = cls.get_working_path(mode = UserModes.User)
        package_id = data['location']
        package_install_path = os.path.normpath(os.path.join(root_install_path, package_id))

        '''
        store a copy locally
        '''
        versions_folder = os.path.normpath(os.path.join(package_install_path, 'versions'))
        version_file = os.path.normpath(os.path.join(package_install_path, 'versions', os.path.basename(filepath)))
        if not os.path.exists(versions_folder):
            os.makedirs(versions_folder)
        if version_file != filepath:
            shutil.copy2(filepath, version_file)

        '''
        unzip into install path
        '''
        with zipfile.ZipFile(filepath, 'r') as z:
            z.extractall(package_install_path)

        '''
        add init files
        '''
        init_files = []
        path = os.path.normpath(os.path.join(package_install_path, '__init__.py'))
        init_files.append(path)
        path = os.path.normpath(os.path.join(package_install_path, 'scripts', '__init__.py'))
        init_files.append(path)
        for f in init_files:
            if not os.path.isfile(f):
                FileUtils.touch(f)

        '''
        modify icon paths
        '''
        data = cls.localize_images_paths(data)
        data = cls.localize_scripts_paths(data)

        '''
        write updated data file
        '''
        path = os.path.normpath(os.path.join(package_install_path, 'data', 'eblabs.data'))
        FileUtils.write_json_file(path, data)

        '''
        return 
        '''
        return data

    @classmethod
    def pre_install_cleanup(cls, data):
        '''
        define folder names
        '''
        root_install_path = cls.get_working_path(mode = UserModes.User)
        package_install_path = os.path.normpath(os.path.join(root_install_path, data['location']))

        '''
        remove previous version if there
        todo, ask if user wants to update, show change of versions
        '''
        previous_data_filepath = os.path.normpath(os.path.join(package_install_path, 'data', 'eblabs.data'))
        previous_data = FileUtils.read_json_file(previous_data_filepath)
        if previous_data:
            '''
            todo, 
            '''
            print(170, 'Previous Data Exists, todo, ask user for downgrade? ', previous_data)

        '''
        remove old data
        '''
        core_folders = DataTemplates.Templates.get_core_folders_list()
        for core_folder in core_folders:
            remove_path = os.path.normpath(os.path.join(package_install_path, core_folder))
            if os.path.exists(remove_path):
                try:
                    shutil.rmtree(remove_path)
                    print(174, 'Cleaning Up Folder: ', remove_path)
                except Exception as e:
                    print(175, 'Unable to remove Previous Install', remove_path, Exception, e)
                    return False

        '''
        generate new folders
        '''
        try:
            if not os.path.exists(package_install_path):
                os.makedirs(package_install_path)
                print(186, 'Generating Folder: ', package_install_path)
        except Exception as e:
            print(185, 'generate new folders FAILED', Exception, e)
            return False

        '''
        remove old shelf buttons
        todo
        '''
        shelf = cls.get_working_shelf_name(mode=UserModes.User)
        tool_id = data['location']
        MayaUtils.remove_package_buttons_from_shelf(shelf, tool_id)
        print(1618, 'todo: remove old shelf buttons')



    @classmethod
    def validate_package(cls, filepath):
        '''
        makes sure that:
        1. data file is readable
        2. has correct folders
        '''
        required_folder_list = DataTemplates.Templates.get_core_folders_list()
        data = False
        try:
            data = cls.get_data_file_from_archive(filepath)
        except Exception as e:
            print(130, Exception, e)
            return False
        if not data:
            return False
        '''
        check file contents
        '''
        archive_contents = cls.list_zip_file_contents(filepath)
        folder_names = []
        for zinfo in archive_contents:
            filename = zinfo.filename
            folder_name, base_file_name, file_extension = FileUtils.getFileNameParts(filename)
            if folder_name in required_folder_list:
                #folder_name = os.path.basename(os.path.normpath(filename))
                folder_names.append(folder_name)

        '''
        check that all members are present
        subset comparisons
        https://stackoverflow.com/questions/16579085/python-verifying-if-one-list-is-a-subset-of-the-other
        '''
        if not set(required_folder_list) <= set(folder_names):
            print(1861, 'required_folder_list FAIL', required_folder_list, folder_names)
            return False

        '''
        ok all good, return data
        '''
        return data

    @classmethod
    def get_working_path(cls, mode = None):
        '''
        mode
        '''
        if mode == None:
            mode = PrefsManager.getProperty('mode', UserModes.User)

        '''
        get working folder
        '''
        working_folder = False
        if mode == UserModes.User:
            default_value = os.path.normpath(os.path.join(cmds.internalVar(userAppDir=True), 'scripts', 'eblabs_hub'))
            working_folder = PrefsManager.getProperty('install_path', default_value)
        elif mode == UserModes.Dev:
            working_folder = PrefsManager.getProperty('dev_folder', False)
        '''
        '''
        return working_folder

    @classmethod
    def get_data_file_from_archive(cls, filepath):
        '''
        check that the file exists
        '''
        json_data = False
        if filepath and os.path.isfile(filepath):
            '''
            examine file
            '''
            with zipfile.ZipFile(filepath) as z:
                '''
                itterate members
                '''
                for finfo in z.infolist():
                    '''
                    skip folders, last part of filename will be '' if a folder
                    '''
                    filename = finfo.filename
                    path_parts = filename.split(os.sep)
                    # print path_parts
                    if path_parts[-1]:  # skip folders
                        '''
                        find data file
                        '''
                        if finfo.filename == 'data/eblabs.data':
                            with z.open(finfo) as zfile:
                                '''
                                extract json data
                                '''
                                json_data = json.loads(zfile.read())
        '''
        return
        '''
        return json_data

    @classmethod
    def list_zip_file_contents(cls, filepath):
        '''
        check that the file exists
        '''
        finfo_list = []
        if filepath and os.path.isfile(filepath):
            '''
            examine file
            '''
            with zipfile.ZipFile(filepath) as z:
                '''
                iterate members
                '''
                for finfo in z.infolist():
                    '''
                    skip folders, last part of filename will be '' if a folder
                    '''
                    #filename = finfo.filename
                    #pathParts = filename.split(os.sep)
                    # print pathParts
                    # if pathParts[-1]:  # skip folders
                    '''
                    store finfo
                    '''
                    finfo_list.append(finfo)

        '''
        return
        '''
        return finfo_list


    @classmethod
    def get_packages_basic_info(cls):
        '''
        get working path, either for user or dev
        '''
        mode = PrefsManager.getProperty('mode', UserModes.User)
        working_path = Utils.get_working_path(mode=mode)
        #print(979, 'working_path', working_path)
        if not working_path:
            return False
        if not os.path.exists(working_path):
            return False

        '''
        get list of folders
        '''
        sub_folders = FileUtils.get_sub_folders(working_path)

        '''
        get data file for each path
        '''
        data_file_basic_info = []
        for sub_folder in sub_folders:
            data_file_path = os.path.normpath(os.path.join(working_path, sub_folder, 'data', 'eblabs.data'))
            data_file_basic_info.append([sub_folder, data_file_path])

        return data_file_basic_info

    @classmethod
    def get_icon_path_from_data(cls, data, shelf_button_index = 0, mode = UserModes.User):
        '''
        icon path
        '''
        #(1998, <type 'exceptions.Exception'>, TypeError('list indices must be integers, not str',), {u'description': u'tool for doing xyz', u'package': u'World Space Tools', u'shelf_data': [{u'color': [0.2, 0.2, 0.2], u'children': [{u'command_data': [{u'sourceType': u'python', u'altCommand': u'', u'command': u"\npath = '/u/ecb/Pictures/eblabs-hub/'\n\nimport os\nimport sys\nif not path in sys.path:\n    sys.path.append(path)\n\nimport eblabs_hub.WorldSpaceTools.scripts.worldspace as tool\n\ntool.window.load()", u'longName': u'', u'shortName': u'', u'annotation': u''}], u'tags': [u'modelingMenuSet'], u'color': [0.388, 0.737, 0.808, 1], u'type': u'standardButton', u'children': [], u'subType': u'', u'longName': u'', u'id': u'31668d5c3afb4600bd45afba600e5fe7', u'shortName': u'World Space Tools', u'data': {}, u'annotation': u'', u'icon': {u'image': u'/u/ecb/Pictures/eblabs-hub/eblabs_hub/WorldSpaceTools/images/eblabs_worldSpaceTools.png', u'label': u''}}], u'subType': u'', u'longName': u'', u'shortName': u'', u'type': u'root', u'annotation': u''}], u'legacy': [], u'location': u'WorldSpaceTools', u'version': u'1.5'})
        try:
            icon_filename = data['shelf_data'][shelf_button_index]['icon']['image']
        except Exception as e:
            print(1998, Exception, e, data)
            print (traceback.format_exc())
            return False
        try:
            package_folder = data['location']
        except Exception as e:
            print(2003, Exception, e)
            return False

        '''
        filename parts
        '''
        folderName, baseFileName, fileExtension = FileUtils.getFileNameParts(icon_filename)

        '''
        calculate path
        '''
        root_path = Utils.get_working_path( mode = mode)
        file_path = os.path.normpath(os.path.join(root_path, package_folder, 'images', '{0}.{1}'.format(baseFileName, fileExtension)))

        '''
        check if full path or shortpath
        '''
        if os.path.isfile(file_path):
            return file_path
        else:
            return '{0}.{1}'.format(baseFileName, fileExtension)

    @classmethod
    def get_working_shelf_name(cls, mode = UserModes.User):
        if mode == UserModes.User:
            return 'eblabs_HUB'
        else:
            return 'eblabs_HUB_DEV'

    @classmethod
    def create_template_button(cls):
        '''
        create dev shelf
        '''
        shelf = cls.get_working_shelf_name(mode = UserModes.Dev)
        MayaUtils.create_shelf(shelf)

        '''
        gather data
        '''
        template_button_data = DataTemplates.Templates.get_shelf_button_template_data()
        root_path = cls.get_working_path(mode=UserModes.Dev)
        package_short_name = 'template'

        '''
        localize button script path
        '''
        script_string = template_button_data['command_data']['command']
        tool_id = 'placeholder'
        script_string = cls.localize_script_paths_string_processing(root_path, script_string, tool_id)
        template_button_data['command_data']['command'] = script_string
        '''
        create button
        '''
        MayaUtils.create_shelf_button(target_shelf=shelf, button_data=template_button_data)

    @classmethod
    def camel_case_to_label(cls, string_var):
        try:
            return_string = re.sub(r'((?<=[a-z])[A-Z]|(?<!\A)[A-Z](?=[a-z]))', r' \1', string_var)
            return_string = return_string.replace('_', ' ')
            return return_string
        except:
            return string_var


    @classmethod
    def are_all_strings_in_string(cls, str_item, str_list):
        return all(s in str_item for s in str_list)

    @classmethod
    def inspect_component(cls, component):
        '''
        prep returns
        '''
        component_type = ''
        component_cleaned = ''

        '''
        validate
        '''
        if component is None:
            return False

        '''
        break down component
        '''
        component = str(component).strip()
        component_cleaned = eval(component)

        '''
        type check
        '''
        type_check = ''
        try:
            type_check = type(eval(component))
        except:
            pass

        '''
        casting
        '''
        if type_check:
            if type_check in [int, float]:
                component_type = 'number'
                component_cleaned = float(component_cleaned)
            elif type_check == bool:
                component_type = 'boolean'
            elif type_check == list:
                component_type = 'list'
            elif type_check == str:
                component_type = 'string'

        return[component_type, component_cleaned]

class FileUtils:

    @classmethod
    def touch(cls, path):
        '''
        create folder
        '''
        basedir = os.path.dirname(path)
        if not os.path.exists(basedir):
            os.makedirs(basedir)
        '''
        create empty file
        '''
        with open(path, 'a'):
            os.utime(path, None)

    @classmethod
    def validateText(cls, text, *args, **kwargs):
        if not text:
            return False
        validCharacters = "-_.(){0}{1}".format(string.ascii_letters, string.digits)
        validatedCharacters = []
        for c in text:
            # replace space with underscore
            if c == ' ':
                c = '_'
            # filter non valid characters
            if c in validCharacters:
                validatedCharacters.append(c)
        # return result
        validatedText = ''.join(validatedCharacters)
        return validatedText

    @classmethod
    def getFileNameParts(cls, filepath, *args, **kwargs):
        if not filepath:
            return False
        folderName, filename = os.path.split(filepath)
        baseFileName, fileExtension = os.path.splitext(filename)
        fileExtension = fileExtension[1:]  # remove period
        return folderName, baseFileName, fileExtension

    @classmethod
    def getFilesInFolder(cls, path, extensions, recursive = True):
        fileList = []
        if os.path.exists(path):
            for entry in Scandir.scandir(path):
                fileCheckList = []
                if entry.is_dir(follow_symlinks=False):
                    if recursive:
                        fileCheckList += cls.getFilesInFolder(entry.path, extensions, recursive)
                else:
                    fileCheckList += [entry.path]
                matchFound = False
                if fileCheckList:
                    for f in fileCheckList:
                        for extension in extensions:
                            if f.endswith(extension):
                                fileList.append(os.path.normpath(f))
                                matchFound = True
                                break
        return fileList

    @classmethod
    def get_sub_folders(cls, path, *args, **kwargs):
        folders = []
        if path and os.path.exists(path):
            for entry in Scandir.scandir(path):
                if not entry.name.startswith('.') and entry.is_dir():
                    folders.append(entry.name)
        return folders

    @classmethod
    def read_json_file(cls, filepath):
        try:
            with open(filepath, 'r') as f:
                data = json.loads(f.read())
                return data
        except:
            return False

    @classmethod
    def write_json_file(cls, filepath, data):
        try:
            '''
            write data
            '''
            data = json.dumps(data, sort_keys=True, indent=4)
            with open(filepath, 'w') as f:
                f.write(data)
        except:
            return False

    @classmethod
    def browseFolder(cls, path):
        if path:
            if sys.platform == "win32":
                    os.startfile(path)
            elif sys.platform == "Darwin":
                os.system(["open", path])
            else:
                os.system('xdg-open "{0}"'.format(path))

    @classmethod
    def split_path_all(cls, path):
        allparts = []
        while 1:
            parts = os.path.split(path)
            if parts[0] == path:  # sentinel for absolute paths
                allparts.insert(0, parts[0])
                break
            elif parts[1] == path: # sentinel for relative paths
                allparts.insert(0, parts[1])
                break
            else:
                path = parts[0]
                allparts.insert(0, parts[1])
        return allparts

class QTHelpers():



    @classmethod
    def getStringFromUser(cls, parentWidget = False, titleText = 'Input Dialog', labelText = 'Input Below', successCallback = False):
        '''
        ask the user to provide a string
        '''
        # get input from user
        returnText, okState = Qt.QtWidgets.QInputDialog.getText(parentWidget, titleText, labelText)
        if okState and returnText:
            '''
            run callback
            '''
            try:
                if successCallback:
                    successCallback(returnText)
            except:
                pass

    @classmethod
    def getYesNoFromUser(cls, parentWidget = False, titleText = 'Title Text', messageText = 'Message Text', successCallback = False):
        '''
        ask the user to click yes or no
        '''
        reply = Qt.QtWidgets.QMessageBox.question(parentWidget, titleText, messageText, Qt.QtWidgets.QMessageBox.Yes | Qt.QtWidgets.QMessageBox.No, Qt.QtWidgets.QMessageBox.No)
        if reply == Qt.QtWidgets.QMessageBox.Yes:
            '''
            run callback
            '''
            try:
                if successCallback:
                    successCallback()
            except:
                pass

    @classmethod
    def get_files_from_user(cls, parent_widget=False, file_types='Archive (*.zip)', title='window title',
                            target_folder=False, allow_multiples = True):
        '''
        setup parent
        '''
        if not parent_widget:
            parent_widget = cls.get_main_window()
        '''
        target folder
        '''
        if not target_folder:
            target_folder = Qt.QtCore.QDir.currentPath()

        '''
        get filepath from user
        '''
        filepaths = []
        if allow_multiples:
            filepaths = Qt.QtWidgets.QFileDialog.getOpenFileNames(parent_widget, title, target_folder, file_types)
        else:
            filepaths = Qt.QtWidgets.QFileDialog.getOpenFileName(parent_widget, title, target_folder, file_types)
            if filepaths:
                filepaths = [filepaths]

        '''
        remove filepath list from tupple
        (['filepathA.txt', 'filepathB.txt'], u'Text Files (*.txt)'))
        '''
        if filepaths:
            filepaths = filepaths[0]
        '''
        return
        '''
        return filepaths

    @classmethod
    def get_folder_from_user(cls, parent_widget=False, title='window title', target_folder=False):
        '''
        setup parent
        '''
        if not parent_widget:
            parent_widget = cls.get_main_window()
        '''
        target folder
        '''
        if not target_folder:
            target_folder = Qt.QtCore.QDir.currentPath()

        '''
        get filepath from user
        '''
        filepath = Qt.QtWidgets.QFileDialog.getExistingDirectory(None, title, target_folder, Qt.QtWidgets.QFileDialog.ShowDirsOnly)
        '''
        return
        '''
        return filepath

    @classmethod
    def get_main_window(cls):
        """Return Maya's main window"""
        for obj in Qt.QtWidgets.QApplication.instance().topLevelWidgets():
            if obj.objectName() == 'MayaWindow':
                return obj

        return False






