from functools import partial
from maya import cmds, mel, OpenMaya, OpenMayaUI
import os
import json
import time
import sys
import re
import copy


class PrefsDataStruct():
    @classmethod
    def new(cls):
        newDict = {}
        newDict['activeProfile'] = 'default'
        newDict['data'] = {}
        return newDict


class PrefsManager():
    instance = False

    @classmethod
    def getInstance(cls):
        '''
        override this method to set prefs group
        '''
        if not cls.instance:
            kwargs = {}
            kwargs['prefsGroup'] = 'eblabs_Hub_Main'
            cls.instance = Prefs(**kwargs)
        return cls.instance

    @classmethod
    def setProperty(cls, key, value):
        '''
        commit data
        '''
        cls.getInstance().setFilePref(key, value)

    @classmethod
    def getProperty(cls, key, defaultValue):
        '''
        load existing prefs
        '''
        return cls.getInstance().getFilePref(key, default=defaultValue)

    @classmethod
    def setActiveProfile(cls, profile):
        '''
        set profile
        '''
        cls.getInstance().setActiveProfile(profile)

    @classmethod
    def removeProfile(cls, profile):
        '''
        set profile
        '''
        cls.getInstance().removeProfile(profile)


class Prefs():
    '''
    kwargs = {}
    kwargs['prefsGroup'] = 'IDForGroupingPrefs'
    Prefs(**kwargs)
    '''

    def __init__(self, *args, **kwargs):
        '''
        grouping keyword
        '''
        self.prefsGroup = 'default'
        if 'prefsGroup' in kwargs:
            self.prefsGroup = kwargs.pop('prefsGroup')

        '''
        state tracking
        '''
        self.prefsDataID = False
        self.configDataID = False  # not yet implemented
        self.data = False
        self.rawData = False
        '''
        profiles
        '''
        self.activeProfile = 'default'

        '''
        prefs path
        '''
        self.prefsPath = os.path.normpath(os.path.join(cmds.internalVar(userAppDir=True), 'scripts', 'eblabs_prefs',
                                                       '{0}.prefs'.format(self.prefsGroup)))

        '''
        temp data
        '''
        self.tempData = {}

        '''
        refresh
        '''
        self.refreshData()

    def getActiveProfile(self):
        '''
        cached loading
        '''
        self.refreshData()

        '''
        '''
        return self.rawData['activeProfile']

    def removeProfile(self, profileVar):
        if not profileVar:
            return False

        '''
        cached loading
        '''
        self.refreshData()

        '''
        remove data
        '''
        if profileVar in self.rawData['data'].keys():
            self.rawData['data'].pop(profileVar, None)

        '''
        save prefs
        '''
        self.writePrefsToFile()

        '''
        fallback to default, if deletting active profile
        '''
        if profileVar == self.getActiveProfile():
            self.setActiveProfile('default')

    def setActiveProfile(self, profileVar):
        '''
        cached loading
        '''
        self.refreshData()

        '''
        set profile
        '''
        self.activeProfile = profileVar
        self.rawData['activeProfile'] = profileVar

        '''
        create profile if it doesnt exist
        '''
        if profileVar not in self.listProfiles():
            self.rawData['data'][profileVar] = {}

        self.data = self.rawData['data'][profileVar]

        '''
        save prefs
        '''

        self.writePrefsToFile()

    def listProfiles(self):
        return self.rawData['data'].keys()

    def setTempKey(self, key, value, group='default'):
        try:
            self.tempData[group]
        except:
            self.tempData[group] = {}
        self.tempData[group][key] = value

    def getTempKey(self, key, group='default', default=False):
        try:
            self.tempData[group]
        except:
            self.tempData[group] = {}

        # set default key
        if key not in self.tempData[group].keys():
            return default

        return self.tempData[group][key]

    def setScenePref(self, key, value):
        #
        prefsKey = '{0}.{1}'.format(self.prefsGroup, key)
        cmds.fileInfo(prefsKey, value)

    def getScenePref(self, key, default='NOTSET'):
        #
        prefsKey = '{0}.{1}'.format(self.prefsGroup, key)
        queryPrefs = cmds.fileInfo(prefsKey, query=True)
        if queryPrefs:
            queryPrefs = queryPrefs[0]
            try:
                # cast to bools and numbers
                queryPrefs = eval(queryPrefs)
            except:
                # carry on as a string
                pass
        else:
            # fallback to defaults
            queryPrefs = default
        #
        return queryPrefs

    def getFilePref(self, key, default='NOTSET'):
        # cached loading
        self.refreshData()

        # return default
        if key not in self.data.keys():
            return default

        # return
        return copy.deepcopy(self.data[key])

    def setFilePref(self, key, value):
        # cached loading
        self.refreshData()

        # set value
        self.data[key] = value

        # save prefs
        self.writePrefsToFile()

    def getMayaObjectPref(self, key, default='NOTSET'):
        pass

    def setMayaObjectPref(self, key, value):
        pass

    def clearPrefs(self):
        #
        self.rawData = PrefsDataStruct.new()
        self.writePrefsToFile()

    def getEditID(self, filepath):
        try:
            return os.path.getmtime(filepath)
        except:
            return False

    def hasEditIDChanged(self, filepath, previousEditID):
        editID = False
        try:
            editID = os.path.getmtime(filepath)
        except:
            return False

        # compare IDs
        if editID:
            if previousEditID != editID:
                return True
            else:
                return False

    def refreshData(self):
        '''
        load data if its changed
        '''
        if self.hasEditIDChanged(self.prefsPath, self.prefsDataID) or not self.prefsDataID:
            self.loadPrefsFromFile()
            self.prefsDataID = self.getEditID(self.prefsPath)

        '''
        validate
        '''
        """
        try:
            self.rawData['data']
        except:
            self.rawData['data'] = {}
        try:
            self.rawData['data']['default']
        except:
            self.rawData['data']['default'] = {}
        try:
            self.rawData['data'][self.activeProfile]
        except:
            self.rawData['data'][self.activeProfile] = {}
        """
        self.data = self.rawData['data'].get(self.activeProfile, {})

    def writePrefsToFile(self):
        '''
        prep folder
        '''
        filePathRoot = os.path.split(self.prefsPath)[0]
        if not os.path.exists(filePathRoot):
            os.makedirs(filePathRoot)

        '''
        commit active profile data
        '''
        self.rawData['data'][self.activeProfile] = self.data

        '''
        write data
        '''
        data = json.dumps(self.rawData, sort_keys=True, indent=4)
        with open(self.prefsPath, 'w') as f:
            f.write(data)

    def loadPrefsFromFile(self):
        try:
            '''
            load data from file
            '''
            with open(self.prefsPath, "r") as f:
                self.rawData = json.load(f)
        except Exception as e:
            pass

        '''
        for new prefs
        '''

        if not self.rawData:
            self.rawData = PrefsDataStruct.new()

        '''
        grab active profile
        '''
        self.activeProfile = self.rawData['activeProfile']

