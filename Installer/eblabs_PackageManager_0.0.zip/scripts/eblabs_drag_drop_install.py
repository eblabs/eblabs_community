import urllib2
import urllib
import tempfile
import os
import sys
import zipfile
import json
import shutil
import copy
import traceback
from functools import  partial
from maya import cmds
from maya import mel


'''
add offline installer through menu!
'''

'''
launcher
'''
def onMayaDroppedPythonFile(*args, **kwargs):
    print('drag drop - onMayaDroppedPythonFile', args, kwargs)
    Installer.run_installer()

online_package_path = 'https://raw.githubusercontent.com/eblabs/eblabs_docs/master/test_download.txt'


class Status(object):
    Pre = 1
    Offline = 2
    Success = 3
    Error = 4

class Installer():
    Instance = False

    @classmethod
    def run_installer(cls):
        '''
        1. check if online
        2. get package, via online or local
        3. install local
        4. build shelf + button
        5. Congrats, info popup
        '''

        '''
        initial state message, display UI
        '''
        cls.init_ui()
        '''
        status
        '''
        status = Status.Pre

        '''
        auto run stages
        '''
        is_online = Utils.internet_on()
        if not is_online:
            status = Status.Offline
        else:
            '''
            attempt to install
            '''
            url = 'https://github.com/eblabs/eblabs_docs/raw/master/Installer/eblabs_PackageManager_0.0.zip'
            temp_filepath = Utils.download_file(url=url)
            print(69, temp_filepath)
            if temp_filepath:
                '''
                woot, file downloaded
                '''
                success = Utils.install_package(filepath = temp_filepath)
                if success:
                    status = Status.Success
                else:
                    status = Status.Error

        '''
        update UI message
        '''
        text = cls.get_feedback_message(status)
        cls.set_message(text)

    @classmethod
    def init_ui(cls):
        windowName = 'eblabs_Installer'
        width = 600
        height = 400
        if (cmds.window(windowName, exists=True)):
            cmds.deleteUI(windowName, window=True)
        if (cmds.windowPref(windowName, exists=True)):
            cmds.windowPref(windowName, remove=True)
        cls.window = cmds.window(windowName, widthHeight=(width, height), title=windowName)

        '''
        layout
        '''
        form_layout = cmds.formLayout(parent = cls.window)

        '''
        menu
        '''
        menu_bar = cmds.menuBarLayout(parent = form_layout)
        menu = cmds.menu(parent=menu_bar, label='Options', tearOff=False)
        menu_item = cmds.menuItem(parent=menu, label='Offline Install', command=cls.offline_install)

        '''
        ui elements
        * welcome message
        '''
        cls.welcome_text = cmds.scrollField(parent=form_layout)

        cmds.formLayout(form_layout, edit=True, attachForm=[(menu_bar, 'top', 0)])
        cmds.formLayout(form_layout, edit=True, attachForm=[(menu_bar, 'left', 0)])
        cmds.formLayout(form_layout, edit=True, attachNone=[(menu_bar, 'bottom' )])
        cmds.formLayout(form_layout, edit=True, attachForm=[(menu_bar, 'right', 0)])

        cmds.formLayout(form_layout, edit=True, attachControl=[(cls.welcome_text, 'top', 0, menu_bar)])
        cmds.formLayout(form_layout, edit=True, attachForm=[(cls.welcome_text, 'left', 0)])
        cmds.formLayout(form_layout, edit=True, attachForm=[(cls.welcome_text, 'bottom', 0)])
        cmds.formLayout(form_layout, edit=True, attachForm=[(cls.welcome_text, 'right', 0)])

        '''
        set initial message
        '''
        text = cls.get_feedback_message(Status.Pre)
        cls.set_message(text)

        '''
        display
        '''
        cmds.showWindow(cls.window)

    @classmethod
    def offline_install(cls):
        print(119, 'offline_install')
        '''
        browse for package
        '''

        '''
        install package
        '''

        '''
        success message
        '''

    @classmethod
    def set_message(cls, text):
        cmds.scrollField(cls.welcome_text, edit=True, text=text, wordWrap=False, fn='fixedWidthFont', editable=False)


    @classmethod
    def get_feedback_message(cls, status):
        '''
        class Status(object):
        Pre = 1
        Offline = 2
        Success = 3
        Error = 4
        '''

        lookup = {}

        '''
        pre
        '''
        message = '''
Thanks for supporting eblabs.com!

Package Manager Installer
'''
        lookup[Status.Pre] = message

        '''
        Success
        '''
        message = '''
Thanks for supporting eblabs.com!

Congratulations, the Package Manager has been successfully
installed. It can now be found on the eblabs_HUB shelf. Please
use this for installing and updating all of your eblabs.com tools!

Happy Animating!!

-Eric @ eblabs
        '''
        lookup[Status.Success] = message

        '''
        Offline
        '''
        message = '''
        OFFLINE
        '''
        lookup[Status.Offline] = message

        '''
        Error
        '''
        message = '''
        ERROR
        '''
        lookup[Status.Error] = message

        '''
        return 
        '''
        return lookup[status]


class Utils():

    @classmethod
    def internet_on(cls):
        try:
            url = 'https://github.com'
            urllib2.urlopen(url, timeout=1)
            return True
        except urllib2.URLError as err:
            return False

    @classmethod
    def download_file(cls, url=''):
        '''
        check
        '''
        if not url:
            return False

        '''
        temp save dir
        '''
        temp_folder = tempfile.gettempdir()
        _, filename = os.path.split(url)
        temp_file = os.path.normpath(os.path.join(temp_folder, filename))

        '''
        download
        '''
        try:
            urllib.urlretrieve(url, filename=temp_file)
            if os.path.exists(temp_file):
                return temp_file
        except Exception as e:
            pass

        '''
        fallback
        '''
        return False

    @classmethod
    def ask_user_for_package_file(cls):
        # get path
        filters = 'eblabs_PackageManager_0.0.zip (eblabs_PackageManager_0.0.zip)'
        path = cmds.fileDialog2(fileFilter=filters, dialogStyle=2, fileMode=1, okCaption='OK')
        if path:
            return str(path[0])
        else:
            return False

    @classmethod
    def validate_package(cls, filepath):
        '''
        makes sure that:
        1. data file is readable
        2. has correct folders
        '''
        required_folder_list = ['data', 'images', 'scripts']
        data = False
        try:
            data = cls.get_data_file_from_archive(filepath)
        except Exception as e:
            print(130, Exception, e)
            return False
        if not data:
            return False
        '''
        check file contents
        '''
        archive_contents = cls.list_zip_file_contents(filepath)
        folder_names = []
        for zinfo in archive_contents:
            filename = zinfo.filename
            folder_name, base_file_name, file_extension = cls.getFileNameParts(filename)
            if folder_name in required_folder_list:
                folder_names.append(folder_name)

        '''
        check that all members are present
        subset comparisons
        https://stackoverflow.com/questions/16579085/python-verifying-if-one-list-is-a-subset-of-the-other
        '''
        if not set(required_folder_list) <= set(folder_names):
            return False

        '''
        ok all good, return data
        '''
        return data

    @classmethod
    def list_zip_file_contents(cls, filepath):
        '''
        check that the file exists
        '''
        finfo_list = []
        if filepath and os.path.isfile(filepath):
            '''
            examine file
            '''
            with zipfile.ZipFile(filepath) as z:
                '''
                iterate members
                '''
                for finfo in z.infolist():
                    '''
                    store finfo
                    '''
                    finfo_list.append(finfo)

        '''
        return
        '''
        return finfo_list

    @classmethod
    def getFileNameParts(cls, filepath, *args, **kwargs):
        if not filepath:
            return False
        folderName, filename = os.path.split(filepath)
        baseFileName, fileExtension = os.path.splitext(filename)
        fileExtension = fileExtension[1:]  # remove period
        return folderName, baseFileName, fileExtension

    @classmethod
    def get_data_file_from_archive(cls, filepath):
        '''
        check that the file exists
        '''
        json_data = False
        if filepath and os.path.isfile(filepath):
            '''
            examine file
            '''
            with zipfile.ZipFile(filepath) as z:
                '''
                itterate members
                '''
                for finfo in z.infolist():
                    '''
                    skip folders, last part of filename will be '' if a folder
                    '''
                    filename = finfo.filename
                    path_parts = filename.split(os.sep)
                    # print path_parts
                    if path_parts[-1]:  # skip folders
                        '''
                        find data file
                        '''
                        if finfo.filename == 'data/eblabs.data':
                            with z.open(finfo) as zfile:
                                '''
                                extract json data
                                '''
                                json_data = json.loads(zfile.read())
        '''
        return
        '''
        return json_data

    @classmethod
    def write_json_file(cls, filepath, data):
        try:
            '''
            write data
            '''
            data = json.dumps(data, sort_keys=True, indent=4)
            with open(filepath, 'w') as f:
                f.write(data)
        except:
            return False

    @classmethod
    def read_json_file(cls, filepath):
        try:
            with open(filepath, 'r') as f:
                data = json.loads(f.read())
                return data
        except:
            return False

    @classmethod
    def get_core_folders_list(cls):
        d = ['data', 'images', 'scripts']
        return d

    @classmethod
    def get_working_shelf_name(cls):
        return 'eblabs_HUB'

    @classmethod
    def remove_package_buttons_from_shelf(cls, shelf, tool_id):
        '''
        look up buttons
        '''
        remove_shelf_buttons = cls.get_package_buttons_from_shelf(shelf, tool_id)
        if not remove_shelf_buttons:
            return False
        '''
        delete
        '''
        cmds.deleteUI(*remove_shelf_buttons, control=True)

    @classmethod
    def are_all_strings_in_string(cls, str_item, str_list):
        return all(s in str_item for s in str_list)

    @classmethod
    def inspect_component(cls, component):
        '''
        prep returns
        '''
        component_type = ''
        component_cleaned = ''

        '''
        validate
        '''
        if component is None:
            return False

        '''
        break down component
        '''
        component = str(component).strip()
        component_cleaned = eval(component)

        '''
        type check
        '''
        type_check = ''
        try:
            type_check = type(eval(component))
        except:
            pass

        '''
        casting
        '''
        if type_check:
            if type_check in [int, float]:
                component_type = 'number'
                component_cleaned = float(component_cleaned)
            elif type_check == bool:
                component_type = 'boolean'
            elif type_check == list:
                component_type = 'list'
            elif type_check == str:
                component_type = 'string'

        return[component_type, component_cleaned]

    @classmethod
    def get_package_buttons_from_shelf(cls, shelf, tool_id):
        '''
        set active shelf
        '''
        cls.set_active_shelf(shelf)

        '''
        check that shelf exists
        '''
        if not cmds.shelfLayout(shelf, exists=True, query=True):
            return []

        '''
        iterate through child buttons of shelf
        '''
        matching_buttons = []
        child_array = cmds.shelfLayout(shelf, query=True, childArray=True, fullPathName=True)
        if not child_array:
            return []
        for shelf_button in child_array:
            command_str = cmds.shelfButton(shelf_button, query=True, command=True)
            '''
            check tool_id
            '''
            split_lines = command_str.splitlines()
            for line in split_lines:
                '''
                isolate tool_id line
                '''
                if Utils.are_all_strings_in_string(line, ['tool_id', '=']):
                    '''
                    check tool_id value
                    '''
                    component, component_value = line.split('=')
                    component_type, component_value = cls.inspect_component(component_value)
                    if component_value == tool_id:
                        if shelf_button not in matching_buttons:
                            matching_buttons.append(shelf_button)
                            break
        '''
        results
        '''
        return matching_buttons

    @classmethod
    def pre_install_cleanup(cls, data):
        '''
        define folder names
        '''
        root_install_path = os.path.normpath(os.path.join(cmds.internalVar(userAppDir=True), 'scripts', 'eblabs_hub'))
        package_install_path = os.path.normpath(os.path.join(root_install_path, data['location']))

        '''
        remove old data
        '''
        core_folders = cls.get_core_folders_list()
        for core_folder in core_folders:
            remove_path = os.path.normpath(os.path.join(package_install_path, core_folder))
            if os.path.exists(remove_path):
                try:
                    shutil.rmtree(remove_path)
                except Exception as e:
                    print(519, False,Exception, e )
                    return False

        '''
        generate new folders
        '''
        try:
            if not os.path.exists(package_install_path):
                os.makedirs(package_install_path)
        except Exception as e:
            print(529, False, Exception, e)
            return False

        '''
        remove old shelf buttons
        todo
        '''
        shelf = cls.get_working_shelf_name()
        tool_id = data['location']
        cls.remove_package_buttons_from_shelf(shelf, tool_id)
        return True

    @classmethod
    def set_active_shelf(cls, shelf):
        '''
        create if it doesnt exist
        '''
        cls.create_shelf(shelf)

    @classmethod
    def create_shelf(cls, shelf):
        '''
        create shelf if it doesnt exist
        '''
        parent = mel.eval("global string $gShelfTopLevel; $temp = $gShelfTopLevel;")
        if not cmds.shelfLayout(shelf, exists=True, query=True):
            mel.eval('${0} = `shelfLayout -cellHeight 32 -p $gShelfTopLevel {0}`;'.format(shelf))

        '''
        set active shelf
        '''
        cmds.tabLayout(parent, edit=True, selectTab=shelf)

    @classmethod
    def getCommandTemplate(cls):
        data = {}
        data['shortName'] = ''
        data['longName'] = ''
        data['annotation'] = ''
        data['command'] = ''
        data['altCommand'] = ''
        data['sourceType'] = ''

        return copy.deepcopy(data)

    @classmethod
    def create_shelf_button(cls, target_shelf = False, button_data = False):
        print(1691, 'create_shelf_button', button_data)
        '''
        annotation 
        '''
        button_annotation = button_data['annotation']

        '''
        children/popups 
        '''
        button_popups = button_data['children']

        '''
        icon
        '''
        icon_path = button_data['icon']['image']

        '''
        overlay label
        '''
        icon_label = button_data['icon']['label']

        '''
        list label
        '''
        list_label = button_data['shortName']

        '''
        command
        '''
        try:
            button_command_data = button_data['command_data']
        except:
            button_command_data = cls.getCommandTemplate()
        button_command = button_command_data['command']
        button_source_type = button_command_data['sourceType']

        '''
        get target shelf
        '''
        parent = cmds.shelfLayout(target_shelf, query=True, fullPathName=True)
        # make button
        button_data = cmds.shelfButton(parent =parent,  annotation=button_annotation, image=icon_path, image1=icon_path, c=button_command,
                                       sourceType=button_source_type)
        cmds.shelfButton(button_data, edit=True, imageOverlayLabel=icon_label)
        cmds.shelfButton(button_data, edit=True, label=list_label)

        #print(1712, parent, button_data)
        # add popups
        if button_popups:
            popMenu = cmds.popupMenu(button_data, button=3)
            for popupItem in button_popups:
                popupDivider = popupItem['divider']
                popupSubmenu = popupItem['subMenu']
                popupLabel = popupItem['label']
                popupCommand = popupItem['command']
                popupSourceType = popupItem['sourceType']

                # black list commands
                blackList = ['Delete', 'Edit Popup', 'Open', 'Edit']
                if popupLabel not in blackList:
                    # regular items
                    if not popupDivider and not popupSubmenu:
                        cmds.menuItem(parent=popMenu, label=popupLabel, command=popupCommand, sourceType=popupSourceType)

                    # dividers
                    if popupDivider:
                        cmds.menuItem(parent=popMenu, divider=True)

                    # submenus
                    if popupSubmenu:
                        submenuParent = cmds.menuItem(parent=popMenu, submenu=True, label=popupLabel)
                        for si in popupSubmenu:
                            si_label = si['label']
                            si_command = si['command']
                            si_sourceType = si['sourceType']

                            # black list
                            if si_label not in blackList:
                                # make the submenu item
                                cmds.menuItem(parent=submenuParent, label=popupLabel, command=si_command,
                                              sourceType=si_sourceType)
    @classmethod
    def touch(cls, path):
        '''
        create folder
        '''
        basedir = os.path.dirname(path)
        if not os.path.exists(basedir):
            os.makedirs(basedir)
        '''
        create empty file
        '''
        with open(path, 'a'):
            os.utime(path, None)

    @classmethod
    def get_icon_path_from_data(cls, data, shelf_button_index = 0):
        '''
        icon path
        '''
        try:
            icon_filename = data['shelf_data'][shelf_button_index]['icon']['image']
        except Exception as e:
            print(1998, Exception, e, data)
            print (traceback.format_exc())
            return False
        try:
            package_folder = data['location']
        except Exception as e:
            print(2003, Exception, e)
            return False

        '''
        filename parts
        '''
        folderName, baseFileName, fileExtension = cls.getFileNameParts(icon_filename)

        '''
        calculate path
        '''
        root_path = Utils.get_working_path()
        file_path = os.path.normpath(os.path.join(root_path, package_folder, 'images', '{0}.{1}'.format(baseFileName, fileExtension)))

        '''
        check if full path or shortpath
        '''
        if os.path.isfile(file_path):
            return file_path
        else:
            return '{0}.{1}'.format(baseFileName, fileExtension)

    @classmethod
    def localize_images_paths(cls, data):
        '''
        pull out shelf data
        '''
        shelf_data = data.get('shelf_data', [])
        if not shelf_data:
            return data

        '''
        rebuild new shelf data
        '''
        new_shelf_data = []
        for i in range(len(shelf_data)):
            button_data = copy.deepcopy(shelf_data[i])
            button_data['icon']['image'] = cls.get_icon_path_from_data(data, i)
            new_shelf_data.append(button_data)

        '''
        replace
        '''
        data['shelf_data'] = copy.deepcopy(new_shelf_data)

        return data

    @classmethod
    def modify_nested_data(cls, obj, modify_function, key=False):
        """
        Recursively goes through the dictionary obj and replaces keys with the modify_function function.
        https://stackoverflow.com/questions/11700705/python-recursively-replace-character-in-keys-of-nested-dictionary
        """
        if isinstance(obj, (str, int, float)):
            return modify_function(key, obj)
        if isinstance(obj, dict):
            new = obj.__class__()
            for k, v in obj.items():
                new[k] = cls.modify_nested_data(modify_function(k, v), modify_function, key=k)
        elif isinstance(obj, (list, set, tuple)):
            new = obj.__class__(cls.modify_nested_data(modify_function(key, v), modify_function, key=False) for v in obj)
        else:
            return modify_function(key, obj)
        return new

    @classmethod
    def get_working_path(cls):
        return os.path.normpath(os.path.join(cmds.internalVar(userAppDir=True), 'scripts', 'eblabs_hub'))

    @classmethod
    def localize_scripts_paths(cls, data):
        '''
        recursively search through data for 'command
        '''
        replace_data = {}
        replace_data['root_path'] = cls.get_working_path()
        replace_data['tool_id'] = data['location']

        data = cls.modify_nested_data(data, partial(cls.localize_scripts_paths_modify_function, replace_data))

        return data

    @classmethod
    def localize_scripts_paths_modify_function(cls, replace_data, key, value):
        root_path = replace_data['root_path']
        tool_id = replace_data['tool_id']
        if key == 'command':
            #print(2163, type(value), root_path, value, tool_id)
            if isinstance(value, (str, unicode)):
                value = cls.localize_script_paths_string_processing(root_path, value, tool_id)
        return value

    @classmethod
    def localize_script_paths_string_processing(cls, root_path, script_string, tool_id):
        '''
        make replacements
        split into lines
        '''
        split_lines = script_string.splitlines()
        new_lines = []
        for line in split_lines:
            '''
            looking for: 
            install_path = ''
            tool_id = 'myTool'
            '''
            if cls.are_all_strings_in_string(line, ['install_path', '=']):
                line = "install_path = '{0}'".format(root_path)
            elif cls.are_all_strings_in_string(line, ['tool_id', '=']):
                line = "tool_id = '{0}'".format(tool_id)

            '''
            assemble
            '''
            new_lines.append(line)

        '''
        assemble
        '''
        split_lines = '\n'.join(new_lines)
        return split_lines

    @classmethod
    def unpack_package(cls, filepath, data):
        '''
        define folder names
        '''
        filepath = os.path.normpath(filepath)
        root_install_path = cls.get_working_path()
        package_id = data['location']
        package_install_path = os.path.normpath(os.path.join(root_install_path, package_id))

        '''
        store a copy locally
        '''
        versions_folder = os.path.normpath(os.path.join(package_install_path, 'versions'))
        version_file = os.path.normpath(os.path.join(package_install_path, 'versions', os.path.basename(filepath)))
        if not os.path.exists(versions_folder):
            os.makedirs(versions_folder)
        if version_file != filepath:
            shutil.copy2(filepath, version_file)

        '''
        unzip into install path
        '''
        with zipfile.ZipFile(filepath, 'r') as z:
            z.extractall(package_install_path)

        '''
        add init files
        '''
        init_files = []
        path = os.path.normpath(os.path.join(package_install_path, '__init__.py'))
        init_files.append(path)
        path = os.path.normpath(os.path.join(package_install_path, 'scripts', '__init__.py'))
        init_files.append(path)
        for f in init_files:
            if not os.path.isfile(f):
                cls.touch(f)

        '''
        modify icon paths
        '''
        data = cls.localize_images_paths(data)
        data = cls.localize_scripts_paths(data)

        '''
        write updated data file
        '''
        path = os.path.normpath(os.path.join(package_install_path, 'data', 'eblabs.data'))
        cls.write_json_file(path, data)

        '''
        return 
        '''
        return data

    @classmethod
    def install_package(cls, filepath = False):
        '''
        ask user for package
        '''
        if not filepath:
            filepath = cls.ask_user_for_package_file()

        '''
        validate package
        '''
        data = cls.validate_package(filepath)
        if not data:
            print(669, 'False')
            return False

        '''
        remove old contents, ask user if ok
        also remove old shelf buttons
        '''
        success = cls.pre_install_cleanup(data)
        if not success:
            print(679, 'False')
            return False

        '''
        unpack zip file into folders
        '''
        data = cls.unpack_package(filepath, data)
        if not data:
            print(686, 'False')
            return False

        '''
        create eblabs shelf if not there
        '''
        shelf = cls.get_working_shelf_name()
        cls.create_shelf(shelf)

        '''
        add new buttons
        '''
        shelf_data = data.get('shelf_data', [])
        if shelf_data:
            for button_data in shelf_data:
                cls.create_shelf_button(target_shelf=shelf, button_data=button_data)
        '''
        store prefs
        '''
        cmds.savePrefs()
        return True