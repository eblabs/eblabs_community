import urllib2
import urllib
import tempfile
import os
import sys
import zipfile
import json

from maya import cmds


'''
add offline installer through menu!
'''

'''
launcher
'''
def onMayaDroppedPythonFile(*args, **kwargs):
    print('drag drop - onMayaDroppedPythonFile', args, kwargs)
    Installer.run_installer()

online_package_path = 'https://raw.githubusercontent.com/eblabs/eblabs_docs/master/test_download.txt'


class Status(object):
    Pre = 1
    Offline = 2
    Success = 3
    Error = 4

class Installer():
    Instance = False

    @classmethod
    def run_installer(cls):
        '''
        1. check if online
        2. get package, via online or local
        3. install local
        4. build shelf + button
        5. Congrats, info popup
        '''

        '''
        initial state message, display UI
        '''
        cls.init_ui()
        '''
        status
        '''
        status = Status.Pre

        '''
        auto run stages
        '''
        is_online = Utils.internet_on()
        if not is_online:
            status = Status.Offline
        else:
            '''
            attempt to install
            '''
            url = 'https://github.com/eblabs/eblabs_docs/raw/master/Installer/eblabs_PackageManager_0.0.zip'
            temp_filepath = Utils.download_file(url=url)
            if temp_filepath:
                '''
                woot, file downloaded
                '''
                print(71, 'downloaded', temp_filepath)

        '''
        update UI message
        '''
        text = cls.get_feedback_message(status)



    @classmethod
    def init_ui(cls):
        windowName = 'eblabs_Installer'
        width = 600
        height = 400
        if (cmds.window(windowName, exists=True)):
            cmds.deleteUI(windowName, window=True)
        if (cmds.windowPref(windowName, exists=True)):
            cmds.windowPref(windowName, remove=True)
        cls.window = cmds.window(windowName, widthHeight=(width, height), title=windowName)

        '''
        layout
        '''
        form_layout = cmds.formLayout(parent = cls.window)

        '''
        menu
        '''
        menu_bar = cmds.menuBarLayout(parent = form_layout)
        menu = cmds.menu(parent=menu_bar, label='Options', tearOff=False)
        menu_item = cmds.menuItem(parent=menu, label='Offline Install', command=cls.offline_install)

        '''
        ui elements
        * welcome message
        '''
        cls.welcome_text = cmds.scrollField(parent=form_layout)

        cmds.formLayout(form_layout, edit=True, attachForm=[(menu_bar, 'top', 0)])
        cmds.formLayout(form_layout, edit=True, attachForm=[(menu_bar, 'left', 0)])
        cmds.formLayout(form_layout, edit=True, attachNone=[(menu_bar, 'bottom' )])
        cmds.formLayout(form_layout, edit=True, attachForm=[(menu_bar, 'right', 0)])

        cmds.formLayout(form_layout, edit=True, attachControl=[(cls.welcome_text, 'top', 0, menu_bar)])
        cmds.formLayout(form_layout, edit=True, attachForm=[(cls.welcome_text, 'left', 0)])
        cmds.formLayout(form_layout, edit=True, attachForm=[(cls.welcome_text, 'bottom', 0)])
        cmds.formLayout(form_layout, edit=True, attachForm=[(cls.welcome_text, 'right', 0)])

        '''
        set initial message
        '''
        text = cls.get_feedback_message(Status.Pre)
        cls.set_message(text)

        '''
        display
        '''
        cmds.showWindow(cls.window)

    @classmethod
    def offline_install(cls):
        print(119, 'offline_install')
        '''
        browse for package
        '''

        '''
        install package
        '''

        '''
        success message
        '''

    @classmethod
    def set_message(cls, text):
        cmds.scrollField(cls.welcome_text, edit=True, text=text, wordWrap=False, fn='fixedWidthFont', editable=False)


    @classmethod
    def get_feedback_message(cls, status):
        '''
        class Status(object):
        Pre = 1
        Offline = 2
        Success = 3
        Error = 4
        '''

        lookup = {}

        '''
        pre
        '''
        message = '''
Thanks for supporting eblabs.com!

Package Manager Installer

More detailed instructions can be found here:
https://github.com/eblabs/eblabs_docs

Online Install
1. Launch installer by dragging eblabs_drag_drop_install.py script into Maya.
2. The package file will download automatically and appear in the text field.
2. Click Install

Offline Install
1. Drag eblabs_drag_drop_install.py script into Maya. (Done)
2. Locate the local ##.zip file
3. Click Install

After Installing
Use the package manager for adding all your
eblabs tools to your Maya environment. 
Happy Animating!
'''
        lookup[Status.Pre] = message

        '''
        Success
        '''
        message = '''
Thanks for supporting eblabs.com!

Congratulations, the Package Manager has been successfully
installed. It can now be found on the eblabs_HUB shelf. Please
use this for installing and updating all of your eblabs.com tools!

Happy Animating!!

-Eric @ eblabs
        '''
        lookup[Status.Success] = message

        '''
        Offline
        '''
        message = '''
        '''
        lookup[Status.Offline] = message

        '''
        Error
        '''
        message = '''
        '''
        lookup[Status.Error] = message



        '''
        return 
        '''
        return lookup[status]


class Utils():

    @classmethod
    def internet_on(cls):
        try:
            url = 'https://github.com'
            urllib2.urlopen(url, timeout=1)
            return True
        except urllib2.URLError as err:
            return False

    @classmethod
    def download_file(cls, url=''):
        '''
        check
        '''
        if not url:
            return False

        '''
        temp save dir
        '''
        temp_folder = tempfile.gettempdir()
        _, filename = os.path.split(url)
        temp_file = os.path.normpath(os.path.join(temp_folder, filename))

        '''
        download
        '''
        try:
            urllib.urlretrieve(url, filename=temp_file)
            if os.path.exists(temp_file):
                return temp_file
        except Exception as e:
            pass

        '''
        fallback
        '''
        return False

    @classmethod
    def install_package(cls, filepath):
        print('Installing Pacakge, ', filepath)

    @classmethod
    def ask_user_for_package_file(cls):
        # get path
        filters = 'eblabs_PackageManager_0.0.zip (eblabs_PackageManager_0.0.zip)'
        path = cmds.fileDialog2(fileFilter=filters, dialogStyle=2, fileMode=1, okCaption='OK')
        if path:
            return str(path[0])
        else:
            return False

    @classmethod
    def validate_package(cls, filepath):
        '''
        makes sure that:
        1. data file is readable
        2. has correct folders
        '''
        required_folder_list = ['data', 'images', 'scripts']
        data = False
        try:
            data = cls.get_data_file_from_archive(filepath)
        except Exception as e:
            print(130, Exception, e)
            return False
        if not data:
            return False
        '''
        check file contents
        '''
        archive_contents = cls.list_zip_file_contents(filepath)
        folder_names = []
        for zinfo in archive_contents:
            filename = zinfo.filename
            folder_name, base_file_name, file_extension = cls.getFileNameParts(filename)
            if folder_name in required_folder_list:
                #folder_name = os.path.basename(os.path.normpath(filename))
                folder_names.append(folder_name)

        '''
        check that all members are present
        subset comparisons
        https://stackoverflow.com/questions/16579085/python-verifying-if-one-list-is-a-subset-of-the-other
        '''
        if not set(required_folder_list) <= set(folder_names):
            return False

        '''
        ok all good, return data
        '''
        return data

    @classmethod
    def getFileNameParts(cls, filepath, *args, **kwargs):
        if not filepath:
            return False
        folderName, filename = os.path.split(filepath)
        baseFileName, fileExtension = os.path.splitext(filename)
        fileExtension = fileExtension[1:]  # remove period
        return folderName, baseFileName, fileExtension

    @classmethod
    def get_data_file_from_archive(cls, filepath):
        '''
        check that the file exists
        '''
        json_data = False
        if filepath and os.path.isfile(filepath):
            '''
            examine file
            '''
            with zipfile.ZipFile(filepath) as z:
                '''
                itterate members
                '''
                for finfo in z.infolist():
                    '''
                    skip folders, last part of filename will be '' if a folder
                    '''
                    filename = finfo.filename
                    path_parts = filename.split(os.sep)
                    # print path_parts
                    if path_parts[-1]:  # skip folders
                        '''
                        find data file
                        '''
                        if finfo.filename == 'data/eblabs.data':
                            with z.open(finfo) as zfile:
                                '''
                                extract json data
                                '''
                                json_data = json.loads(zfile.read())
        '''
        return
        '''
        return json_data

    @classmethod
    def pre_install_cleanup(cls, data):
        '''
        define folder names
        '''
        root_install_path = os.path.normpath(os.path.join(cmds.internalVar(userAppDir=True), 'scripts', 'eblabs_hub'))
        package_install_path = os.path.normpath(os.path.join(root_install_path, data['location']))

        '''
        remove previous version if there
        todo, ask if user wants to update, show change of versions
        '''
        previous_data_filepath = os.path.normpath(os.path.join(package_install_path, 'data', 'eblabs.data'))
        previous_data = FileUtils.read_json_file(previous_data_filepath)
        if previous_data:
            '''
            todo, 
            '''
            print(170, 'Previous Data Exists, todo, ask user for downgrade? ', previous_data)

        '''
        remove old data
        '''
        core_folders = DataTemplates.Templates.get_core_folders_list()
        for core_folder in core_folders:
            remove_path = os.path.normpath(os.path.join(package_install_path, core_folder))
            if os.path.exists(package_install_path):
                try:
                    shutil.rmtree(remove_path)
                    print(174, 'Cleaning Up Folder: ', remove_path)
                except Exception as e:
                    print(175, 'Unable to remove Previous Install', remove_path, Exception, e)
                    return False

        '''
        generate new folders
        '''
        try:
            if not os.path.exists(package_install_path):
                os.makedirs(package_install_path)
                print(186, 'Generating Folder: ', package_install_path)
        except Exception as e:
            print(185, 'generate new folders FAILED', Exception, e)
            return False

        '''
        remove old shelf buttons
        todo
        '''
        shelf = cls.get_working_shelf_name(mode=UserModes.User)
        tool_id = data['location']
        MayaUtils.remove_package_buttons_from_shelf(shelf, tool_id)
        print(1618, 'todo: remove old shelf buttons')

    @classmethod
    def install_package(cls, filepath = False):
        '''
        ask user for package
        '''
        if not filepath:
            filepath = cls.ask_user_for_package_file()

        '''
        validate package
        '''
        data = cls.validate_package(filepath)
        if not data:
            return False

        '''
        remove old contents, ask user if ok
        also remove old shelf buttons
        '''
        cls.pre_install_cleanup(data)


        '''
        unpack zip file into folders
        '''
        data = cls.unpack_package(filepath, data)

        '''
        create eblabs shelf if not there
        '''
        shelf = cls.get_working_shelf_name(mode = UserModes.User)
        MayaUtils.create_shelf(shelf)

        '''
        add new buttons
        '''
        shelf_data = data.get('shelf_data', [])
        if shelf_data:
            for button_data in shelf_data:
                MayaUtils.create_shelf_button(target_shelf=shelf, button_data=button_data)
        '''
        store prefs
        '''
        if for_real and filepaths:
            MayaUtils.savePrefs()