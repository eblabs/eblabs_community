import urllib2





'''
launcher
'''
def onMayaDroppedPythonFile(*args, **kwargs):
    print('drag drop - onMayaDroppedPythonFile', args, kwargs)

online_package_path = 'https://raw.githubusercontent.com/eblabs/eblabs_docs/master/test_download.txt'

class Installer():

    @classmethod
    def run_installer(cls):
        '''
        1. check if online
        2. get package, via online or local
        3. install local
        4. build shelf + button
        5. Congrats, info popup
        '''

        '''
        check online
        '''
        is_online = Utils.internet_on()

        '''
        get package
        '''
        if is_online:
            '''
            download package
            '''
        else:
            '''
            ask user for package
            '''

        '''
        '''


class Utils():

    @classmethod
    def internet_on(cls):
        try:
            url = 'https://github.com'  # /eblabs/eblabs_docs/raw/master/README.md'
            urllib2.urlopen(url, timeout=1)
            return True
        except urllib2.URLError as err:
            return False


'''
* get package manager script
* either by downloading, or by selecting

* online/offline check

* unpack zip file

* create shelf and buttons

* done :)

'''

'''
##Python 2
import urllib
def hook(*args, **kwargs):
    print('hook', args, kwargs)
url = 'https://github.com/eblabs/eblabs_docs/raw/master/test_download.txt'
local_path = 'C:/Users/eric/Downloads/test_download.txt'
urllib.urlretrieve (url, filename=local_path, reporthook=hook)

##Python 3
import urllib.request
url = "https://www.cs.cmu.edu/~./enron/enron_mail_20150507.tgz"
print ("download start!")
filename, headers = urllib.request.urlretrieve(url, filename="e:\\PythonStuff\\enron_mail_20150507.tgz")
print ("download complete!")
print ("download file location: ", filename)
print ("download headers: ", headers)
'''